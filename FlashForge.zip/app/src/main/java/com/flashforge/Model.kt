package com.flashforge

import android.net.Uri

enum class Mode(val label: String) {
    NONE("NO DEVICE"),
    FASTBOOT("FASTBOOT"),
    ADB("ADB / RECOVERY"),
    SAMSUNG_DOWNLOAD("SAMSUNG DOWNLOAD"),
    QUALCOMM_EDL("QUALCOMM EDL 9008"),
    MEDIATEK_BROM("MEDIATEK BROM / PRELOADER"),
    UNISOC("UNISOC FDL"),
    UNKNOWN("UNKNOWN")
}

enum class Link(val label: String) {
    RED("NOT CONNECTED"),
    YELLOW("CONNECTING / UNSTABLE"),
    GREEN("CONNECTED")
}

enum class Screen(val title: String, val icon: Int) {
    DEVICE("DEVICE", R.drawable.ic_device),
    FLASH("FLASH", R.drawable.ic_flash),
    PART("PARTITION", R.drawable.ic_part),
    ROM("ROM & Root", R.drawable.ic_rom),
    LOG("LOG", R.drawable.ic_log),
    SAFETY("SAFETY", R.drawable.b_shield),
    SETTINGS("SETTINGS", R.drawable.ic_settings)
}

data class QItem(val part: String, val uri: Uri, val name: String, val size: Long, val enabled: Boolean = true)
