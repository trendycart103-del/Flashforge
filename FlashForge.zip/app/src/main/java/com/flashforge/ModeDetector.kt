package com.flashforge

import android.hardware.usb.UsbDevice

object ModeDetector {
    fun detect(d: UsbDevice): Mode {
        val vid = d.vendorId
        val pid = d.productId
        if (vid == 0x05c6 && pid == 0x9008) return Mode.QUALCOMM_EDL
        if (vid == 0x0e8d && (pid == 0x0003 || pid == 0x2000 || pid == 0x2001)) return Mode.MEDIATEK_BROM
        if (vid == 0x04e8 && pid == 0x685d) return Mode.SAMSUNG_DOWNLOAD
        if (vid == 0x1782 && pid == 0x4d00) return Mode.UNISOC
        for (i in 0 until d.interfaceCount) {
            val f = d.getInterface(i)
            if (f.interfaceClass == 0xFF && f.interfaceSubclass == 0x42) {
                when (f.interfaceProtocol) {
                    0x03 -> return Mode.FASTBOOT
                    0x01 -> return Mode.ADB
                    // Keep checking other interfaces; composite USB devices can expose
                    // unrelated vendor interfaces before their ADB/Fastboot interface.
                }
            }
        }
        return Mode.UNKNOWN
    }

    fun chipHint(m: Mode): String = when (m) {
        Mode.QUALCOMM_EDL -> "Qualcomm"
        Mode.MEDIATEK_BROM -> "MediaTek"
        Mode.UNISOC -> "Unisoc"
        Mode.SAMSUNG_DOWNLOAD -> "Samsung (Exynos or Qualcomm)"
        else -> ""
    }
}
