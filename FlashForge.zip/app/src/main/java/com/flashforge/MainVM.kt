package com.flashforge

import android.app.Application
import android.app.PendingIntent
import android.content.Context
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.DataInputStream
import java.io.BufferedInputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.zip.ZipInputStream

class MainVM(app: Application) : AndroidViewModel(app) {
    companion object { const val ACTION = "com.flashforge.USB_PERMISSION" }

    private val ctx = app
    private val usb = app.getSystemService(Context.USB_SERVICE) as UsbManager
    private val prefs = app.getSharedPreferences("flashforge", Context.MODE_PRIVATE)
    private val db = DeviceDb(app)
    private var fb: Fastboot? = null
    @Volatile private var activeAdb: AdbSideload? = null
    @Volatile private var activeAdbConnection: UsbDeviceConnection? = null

    var screen by mutableStateOf(Screen.DEVICE)
    var device by mutableStateOf<UsbDevice?>(null)
    var mode by mutableStateOf(Mode.NONE)
    var vendor by mutableStateOf("")
    var usbId by mutableStateOf("")
    var product by mutableStateOf("")
    var modelName by mutableStateOf("")
    var modelNote by mutableStateOf("")
    var chip by mutableStateOf("")
    var analyzerStatus by mutableStateOf("WARNING")
    var analyzerMessage by mutableStateOf("Pre-flash analysis has not run for an image yet. The actual gate runs automatically on every image flash.")
    val analyzerChecks = mutableStateListOf<String>()
    val analyzerWarnings = mutableStateListOf(
        "The app can compare a publisher SHA-256, but it cannot independently authenticate the website/person that supplied that checksum.",
        "This Fastboot interface does not provide a reliable hardware-variant, firmware-build, region/CSC compatibility proof for every device. Verify those details against the OEM release notes.",
        "The app validates .img readability, Android sparse structure when present, and partition fit, but it does not parse every vendor-specific firmware payload or signed build manifest."
    )
    var safetyWarningsAcknowledged by mutableStateOf(false)
    var isAB by mutableStateOf(false)
    private var slotInfoKnown = false
    var unlocked by mutableStateOf("?")
    var slot by mutableStateOf("?")
    var userspace by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var progress by mutableFloatStateOf(0f)
    var expected by mutableStateOf(prefs.getString("expected", "") ?: "")
    var dbUrl by mutableStateOf(prefs.getString("dburl", "") ?: "")
    var dbInfo by mutableStateOf("v${db.version}, ${db.count()} models")

    /** Optional vendor loader/DA selection. Stored only as a user-selected reference; never auto-executed. */
    fun optionalLoader(key: String): Uri? = prefs.getString("optional_loader_$key", null)?.let(Uri::parse)

    fun setOptionalLoader(key: String, uri: Uri?) {
        if (uri == null) {
            prefs.edit().remove("optional_loader_$key").apply()
            log("Optional ${key.uppercase()} loader selection cleared")
            return
        }
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) { log("Optional loader URI permission is temporary: ${e.message}") }
        prefs.edit().putString("optional_loader_$key", uri.toString()).apply()
        log("Optional ${key.uppercase()} loader selected: ${uri.lastPathSegment ?: "document"}. Selection is stored only; no chipset write operation is enabled.")
    }

    // ---- cable alert and floating bubble ----
    var cableWarn by mutableStateOf<String?>(null)
    var bubbleOn by mutableStateOf(prefs.getBoolean("bubble", true))
    var overlayOk by mutableStateOf(false)
    var notifOk by mutableStateOf(true)
    private var slowCount = 0
    private var cableIgnored = false
    @Volatile private var failed = false

    val vars = mutableStateMapOf<String, String>()
    val parts = mutableStateListOf<String>()
    val queue = mutableStateListOf<QItem>()

    // ---- flash screen state (read by FlashingScreen) ----
    var flashScreenOpen by mutableStateOf(false)
    /** 0 = running, 1 = finished OK, 2 = failed */
    var flashOutcome by mutableIntStateOf(0)
    var flashIndex by mutableIntStateOf(0)
    val flashPlan = mutableStateListOf<QItem>()

    /** Skip (cross) or re-include one queue file. Not allowed while an operation runs. */
    fun toggleQueueItem(i: Int) {
        if (busy) return
        if (i in queue.indices) queue[i] = queue[i].copy(enabled = !queue[i].enabled)
    }

    /** Empty = detect the flash screen style from the phone; otherwise a FlashBrand name picked by the user. */
    var brandOverride by mutableStateOf(prefs.getString("brand_style", "") ?: "")

    fun setBrandOverride(name: String) {
        brandOverride = name
        prefs.edit().putString("brand_style", name).apply()
    }

    fun closeFlashScreen() {
        if (!busy) flashScreenOpen = false
    }
    val logs = mutableStateListOf<String>()
    // A file is flash-eligible only after its expected SHA-256 has matched.
    val verifiedFirmware = mutableStateMapOf<String, String>()

    // ---- connection light (red / yellow / green) ----
    var link by mutableStateOf(Link.RED)
    var linkNote by mutableStateOf("No device. Connect the phone with an OTG cable.")
    var linkPct by mutableStateOf(0)
    private var pending = false
    private var connecting = false
    private var ready = false
    private var connectedAt = 0L
    private val detachTimes = ArrayList<Long>()
    @Volatile private var pendingDestructiveConfirmation: String? = null
    @Volatile private var viewModelClosing: Boolean = false
    @Volatile private var closeInterruptionJournaled: Boolean = false
    @Volatile private var lastConfirmedStep: String = "No destructive step confirmed"
    @Volatile private var activeOperationLabel: String = ""
    @Volatile private var activeFileName: String = ""
    @Volatile private var activePartition: String = ""
    @Volatile private var activeSha256: String = ""

    init {
        AppSettings.init(app)
        FlashStatus.bubbleOn = bubbleOn
        refreshPerms()
        val prior = prefs.getString("operation_journal", null)
        if (!prior.isNullOrBlank()) {
            try {
                val j = JSONObject(prior)
                if (j.optString("status") == "RUNNING") {
                    j.put("status", "INTERRUPTED")
                    j.put("error", "Application process ended before the operation was marked complete. Do not retry automatically; inspect the target device and recovery state.")
                    j.put("updatedAt", System.currentTimeMillis())
                    prefs.edit().putString("operation_journal", j.toString()).commit()
                    appendOperationHistory(j)
                    analyzerStatus = "BLOCKED"
                    analyzerMessage = "Previous operation was interrupted. Inspect the device before any retry. Last confirmed step: ${j.optString("lastConfirmedStep", "unknown")}."
                    log("RECOVERY REQUIRED: previous '${j.optString("label")}' operation was interrupted. Last confirmed step: ${j.optString("lastConfirmedStep", "unknown")}. Do not repeat a destructive operation automatically.")
                }
            } catch (e: Exception) { log("Could not read previous operation journal: ${e.message}") }
        }
        viewModelScope.launch {
            while (true) {
                delay(500)
                updateLink()
            }
        }
    }

    /** Main thread only. Red = no link, yellow = connecting or dropping, green = stable and ready. */
    private fun updateLink() {
        val now = System.currentTimeMillis()
        detachTimes.removeAll { now - it > 20000 }
        val flapping = detachTimes.size >= AppSettings.flapLimit
        val r = when {
            flapping -> {
                raiseCable("The USB connection dropped ${detachTimes.size} times in 20 seconds.")
                Triple(Link.YELLOW, "Connection keeps dropping. Change the USB cable.", 35)
            }
            pending -> Triple(Link.YELLOW, "Waiting for USB permission. Tap Allow.", 20)
            device == null -> Triple(Link.RED, "No device. Connect the phone with an OTG cable.", 0)
            connecting -> Triple(Link.YELLOW, "Connecting and reading the device...", 60)
            ready && now - connectedAt >= 2000 -> Triple(Link.GREEN, "Stable connection. Ready.", 100)
            ready -> Triple(Link.YELLOW, "Verifying the link...", 90)
            else -> Triple(Link.YELLOW, "Device found but not ready. Put it in a known mode.", 50)
        }
        link = r.first
        linkNote = r.second
        linkPct = r.third
    }

    private fun markReady() {
        connectedAt = System.currentTimeMillis()
        ready = true
    }

    fun log(s: String) {
        logs.add(s)
        while (logs.size > AppSettings.logMax) logs.removeAt(0)
    }

    private fun hex(i: Int) = "%04X".format(i)

    private fun writeJournal(label: String, status: String, error: String = "") {
        val j = JSONObject()
            .put("label", label)
            .put("status", status)
            .put("productId", product)
            .put("fileName", activeFileName)
            .put("partition", activePartition)
            .put("sha256", activeSha256)
            .put("lastConfirmedStep", lastConfirmedStep)
            .put("updatedAt", System.currentTimeMillis())
            .put("error", error)
        prefs.edit().putString("operation_journal", j.toString()).commit()
    }

    private fun appendOperationHistory(record: JSONObject) {
        try {
            val old = prefs.getString("operation_history", "[]") ?: "[]"
            val array = JSONArray(old)
            array.put(JSONObject(record.toString()))
            val trimmed = JSONArray()
            val start = maxOf(0, array.length() - 100)
            for (i in start until array.length()) trimmed.put(array.getJSONObject(i))
            prefs.edit().putString("operation_history", trimmed.toString()).commit()
        } catch (e: Exception) { log("Could not persist operation history: ${e.message}") }
    }

    private fun finalizeJournal(label: String, status: String, error: String = "") {
        writeJournal(label, status, error)
        val record = JSONObject(prefs.getString("operation_journal", "{}") ?: "{}")
        appendOperationHistory(record)
    }

    private fun io(label: String, bubble: Boolean = false, block: () -> Unit) {
        if (busy) { log("Busy. Wait for the current task to finish."); return }
        busy = true
        progress = 0f
        cableIgnored = false
        slowCount = 0
        failed = false
        lastConfirmedStep = "Operation accepted by application"
        activeOperationLabel = label
        closeInterruptionJournaled = false
        activeFileName = ""
        activePartition = ""
        activeSha256 = ""
        writeJournal(label, "RUNNING")
        val isFlashRun = label.startsWith("Flash", true)
        if (isFlashRun) {
            flashPlan.clear()
            flashIndex = 0
            flashOutcome = 0
            flashScreenOpen = true
        }
        if (bubble) {
            FlashStatus.label = label
            FlashStatus.progress = 0f
            FlashStatus.speed = 0.0
            FlashStatus.warn = false
            FlashStatus.warnText = ""
            FlashStatus.result = 0
            FlashStatus.running = true
            startBubble()
        }
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { block() }
                if (lastConfirmedStep == "Operation accepted by application") lastConfirmedStep = "Operation completed"
                finalizeJournal(label, "SUCCESS")
            } catch (e: CancellationException) {
                failed = true
                val interrupted = "Operation cancelled/interrupted by lifecycle or process shutdown. Do not automatically retry a destructive operation."
                if (label.startsWith("Flash", true) || label.equals("ADB sideload", true) || label.contains("erase", true) || label.contains("unlock", true) || label.contains("slot", true)) {
                    analyzerStatus = "BLOCKED"
                    analyzerMessage = "Firmware/destructive operation was interrupted. Inspect the target device before any retry."
                    analyzerChecks.add("BLOCKED — interrupted operation; no automatic resume or retry")
                }
                if (!closeInterruptionJournaled) finalizeJournal(label, "INTERRUPTED", interrupted)
                log("INTERRUPTED [$label]: $interrupted Last confirmed step: $lastConfirmedStep")
                throw e
            } catch (e: Exception) {
                failed = true
                val errorText = e.message ?: e.javaClass.simpleName
                if (viewModelClosing) {
                    if (!closeInterruptionJournaled) finalizeJournal(label, "INTERRUPTED", "ViewModel closed while operation was active: $errorText. Do not retry automatically.")
                    log("INTERRUPTED [$label]: ViewModel closed during operation. Last confirmed step: $lastConfirmedStep")
                } else {
                    if (label.startsWith("Flash", true) && analyzerStatus != "WARNING") {
                        analyzerStatus = "BLOCKED"
                        analyzerMessage = errorText
                        analyzerChecks.add("BLOCKED — $errorText")
                    }
                    finalizeJournal(label, "FAILED", errorText)
                    log("ERROR [$label]: $errorText Last confirmed step: $lastConfirmedStep")
                }
            } finally {
                busy = false
                pendingDestructiveConfirmation = null
                if (isFlashRun) {
                    flashOutcome = if (failed) 2 else 1
                    if (!failed) flashIndex = flashPlan.size
                }
                if (bubble) {
                    if (!failed) FlashStatus.progress = 1f
                    FlashStatus.result = if (failed) 2 else 1
                    FlashStatus.running = false
                }
            }
        }
    }

    // ---------------- cable alert ----------------

    private fun prog(f: Float) {
        progress = f
        FlashStatus.progress = f
    }

    /** Progress callback that also measures the real USB speed once per second. */
    private fun speedProbe(total: () -> Long): (Float) -> Unit {
        var t0 = System.nanoTime()
        var b0 = 0L
        return { f ->
            prog(f)
            val now = System.nanoTime()
            if (now - t0 >= 1_000_000_000L) {
                val b = (f * total()).toLong()
                val mbs = (b - b0) / 1048576.0 / ((now - t0) / 1e9)
                t0 = now
                b0 = b
                onSpeed(mbs)
            }
        }
    }

    private fun onSpeed(mbs: Double) {
        FlashStatus.speed = mbs
        if (mbs < AppSettings.slowMbs) {
            slowCount++
            if (slowCount >= AppSettings.slowSamples) raiseCable("USB transfer speed has remained below ${AppSettings.slowMbs} MiB/s for $slowCount consecutive samples. Check the cable, OTG adapter and port.")
        } else slowCount = 0
    }

    private fun raiseCable(why: String) {
        if (cableIgnored || cableWarn != null) return
        cableWarn = why
        FlashStatus.warnText = why
        FlashStatus.warn = true
        FlashStatus.warnSeq = FlashStatus.warnSeq + 1
        log("CABLE WARNING: $why")
    }

    fun cableContinue() {
        cableIgnored = true
        cableWarn = null
        FlashStatus.warn = false
        log("Cable warning ignored for this task")
    }

    fun cableChange() {
        slowCount = 0
        detachTimes.clear()
        cableWarn = null
        FlashStatus.warn = false
        log("Change the data cable, then run the task again if it failed")
    }

    // ---------------- floating bubble ----------------

    private fun startBubble() {
        if (!Settings.canDrawOverlays(ctx)) log("Floating bubble is off: allow \"Display over other apps\" for FlashForge when Android asks for it.")
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, BubbleService::class.java))
        } catch (e: Exception) {
            log("Bubble service not started: ${e.message}")
        }
    }

    fun refreshPerms() {
        overlayOk = Settings.canDrawOverlays(ctx)
        notifOk = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }

    fun toggleBubble() {
        bubbleOn = !bubbleOn
        FlashStatus.bubbleOn = bubbleOn
        prefs.edit().putBoolean("bubble", bubbleOn).apply()
    }

    /** 20 second demo: press Home while it runs to see the bubble over the launcher. */
    fun testBubble() {
        if (busy) return
        busy = true
        failed = false
        FlashStatus.label = "Bubble test"
        FlashStatus.progress = 0f
        FlashStatus.speed = 0.0
        FlashStatus.warn = false
        FlashStatus.warnText = ""
        FlashStatus.result = 0
        FlashStatus.running = true
        startBubble()
        log("Bubble test for 20 seconds. Press Home to see the bubble.")
        viewModelScope.launch {
            for (i in 1..80) {
                delay(250)
                prog(i / 80f)
                FlashStatus.speed = 18.0 + (i % 5)
            }
            FlashStatus.result = 1
            FlashStatus.running = false
            busy = false
            progress = 0f
        }
    }

    private fun need(): Fastboot = fb ?: throw IOException("No Fastboot connection. Use RECONNECT USB to re-identify the device.")

    private fun closeActiveAdb() {
        try { activeAdb?.close() } catch (e: Exception) { android.util.Log.w("FlashForge", "ADB interface cleanup failed", e) }
        try { activeAdbConnection?.close() } catch (e: Exception) { android.util.Log.w("FlashForge", "ADB USB connection cleanup failed", e) }
        activeAdb = null
        activeAdbConnection = null
    }

    private fun invalidateFastbootIfUnusable(connection: Fastboot, reason: String) {
        if (!connection.isProtocolUsable) {
            try { connection.close() } catch (e: Exception) { log("Fastboot cleanup failed: ${e.message}") }
            if (fb === connection) fb = null
            ready = false
            link = Link.YELLOW
            linkNote = "$reason Reconnect USB and verify the device again; do not retry automatically."
            log("Fastboot session invalidated: $reason")
        }
    }

    // ---------------- USB connection ----------------

    fun scan() {
        if (busy) { log("USB rescan is unavailable while an operation is running. Wait for the current result."); return }
        val d = usb.deviceList.values.firstOrNull()
        if (d == null) { if (device != null || pending || fb != null) onDetached(); return }
        if (device?.deviceId == d.deviceId && mode != Mode.NONE && (mode != Mode.FASTBOOT || fb != null)) return
        if (usb.hasPermission(d)) connect(d) else {
            val pi = PendingIntent.getBroadcast(
                ctx, 0, Intent(ACTION).setPackage(ctx.packageName),
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            pending = true
            usb.requestPermission(d, pi)
        }
        updateLink()
    }

    private fun connect(d: UsbDevice) {
        if (device?.deviceId != null && device?.deviceId != d.deviceId) {
            try { fb?.close() } catch (e: Exception) { log("Previous USB connection cleanup failed: ${e.message}") }
            fb = null
            ready = false
        }
        device = d
        safetyWarningsAcknowledged = false
        analyzerChecks.clear()
        analyzerStatus = "WARNING"
        analyzerMessage = "Device connection changed. Pre-flash checks must run again."
        mode = ModeDetector.detect(d)
        vendor = db.vendor(d.vendorId)
        usbId = hex(d.vendorId) + ":" + hex(d.productId)
        chip = ModeDetector.chipHint(mode)
        log("Detected $vendor  USB $usbId  mode ${mode.label}")
        val target = when (mode) {
            Mode.FASTBOOT -> Screen.DEVICE
            Mode.ADB -> Screen.ROM
            else -> Screen.MODES
        }
        screen = if (AppSettings.tabVisible(target)) target else Screen.DEVICE
        pending = false
        ready = false
        connecting = mode == Mode.FASTBOOT
        if (mode == Mode.FASTBOOT) io("Connect") {
            try {
                val c = usb.openDevice(d) ?: throw IOException("openDevice failed")
                val f = Fastboot(c, d, { partition, uri, requestedSize ->
                    // Re-read URI metadata at the transport boundary. A changed/replaced file
                    // or unknown provider size is blocked before Fastboot sends DOWNLOAD.
                    val (currentName, currentSize) = meta(uri)
                    if (currentSize <= 0L || currentSize != requestedSize) {
                        throw IOException("file size/identity changed or cannot be verified (queued=$requestedSize, current=$currentSize)")
                    }
                    verifyFlashGate(partition, uri, currentName, currentSize)
                }, { command -> authorizeDestructiveCommand(command) })
                try {
                    if (!f.open()) throw IOException("Cannot claim the fastboot interface")
                    fb = f
                    refreshInternal(f)
                    if (device?.deviceId != d.deviceId || usb.deviceList.values.none { it.deviceId == d.deviceId })
                        throw IOException("USB device disconnected or changed while Fastboot identification was running")
                    markReady()
                } catch (e: Exception) {
                    try { f.close() } catch (closeError: Exception) { log("Fastboot connection cleanup failed: ${closeError.message}") }
                    if (fb === f) fb = null
                    ready = false
                    throw e
                }
            } finally {
                connecting = false
            }
        } else {
            if (mode != Mode.UNKNOWN) markReady()
        }
        updateLink()
    }

    fun onDetached(detachedDevice: UsbDevice? = null) {
        if (detachedDevice != null && device?.deviceId != detachedDevice.deviceId) return
        if (device != null) detachTimes.add(System.currentTimeMillis())
        pending = false; connecting = false; ready = false
        try { fb?.close() } catch (e: Exception) { log("USB connection close reported: ${e.message}") }
        fb = null
        closeActiveAdb()
        device = null; mode = Mode.NONE; vendor = ""; usbId = ""; product = ""
        safetyWarningsAcknowledged = false
        analyzerChecks.clear()
        analyzerStatus = "BLOCKED"
        analyzerMessage = "Target device disconnected. Reconnect and identify the device before flashing."
        modelName = ""; modelNote = ""; chip = ""; slot = "?"; unlocked = "?"
        isAB = false; slotInfoKnown = false; userspace = false
        log("Device disconnected")
        updateLink()
    }

    // ---------------- device info ----------------

    private fun refreshInternal(f: Fastboot) {
        vars.clear(); parts.clear()
        val all = f.cmd("getvar:all", 20000)
        if (!all.ok) log("Device info warning: getvar:all unavailable: ${all.text}")
        all.info.forEach { l ->
            if (l.startsWith("partition-size:")) parts.add(l.removePrefix("partition-size:").trim())
            else {
                val i = l.indexOf(": ")
                if (i > 0) vars[l.substring(0, i).trim()] = l.substring(i + 2).trim()
            }
        }
        product = f.getvar("product")?.trim()?.takeIf { it.isNotBlank() && !it.equals("unknown", true) } ?: ""
        if (product.isBlank()) throw IOException("Bootloader did not provide a verifiable product ID; destructive operations remain blocked")
        val reportedSlot = f.getvar("current-slot")?.trim()?.removePrefix("_") ?: "?"
        val reportedSlotCount = f.getvar("slot-count")?.trim()?.toIntOrNull()
        slotInfoKnown = reportedSlotCount != null || reportedSlot in listOf("a", "b")
        isAB = reportedSlotCount?.let { it > 1 } ?: (reportedSlot in listOf("a", "b"))
        slot = if (slotInfoKnown) reportedSlot else "?"
        unlocked = f.getvar("unlocked") ?: "?"
        userspace = f.getvar("is-userspace")?.trim() == "yes"
        val m = db.model(product)
        if (m != null) {
            modelName = m.optString("brand") + " " + m.optString("name")
            modelNote = m.optString("note")
            chip = m.optString("chip")
        } else {
            modelName = "Not in database"
            modelNote = "Add this product ID to devices.json or update the database in the Log tab."
        }
        if (!f.isProtocolUsable) throw IOException("Fastboot communication became unsynchronized while reading device information; reconnect required")
        log("Product '$product'  slot $slot  unlocked $unlocked  A/B $isAB  fastbootd $userspace")
    }

    fun refresh() = io("Refresh") {
        val f = need()
        try { refreshInternal(f) } catch (e: Exception) {
            invalidateFastbootIfUnusable(f, "Device information refresh failed.")
            throw e
        }
    }

    fun changeExpected(s: String) {
        expected = s.trim()
        safetyWarningsAcknowledged = false
        analyzerChecks.clear()
        analyzerStatus = "WARNING"
        analyzerMessage = "Expected product ID changed. Re-run the Safety Analyzer and review warnings."
        prefs.edit().putString("expected", expected).apply()
    }

    fun acknowledgeSafetyWarnings() {
        safetyWarningsAcknowledged = true
        analyzerMessage = "Warnings explicitly acknowledged for this connected device session. Critical checks will still run before every image write."
        log("Safety Analyzer warnings explicitly acknowledged for this device session")
    }

    fun clearSafetyWarningAcknowledgement() {
        safetyWarningsAcknowledged = false
        analyzerStatus = "WARNING"
        analyzerMessage = "Safety warnings are no longer acknowledged. The next image flash will be blocked until reviewed again."
        log("Safety Analyzer warning acknowledgement cleared")
    }

    private fun guardOk(): Boolean {
        if (expected.isBlank()) {
            log("BLOCKED: expected product ID is not confirmed. Detect the device, then explicitly set the expected product ID.")
            return false
        }
        if (mode != Mode.FASTBOOT || !ready || fb == null) {
            log("BLOCKED: a ready Fastboot connection is required")
            return false
        }
        val connection = fb ?: return false
        val liveProduct = connection.getvar("product")?.trim()?.takeIf { it.isNotBlank() && !it.equals("unknown", true) }
        if (liveProduct.isNullOrBlank()) {
            invalidateFastbootIfUnusable(connection, "Live product identity could not be re-read.")
            log("BLOCKED: bootloader did not provide a live product ID")
            return false
        }
        if (!product.equals(liveProduct, true)) {
            log("Device product identity changed during this session: cached='$product', live='$liveProduct'. Reconfirm the expected product and warnings before proceeding.")
            product = liveProduct
            safetyWarningsAcknowledged = false
            analyzerChecks.clear()
            analyzerStatus = "BLOCKED"
            analyzerMessage = "Live product identity changed during this session. Reconnect/reconfirm the target before flashing."
            throw IOException("Safety Analyzer BLOCKED: live product identity changed during this session")
        }
        if (!expected.equals(liveProduct, true)) {
            log("BLOCKED: expected product '$expected' but live connected device reports '$liveProduct'")
            return false
        }
        return true
    }

    /** Returns the actual expanded partition footprint for Android sparse images, or raw size otherwise. */
    private fun expandedImageSize(uri: Uri, rawSize: Long): Long {
        val source = ctx.contentResolver.openInputStream(uri) ?: throw IOException("Cannot open image to inspect its format")
        DataInputStream(BufferedInputStream(source)).use { input ->
            val first = ByteArray(4)
            input.readFully(first)
            fun u16(bytes: ByteArray, offset: Int): Int = (bytes[offset].toInt() and 0xff) or ((bytes[offset + 1].toInt() and 0xff) shl 8)
            fun u32(bytes: ByteArray, offset: Int): Long = (bytes[offset].toLong() and 0xff) or
                ((bytes[offset + 1].toLong() and 0xff) shl 8) or
                ((bytes[offset + 2].toLong() and 0xff) shl 16) or
                ((bytes[offset + 3].toLong() and 0xff) shl 24)
            if (u32(first, 0) != 0xED26FF3AL) return rawSize
            val rest = ByteArray(24)
            input.readFully(rest)
            val header = first + rest
            val major = u16(header, 4)
            val fileHeaderSize = u16(header, 8)
            val chunkHeaderSize = u16(header, 10)
            val blockSize = u32(header, 12)
            val totalBlocks = u32(header, 16)
            val totalChunks = u32(header, 20)
            if (major != 1 || fileHeaderSize !in 28..4096 || chunkHeaderSize !in 12..4096 ||
                blockSize < 4 || blockSize > 16L * 1024 * 1024 || totalBlocks <= 0 || totalChunks <= 0 || totalChunks > 1_000_000)
                throw IOException("Malformed or unsupported Android sparse image header")
            var extraHeader = (fileHeaderSize - 28).toLong()
            while (extraHeader > 0) {
                val skipped = input.skip(extraHeader)
                if (skipped <= 0) throw IOException("Truncated sparse image file header")
                extraHeader -= skipped
            }
            var expandedBlocks = 0L
            val chunkHeader = ByteArray(chunkHeaderSize)
            val discard = ByteArray(65536)
            repeat(totalChunks.toInt()) {
                input.readFully(chunkHeader)
                val type = u16(chunkHeader, 0)
                val chunkBlocks = u32(chunkHeader, 4)
                val totalSize = u32(chunkHeader, 8)
                val payload = totalSize - chunkHeaderSize
                if (payload < 0) throw IOException("Sparse image chunk has an invalid size")
                when (type) {
                    0xCAC1 -> {
                        if (chunkBlocks <= 0 || chunkBlocks > Long.MAX_VALUE / blockSize || payload != chunkBlocks * blockSize)
                            throw IOException("Sparse RAW chunk size is inconsistent")
                        expandedBlocks += chunkBlocks
                    }
                    0xCAC2 -> {
                        if (chunkBlocks <= 0 || payload != 4L) throw IOException("Sparse FILL chunk is malformed")
                        expandedBlocks += chunkBlocks
                    }
                    0xCAC3 -> {
                        if (chunkBlocks <= 0 || payload != 0L) throw IOException("Sparse DONT_CARE chunk is malformed")
                        expandedBlocks += chunkBlocks
                    }
                    0xCAC4 -> {
                        if (chunkBlocks != 0L || payload != 4L) throw IOException("Sparse CRC32 chunk is malformed")
                    }
                    else -> throw IOException("Unsupported sparse image chunk type 0x${type.toString(16)}")
                }
                if (expandedBlocks > totalBlocks) throw IOException("Sparse image expands beyond its declared block count")
                var remaining = payload
                while (remaining > 0) {
                    val want = minOf(discard.size.toLong(), remaining).toInt()
                    val count = input.read(discard, 0, want)
                    if (count <= 0) throw IOException("Truncated sparse image chunk payload")
                    remaining -= count
                }
            }
            if (expandedBlocks != totalBlocks) throw IOException("Sparse image expanded block count does not match its header")
            if (input.read() != -1) throw IOException("Sparse image contains unexpected trailing data")
            if (totalBlocks > Long.MAX_VALUE / blockSize) throw IOException("Sparse image expanded size overflows")
            return totalBlocks * blockSize
        }
    }

    /** Common fail-closed gate used by every image write path. Requires a publisher checksum
     * previously matched through the VERIFY action, and recalculates it immediately before transfer. */
    private fun verifyFlashGate(partition: String, uri: Uri, name: String, size: Long): String {
        analyzerStatus = "RUNNING"
        analyzerMessage = "Checking live device, publisher checksum, image format, slot layout and partition compatibility..."
        analyzerChecks.clear()
        try {
            if (!guardOk()) throw IOException("Safety Analyzer BLOCKED: exact expected product ID and ready Fastboot device are required")
            analyzerChecks.add("PASS — live bootloader product ID matches the user-confirmed expected product ID")
            if (!partition.matches(Regex("[A-Za-z0-9_]{1,48}"))) throw IOException("Safety Analyzer BLOCKED: invalid partition name")
            analyzerChecks.add("PASS — target partition name is syntactically valid and explicitly selected")
            if (!name.endsWith(".img", true)) throw IOException("Safety Analyzer BLOCKED: this Fastboot image path accepts .img files only; ZIP packages must be unpacked first and other formats require a reviewed parser")
            analyzerChecks.add("PASS — supported .img file format selected")
            if (size <= 0L) throw IOException("Safety Analyzer BLOCKED: image size is unknown or empty")
            val key = uri.toString() + "|" + size
            val expectedDigest = verifiedFirmware[key] ?: run {
                val prefix = uri.toString() + "|"
                verifiedFirmware.keys.filter { it.startsWith(prefix) }.forEach { verifiedFirmware.remove(it) }
                throw IOException("Safety Analyzer BLOCKED: publisher SHA-256 is not verified for the current file size/content. Verify this exact image again before flashing.")
            }
            analyzerChecks.add("PASS — publisher SHA-256 was supplied and matched during the explicit Verify action")
            val battery = safetyBatteryPercent()
            if (battery == null || battery < AppSettings.minBattery) throw IOException("Safety Analyzer BLOCKED: controller phone battery must be at least ${AppSettings.minBattery}% (currently ${battery?.let { "$it%" } ?: "unavailable"})")
            analyzerChecks.add("PASS — controller phone battery is $battery% (minimum ${AppSettings.minBattery}%); target phone battery is not assumed")
            val q = QItem(partition, uri, name, size)
            val actual = calculateSha256(q)
            activeSha256 = actual
            writeJournal(activeOperationLabel, "RUNNING")
            if (!actual.equals(expectedDigest, true)) {
                verifiedFirmware.remove(key)
                throw IOException("Safety Analyzer BLOCKED: file changed after verification or SHA-256 mismatch")
            }
            analyzerChecks.add("PASS — SHA-256 recalculated immediately before transfer and still matches")
            val liveSlot = need().getvar("current-slot")?.trim()?.removePrefix("_") ?: "?"
            val liveSlotCount = need().getvar("slot-count")?.trim()?.toIntOrNull()
            val liveSlotKnown = liveSlotCount != null || liveSlot in listOf("a", "b")
            val liveIsAB = liveSlotCount?.let { it > 1 } ?: (liveSlot in listOf("a", "b"))
            if (!slotInfoKnown || !liveSlotKnown || liveIsAB != isAB || (slot != "?" && liveSlot != slot))
                throw IOException("Safety Analyzer BLOCKED: slot layout or active slot is unknown or changed since device identification")
            analyzerChecks.add("PASS — current slot layout and active slot were re-read from the bootloader")
            val suffix = when {
                partition.endsWith("_a", true) -> "a"
                partition.endsWith("_b", true) -> "b"
                else -> ""
            }
            val basePartition = if (suffix.isNotEmpty()) partition.dropLast(2) else partition
            if (liveIsAB) {
                val hasSlot = need().getvar("has-slot:$basePartition")?.trim()?.lowercase()
                if (hasSlot == "yes" && suffix.isEmpty()) throw IOException("Safety Analyzer BLOCKED: '$basePartition' is slot-aware; choose an explicit _a or _b partition")
                if (hasSlot == "yes" && suffix !in listOf("a", "b")) throw IOException("Safety Analyzer BLOCKED: invalid slot suffix")
                if (hasSlot == "no" && suffix.isNotEmpty()) throw IOException("Safety Analyzer BLOCKED: '$basePartition' is reported as a non-slot partition; suffixed target is ambiguous")
                if (hasSlot != "yes" && hasSlot != "no") throw IOException("Safety Analyzer BLOCKED: bootloader could not verify whether '$basePartition' is slot-aware")
            } else if (suffix.isNotEmpty()) {
                throw IOException("Safety Analyzer BLOCKED: this device is reported as non-A/B; a suffixed partition target is not accepted")
            }
            analyzerChecks.add("PASS — A/B slot requirement and explicit target slot are compatible")
            val logical = need().getvar("is-logical:$partition")?.trim()?.lowercase()
            if (logical != "yes" && logical != "no") throw IOException("Safety Analyzer BLOCKED: bootloader could not establish whether '$partition' is a logical or physical partition")
            val userspaceValue = need().getvar("is-userspace")?.trim()?.lowercase()
            if (userspaceValue != "yes" && userspaceValue != "no") throw IOException("Safety Analyzer BLOCKED: bootloader did not report whether this is bootloader Fastboot or Fastbootd")
            val liveUserspace = userspaceValue == "yes"
            userspace = liveUserspace
            if (logical == "yes" && !liveUserspace) throw IOException("Safety Analyzer BLOCKED: logical partition '$partition' requires Fastbootd; bootloader Fastboot mode is not accepted")
            analyzerChecks.add("PASS — logical/physical partition type and current Fastboot/Fastbootd mode are compatible")
            val rawSize = need().getvar("partition-size:$partition")?.trim()?.removePrefix("0x")?.removePrefix("0X")
            val capacity = rawSize?.toLongOrNull(16)
                ?: throw IOException("Safety Analyzer BLOCKED: bootloader did not verify partition '$partition' size")
            val expandedSize = expandedImageSize(uri, size)
            if (capacity <= 0L || expandedSize > capacity)
                throw IOException("Safety Analyzer BLOCKED: image expands to $expandedSize bytes but verified partition capacity is $capacity bytes")
            analyzerChecks.add("PASS — image expanded size $expandedSize bytes fits bootloader-reported partition capacity $capacity bytes")
            lastConfirmedStep = "Exact device identity, publisher checksum, slot/layout and partition capacity verified; no partition write has started yet"
            writeJournal(activeOperationLabel, "RUNNING")
            if (analyzerWarnings.isNotEmpty() && !safetyWarningsAcknowledged) {
                analyzerStatus = "WARNING"
                analyzerMessage = "Critical checks passed, but the warnings below must be reviewed and explicitly acknowledged before any write."
                analyzerChecks.add("WARNING — explicit warning acknowledgement is required; no DOWNLOAD or FLASH command has been issued")
                throw IOException("Safety Analyzer WARNING: review and acknowledge the unresolved compatibility/source warnings on the Safety Analyzer page before flashing")
            }
            analyzerStatus = if (analyzerWarnings.isEmpty()) "PASS" else "WARNING"
            analyzerMessage = if (analyzerWarnings.isEmpty())
                "All implemented critical checks passed. This is not a guarantee against unknown hardware or firmware risks."
            else
                "Critical checks passed. Warnings were explicitly acknowledged for this device session; unresolved compatibility/source limits remain."
            if (analyzerWarnings.isNotEmpty()) analyzerChecks.add("WARNING — user explicitly acknowledged the unresolved warnings; proceeding does not remove those risks")
            return actual
        } catch (e: Exception) {
            if (e.message?.startsWith("Safety Analyzer WARNING") != true) {
                analyzerStatus = "BLOCKED"
                analyzerMessage = e.message ?: "A required pre-flash check failed"
                analyzerChecks.add("BLOCKED — ${analyzerMessage}")
            }
            throw e
        }
    }

    fun adoptDetectedProduct() {
        if (product.isBlank() || mode != Mode.FASTBOOT) { log("Cannot adopt product ID: no identified Fastboot device"); return }
        changeExpected(product)
        log("Expected product ID set to '$product'. Confirm that this is the intended target before flashing.")
    }

    fun safetyBatteryPercent(): Int? {
        val intent = ctx.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED)) ?: return null
        val level = intent.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1)
        return if (level >= 0 && scale > 0) (level * 100 / scale) else null
    }

    // ---------------- fastboot commands ----------------

    private fun authorizeDestructiveCommand(command: String) {
        val c = command.trim()
        if (pendingDestructiveConfirmation != c) throw IOException("explicit in-app confirmation is required for '$c'")
        pendingDestructiveConfirmation = null
        if (!guardOk()) throw IOException("exact expected product ID and ready Fastboot device are required")
        val battery = safetyBatteryPercent()
        if (battery == null || battery < AppSettings.minBattery) throw IOException("controller phone battery must be at least ${AppSettings.minBattery}% for destructive commands")
        when {
            c.equals("flashing lock", true) || c.equals("oem lock", true) ->
                throw IOException("bootloader locking is disabled until stock-compatible firmware and device-specific relock requirements can be independently verified")
            c.startsWith("create-logical-partition:", true) || c.startsWith("resize-logical-partition:", true) || c.startsWith("delete-logical-partition:", true) || c.startsWith("update-super:", true) || c.startsWith("partition:", true) ->
                throw IOException("logical/super partition modification is disabled: this build cannot prove metadata geometry, group limits and device-specific recovery requirements")
            c.startsWith("erase:", true) -> {
                val part = c.substringAfter(':')
                if (!part.matches(Regex("[A-Za-z0-9_]{1,48}"))) throw IOException("invalid partition name")
                val liveSlot = need().getvar("current-slot")?.trim()?.removePrefix("_") ?: "?"
                val liveCount = need().getvar("slot-count")?.trim()?.toIntOrNull()
                val liveSlotKnown = liveCount != null || liveSlot in listOf("a", "b")
                val liveIsAB = liveCount?.let { it > 1 } ?: (liveSlot in listOf("a", "b"))
                if (!slotInfoKnown || !liveSlotKnown || liveIsAB != isAB || (slot != "?" && liveSlot != slot))
                    throw IOException("slot layout is unknown or changed; erase is blocked")
                val suffix = when { part.endsWith("_a", true) -> "a"; part.endsWith("_b", true) -> "b"; else -> "" }
                val base = if (suffix.isNotEmpty()) part.dropLast(2) else part
                if (liveIsAB) {
                    val hasSlot = need().getvar("has-slot:$base")?.trim()?.lowercase()
                    if (hasSlot == "yes" && suffix.isEmpty()) throw IOException("slot-aware partition erase requires explicit _a or _b target")
                    if (hasSlot == "no" && suffix.isNotEmpty()) throw IOException("partition is not slot-aware; suffixed erase target is blocked")
                    if (hasSlot != "yes" && hasSlot != "no") throw IOException("bootloader could not verify erase partition slot layout")
                } else if (suffix.isNotEmpty()) throw IOException("non-A/B device cannot erase a suffixed partition target")
                val logical = need().getvar("is-logical:$part")?.trim()?.lowercase()
                if (logical != "no") throw IOException("logical or unverified partition erase is disabled")
                val raw = need().getvar("partition-size:$part")?.trim()?.removePrefix("0x")?.removePrefix("0X")
                val bytes = raw?.toLongOrNull(16) ?: throw IOException("bootloader did not confirm that partition '$part' exists and has a readable size")
                if (bytes <= 0L) throw IOException("partition size is invalid")
            }
            c.equals("flashing unlock", true) || c.equals("oem unlock", true) -> {
                val liveUnlocked = need().getvar("unlocked")?.trim()?.lowercase()
                if (liveUnlocked == "yes" || liveUnlocked == "true") throw IOException("Bootloader already reports unlocked; refusing a redundant unlock command")
                if (liveUnlocked != "no" && liveUnlocked != "false") throw IOException("Bootloader unlock state is unknown; refusing unlock")
                val ability = need().getvar("unlock_ability")?.trim()?.lowercase()
                if (ability !in setOf("1", "yes", "true")) throw IOException("Bootloader did not positively confirm unlock_ability; device-specific unlock is blocked")
            }
            c.startsWith("set_active:", true) -> {
                val target = c.substringAfter(':').lowercase()
                val liveCount = need().getvar("slot-count")?.trim()?.toIntOrNull()
                if (liveCount == null || liveCount <= 1 || target !in listOf("a", "b"))
                    throw IOException("slot change is unsupported or slot-count could not be verified")
            }
            c.startsWith("format:", true) || c.startsWith("wipe:", true) ->
                throw IOException("format/wipe command is not implemented as a reviewed device-specific operation")
            else -> throw IOException("unrecognized destructive Fastboot command is blocked")
        }
    }

    /** Called only by explicit confirmation controls; the token is one-shot and command-specific. */
    fun confirmedFbCmd(c: String) {
        if (busy) { log("Busy. Destructive command was not queued."); return }
        pendingDestructiveConfirmation = c.trim()
        fbCmd(c)
    }

    fun fbCmd(c: String) = io(c) {
        val normalized = c.trim()
        val safeReadOrReboot = normalized.equals("reboot", true) || normalized.equals("reboot-bootloader", true) ||
            normalized.equals("reboot-recovery", true) || normalized.equals("reboot-fastboot", true) ||
            normalized.startsWith("getvar:", true)
        val destructive = normalized.startsWith("erase:", true) || normalized.startsWith("flashing unlock", true) ||
            normalized.startsWith("oem ", true) || normalized.startsWith("set_active:", true) ||
            normalized.startsWith("create-logical-partition:", true) || normalized.startsWith("resize-logical-partition:", true) ||
            normalized.startsWith("delete-logical-partition:", true) || normalized.startsWith("format:", true) || normalized.startsWith("wipe:", true) ||
            normalized.startsWith("flashing lock", true) || normalized.startsWith("download:", true) || normalized.startsWith("flash:", true)
        if (!safeReadOrReboot && !destructive) throw IOException("Unsupported raw Fastboot command is blocked")
        if (destructive && pendingDestructiveConfirmation != normalized) throw IOException("Explicit confirmation is required")
        val connection = need()
        if (destructive) {
            lastConfirmedStep = "Explicit confirmation received; destructive command '$normalized' is about to be issued"
            writeJournal(activeOperationLabel, "RUNNING")
        }
        val r = connection.cmd(normalized, 120000)
        log("> $normalized => ${if (r.ok) "OKAY" else "FAIL"} ${r.text}")
        r.info.forEach { log("  $it") }
        if (!r.ok) {
            invalidateFastbootIfUnusable(connection, "Fastboot command '$normalized' failed.")
            throw IOException("Fastboot rejected '$normalized': ${r.text}")
        }
        lastConfirmedStep = "Fastboot returned OKAY for: $normalized"
        writeJournal(activeOperationLabel, "RUNNING")
    }

    fun changeSlot(s: String) {
        val target = s.lowercase()
        val command = "set_active:$target"
        if (busy) { log("Busy. Slot change was not queued."); return }
        pendingDestructiveConfirmation = command
        io("Slot change") {
            if (!guardOk()) throw IOException("BLOCKED: exact device identity is required")
            val f = need()
            lastConfirmedStep = "Explicitly confirmed active-slot change; set_active command is about to be issued"
            writeJournal(activeOperationLabel, "RUNNING")
            val result = f.cmd(command)
            if (!result.ok) {
                invalidateFastbootIfUnusable(f, "Slot change command failed.")
                throw IOException("Fastboot rejected slot change: ${result.text}")
            }
            lastConfirmedStep = "Bootloader returned OKAY for $command; verifying current-slot response"
            writeJournal(activeOperationLabel, "RUNNING")
            val actual = f.getvar("current-slot")?.trim()?.removePrefix("_") ?: "?"
            if (actual != target) {
                invalidateFastbootIfUnusable(f, "Active slot could not be re-verified after the slot command.")
                throw IOException("Slot change was acknowledged but current-slot verification returned '$actual', expected '$target'. Do not assume the slot changed.")
            }
            slot = actual
            lastConfirmedStep = "Bootloader confirmed active slot $actual"
            writeJournal(activeOperationLabel, "RUNNING")
            log("Active slot verified as $actual")
        }
    }

    fun wipe() = io("Wipe", true) {
        if (!guardOk()) throw IOException("BLOCKED: device identity is not verified")
        val f = need()
        val first = "erase:userdata"
        pendingDestructiveConfirmation = first
        lastConfirmedStep = "Explicitly confirmed userdata erase; command is about to be issued"
        writeJournal("Wipe", "RUNNING")
        val a = f.cmd(first, 120000)
        log("$first => ${if (a.ok) "OKAY" else "FAIL " + a.text}")
        if (!a.ok) {
            invalidateFastbootIfUnusable(f, "Userdata erase failed.")
            throw IOException("Wipe stopped after userdata erase failed: ${a.text}. Metadata erase was NOT attempted.")
        }
        lastConfirmedStep = "userdata erase returned OKAY"
        writeJournal("Wipe", "RUNNING")
        val second = "erase:metadata"
        pendingDestructiveConfirmation = second
        lastConfirmedStep = "Userdata erase returned OKAY; metadata erase is about to be issued"
        writeJournal("Wipe", "RUNNING")
        val b = f.cmd(second, 60000)
        log("$second => ${if (b.ok) "OKAY" else "FAIL " + b.text}")
        if (!b.ok) {
            invalidateFastbootIfUnusable(f, "Metadata erase failed after userdata erase succeeded.")
            throw IOException("userdata erase succeeded but metadata erase failed: ${b.text}. Do not repeat automatically.")
        }
        lastConfirmedStep = "userdata and metadata erase returned OKAY"
        writeJournal("Wipe", "RUNNING")
    }

    private fun meta(uri: Uri): Pair<String, Long> {
        var name = uri.lastPathSegment?.substringAfterLast('/')?.ifBlank { null } ?: "file"
        var size = -1L
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0) name = c.getString(ni) ?: name
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        } catch (e: Exception) { throw IOException("Cannot read selected file metadata: ${e.message}", e) }
        if (uri.scheme == "file") {
            val f = File(uri.path ?: throw IOException("Invalid file URI"))
            if (!f.isFile || !f.canRead()) throw IOException("Selected file does not exist or is unreadable")
            name = f.name
            size = f.length()
        } else if (size <= 0L) {
            try { ctx.contentResolver.openFileDescriptor(uri, "r")?.use { descriptor -> size = descriptor.statSize } }
            catch (e: Exception) { throw IOException("Cannot determine selected file size: ${e.message}", e) }
        }
        if (size <= 0L) throw IOException("File size is missing, zero, or unavailable; select a readable local firmware file")
        return Pair(name, size)
    }

    /** Single application-level route for every image flash (single-image, recovery, boot, queue).
     * Fastboot independently invokes the mandatory authorization callback again at the USB
     * transport boundary immediately before issuing DOWNLOAD, providing defense in depth.
     */
    private fun executeVerifiedFlash(f: Fastboot, partition: String, uri: Uri, name: String, size: Long) {
        if (size <= 0L) throw IOException("Safety Analyzer BLOCKED: image size is unknown or empty")
        activeFileName = name
        activePartition = partition
        activeSha256 = ""
        log("Safety Analyzer: evaluating $name -> $partition")
        analyzerStatus = "RUNNING"
        analyzerMessage = "Mandatory pre-flash checks are running for $name → $partition."
        lastConfirmedStep = "Pre-flash checks pending; no write has started"
        writeJournal(activeOperationLabel, "RUNNING")
        val result = try {
            f.flash(partition, ctx.contentResolver, uri, size, speedProbe { size }) { step ->
                lastConfirmedStep = step
                writeJournal(activeOperationLabel, "RUNNING")
            }
        } catch (e: Exception) {
            analyzerStatus = "BLOCKED"
            analyzerMessage = "Unexpected Fastboot transport exception: ${e.message}. No automatic retry was issued."
            analyzerChecks.add("BLOCKED — ${analyzerMessage}")
            invalidateFastbootIfUnusable(f, "Unexpected Fastboot transport exception.")
            throw e
        }
        lastConfirmedStep = if (result.ok) "Bootloader returned OKAY for flash:$partition" else "Flash did not complete successfully: ${result.text}"
        result.info.forEach { log("  $it") }
        log("flash $name -> $partition => ${if (result.ok) "OKAY" else "FAIL " + result.text}")
        if (!result.ok) {
            if (result.text.contains("Safety Analyzer WARNING")) {
                analyzerStatus = "WARNING"
                analyzerMessage = "Critical checks passed, but explicit warning acknowledgement is still required. No DOWNLOAD or FLASH command was issued."
                analyzerChecks.add("WARNING — explicit acknowledgement is required before any write")
            } else {
                analyzerStatus = "BLOCKED"
                analyzerMessage = "Flash transfer/bootloader operation failed: ${result.text}. No automatic retry was issued."
                analyzerChecks.add("BLOCKED — ${analyzerMessage}")
            }
            invalidateFastbootIfUnusable(f, "Fastboot transfer failed or protocol state is uncertain.")
            throw IOException("Flash stopped; no further destructive command or automatic retry was issued: ${result.text}")
        }
        lastConfirmedStep = "Bootloader returned OKAY for flash:$partition"
        analyzerMessage = "Bootloader returned OKAY for $partition. ${analyzerMessage}"
        writeJournal(activeOperationLabel, "RUNNING")
    }

    fun flashOne(part: String, uri: Uri) = io("Flash", true) {
        analyzerStatus = "RUNNING"
        analyzerMessage = "Preparing mandatory pre-flash checks..."
        val (n, s) = meta(uri)
        flashPlan.clear()
        flashPlan.add(QItem(part.trim(), uri, n, s))
        flashIndex = 0
        executeVerifiedFlash(need(), part.trim(), uri, n, s)
    }

    /** vbmeta auto-patching weakens Android Verified Boot; intentionally fail closed. */
    fun flashVbmeta(uri: Uri) = io("VBMETA safety block", true) {
        throw IOException("BLOCKED: automatic vbmeta patching is disabled. It can weaken Android Verified Boot. Use a device-specific reviewed procedure and an unmodified, publisher-verified image.")
    }

    fun backup(p: String) = io("Backup", true) {
        if (!guardOk()) throw IOException("BLOCKED: exact device identity is required before backup")
        if (!p.matches(Regex("[A-Za-z0-9_]{1,48}"))) throw IOException("Invalid partition name")
        val dir = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "backups")
        if (!dir.exists() && !dir.mkdirs()) throw IOException("Cannot create backup directory")
        val base = "${product}_${p}_${System.currentTimeMillis()}.img"
        val out = File(dir, base)
        val temp = File(dir, "$base.partial")
        val metadata = File(dir, out.name + ".json")
        val metadataTempFile = File(dir, out.name + ".json.partial")
        var tempCreated = false
        var metadataTempCreated = false
        var finalizedBackup: File? = null
        var total = -1L
        try {
            if (out.exists() || metadata.exists()) throw IOException("Refusing to overwrite an existing backup or metadata file")
            if (!temp.createNewFile()) throw IOException("A temporary backup file with this name already exists; refusing overwrite")
            tempCreated = true
            val connection = need()
            if (!slotInfoKnown) throw IOException("Bootloader slot layout is unknown; backup target is ambiguous")
            val suffix = when { p.endsWith("_a", true) -> "a"; p.endsWith("_b", true) -> "b"; else -> "" }
            val base = if (suffix.isNotEmpty()) p.dropLast(2) else p
            if (isAB) {
                val hasSlot = connection.getvar("has-slot:$base")?.trim()?.lowercase()
                if (hasSlot == "yes" && suffix.isEmpty()) throw IOException("Backup of slot-aware partition requires explicit _a or _b target")
                if (hasSlot == "no" && suffix.isNotEmpty()) throw IOException("Partition is not slot-aware; suffixed backup target is blocked")
                if (hasSlot != "yes" && hasSlot != "no") throw IOException("Bootloader could not verify backup partition slot layout")
            } else if (suffix.isNotEmpty()) throw IOException("Non-A/B device cannot back up a suffixed partition target")
            val logical = connection.getvar("is-logical:$p")?.trim()?.lowercase()
            if (logical != "no") throw IOException("Logical or unverified partition backup is not supported by this backup path")
            val expectedSizeRaw = connection.getvar("partition-size:$p")?.trim()?.removePrefix("0x")?.removePrefix("0X")
            val expectedPartitionSize = expectedSizeRaw?.toLongOrNull(16)
                ?: throw IOException("Bootloader did not verify the size of partition '$p'; backup is blocked")
            if (expectedPartitionSize <= 0L) throw IOException("Bootloader reported an invalid partition size")
            if (dir.usableSpace < expectedPartitionSize) throw IOException("Not enough free storage for this partition backup: need $expectedPartitionSize bytes, available ${dir.usableSpace}")
            lastConfirmedStep = "Partition size verified; backup fetch is about to begin"
            activePartition = p
            writeJournal(activeOperationLabel, "RUNNING")
            val r = temp.outputStream().use { stream ->
                connection.fetch(p, stream, { n -> total = n }, speedProbe { maxOf(total, 0L) })
            }
            if (!r.ok) {
                invalidateFastbootIfUnusable(connection, "Backup transfer was interrupted.")
                throw IOException("Partition read failed; backup is not available: ${r.text}")
            }
            if (total <= 0L || total != expectedPartitionSize || temp.length() != total)
                throw IOException("Backup size verification failed: bootloader partition=$expectedPartitionSize, fetch=$total, saved=${temp.length()}")
            val digest = sha256File(temp)
            if (!temp.renameTo(out)) throw IOException("Could not finalize backup file")
            tempCreated = false
            finalizedBackup = out
            if (metadata.exists() || !metadataTempFile.createNewFile()) throw IOException("Could not reserve a unique backup metadata file; refusing overwrite")
            metadataTempCreated = true
            metadataTempFile.writeText(JSONObject().put("product", product).put("partition", p).put("size", out.length()).put("sha256", digest).put("created", System.currentTimeMillis()).toString(2))
            if (!metadataTempFile.renameTo(metadata)) throw IOException("Could not safely finalize backup metadata")
            metadataTempCreated = false
            lastConfirmedStep = "Partition $p fetched and backup SHA-256 verified"
            activeFileName = out.name
            activePartition = p
            activeSha256 = digest
            writeJournal(activeOperationLabel, "RUNNING")
            log("backup $p => OKAY ${out.absolutePath}; SHA-256 $digest")
        } catch (e: Exception) {
            if (tempCreated && temp.exists()) temp.delete()
            if (metadataTempCreated && metadataTempFile.exists()) metadataTempFile.delete()
            finalizedBackup?.delete()
            throw e
        }
    }

    private fun sha256File(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buf = ByteArray(65536)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                if (n == 0) throw IOException("Zero-byte read while calculating backup SHA-256")
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    // ---------------- queue, hash, profiles ----------------

    fun addFile(uri: Uri, part: String) {
        try {
            try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            catch (e: Exception) { log("Persistent URI permission unavailable; this file may need to be selected again after app restart: ${e.message}") }
            val (n, s) = meta(uri)
            queue.add(QItem(part.trim(), uri, n, s))
            log("Added $n to queue. Target partition remains explicit: ${part.ifBlank { "NOT SELECTED" }}")
        } catch (e: Exception) {
            log("Could not add selected firmware file: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    fun setQueuePartition(index: Int, partition: String) {
        if (index in queue.indices) queue[index] = queue[index].copy(part = partition.trim())
    }

    fun move(i: Int) {
        if (i > 0 && i < queue.size) {
            val x = queue.removeAt(i)
            queue.add(i - 1, x)
        }
    }

    /** Flashes every enabled queue file in order, or only the file at index [only] when given. */
    fun flashQueue(only: Int? = null) = io("Flash queue", true) {
        analyzerStatus = "RUNNING"
        analyzerMessage = "Preparing mandatory pre-flash checks for the queue..."
        val items: List<QItem> = if (only != null) listOfNotNull(queue.getOrNull(only)) else queue.filter { it.enabled }
        if (items.isEmpty()) {
            analyzerStatus = "BLOCKED"
            analyzerMessage = "No file is selected for flashing; no image can be analyzed or flashed."
            analyzerChecks.add("BLOCKED — no file selected in the flash queue")
            throw IOException("No file is selected in the flash queue")
        }
        flashPlan.clear()
        flashPlan.addAll(items)
        flashIndex = 0
        val f = need()
        items.forEachIndexed { i, q ->
            flashIndex = i
            log("[${i + 1}/${items.size}] Preparing ${q.name} -> ${q.part}; mandatory safety gate will run inside Fastboot before DOWNLOAD")
            executeVerifiedFlash(f, q.part, q.uri, q.name, q.size)
        }
        if (queue.size > items.size) log("${queue.size - items.size} queue file(s) were skipped by the user")
        log("Queue finished")
    }

    private fun calculateSha256(q: QItem, showProgress: Boolean = false): String {
        val md = MessageDigest.getInstance("SHA-256")
        val ins = ctx.contentResolver.openInputStream(q.uri) ?: throw IOException("cannot open file")
        var total = 0L
        ins.use { stream ->
            val b = ByteArray(65536)
            while (true) {
                val n = stream.read(b)
                if (n < 0) break
                if (n == 0) throw IOException("File provider returned a zero-byte read while hashing; retry with a different local copy")
                md.update(b, 0, n)
                total += n
                if (showProgress) prog(total.toFloat() / maxOf(q.size, 1L))
            }
        }
        if (q.size > 0 && total != q.size) throw IOException("File size changed or metadata mismatch: expected ${q.size}, read $total bytes")
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    fun hash(q: QItem, expect: String) = io("SHA-256") {
        if (!q.name.endsWith(".img", true)) throw IOException("Only .img files can be verified for the Fastboot image queue. Unpack ZIP packages first.")
        val expectedHash = expect.trim().lowercase()
        if (!expectedHash.matches(Regex("[0-9a-f]{64}"))) {
            verifiedFirmware.remove(q.uri.toString() + "|" + q.size)
            throw IOException("Enter a valid 64-character SHA-256 checksum from the firmware publisher before verification")
        }
        val actual = calculateSha256(q, showProgress = true)
        log("SHA-256 ${q.name}: $actual")
        val key = q.uri.toString() + "|" + q.size
        if (actual == expectedHash) {
            verifiedFirmware[key] = actual
            log("VERIFIED: SHA-256 matches publisher checksum for ${q.name}")
        } else {
            verifiedFirmware.remove(key)
            throw IOException("SHA-256 MISMATCH for ${q.name}. Do not flash this file.")
        }
    }

    fun verifyStandaloneImage(uri: Uri, publisherChecksum: String) = io("Standalone image SHA-256") {
        val prefix = uri.toString() + "|"
        val expectedHash = publisherChecksum.trim().lowercase()
        if (!expectedHash.matches(Regex("[0-9a-f]{64}"))) {
            verifiedFirmware.keys.filter { it.startsWith(prefix) }.forEach { verifiedFirmware.remove(it) }
            throw IOException("Enter a valid 64-character SHA-256 checksum published by the firmware provider")
        }
        val (name, size) = meta(uri)
        if (!name.endsWith(".img", true)) throw IOException("Only .img files can be verified for standalone Fastboot flashing")
        val item = QItem("", uri, name, size)
        val actual = calculateSha256(item, showProgress = true)
        val key = uri.toString() + "|" + size
        if (!actual.equals(expectedHash, true)) {
            verifiedFirmware.remove(key)
            throw IOException("SHA-256 MISMATCH for $name. This image cannot be flashed.")
        }
        verifiedFirmware[key] = actual
        log("VERIFIED standalone image $name: publisher checksum matches local SHA-256 $actual")
    }

    fun isImageVerified(uri: Uri?): Boolean {
        if (uri == null) return false
        val prefix = uri.toString() + "|"
        return verifiedFirmware.keys.any { it.startsWith(prefix) }
    }

    fun saveQueue(name: String) {
        if (name.isBlank()) { log("Enter a profile name"); return }
        val a = JSONArray()
        queue.forEach { a.put(JSONObject().put("p", it.part).put("u", it.uri.toString()).put("n", it.name).put("s", it.size)) }
        prefs.edit().putString("q:$name", a.toString()).apply()
        log("Saved profile '$name' with ${queue.size} item(s)")
    }

    fun loadQueue(name: String) {
        val raw = prefs.getString("q:$name", null)
        if (raw == null) { log("No profile '$name'"); return }
        try {
            val parsed = ArrayList<QItem>()
            val a = JSONArray(raw)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val part = o.optString("p", "").trim()
                val uri = Uri.parse(o.getString("u"))
                val itemName = o.getString("n")
                val size = o.getLong("s")
                if (size <= 0L || itemName.isBlank() || uri.scheme.isNullOrBlank()) throw IOException("Invalid queue profile entry at index $i")
                parsed.add(QItem(part, uri, itemName, size))
            }
            queue.clear()
            queue.addAll(parsed)
            log("Loaded profile '$name' with ${parsed.size} item(s). Partition names remain explicit and are not inferred from filenames.")
        } catch (e: Exception) {
            log("Queue profile '$name' is invalid and was not loaded: ${e.message}")
        }
    }

    fun profileNames(): List<String> = prefs.all.keys.filter { it.startsWith("q:") }.map { it.removePrefix("q:") }

    // ---------------- firmware files ----------------

    private fun unzipInternal(uri: Uri) {
        val dir = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "fw")
        if (!dir.exists() && !dir.mkdirs()) throw IOException("Cannot create firmware directory")
        val stage = File(dir, ".extract-${System.currentTimeMillis()}-${System.nanoTime()}")
        if (!stage.mkdirs()) throw IOException("Cannot create temporary extraction directory")
        val staged = ArrayList<Pair<File, String>>()
        val committed = ArrayList<File>()
        try {
            val raw = ctx.contentResolver.openInputStream(uri) ?: throw IOException("cannot open zip")
            ZipInputStream(raw.buffered()).use { z ->
                var e = z.nextEntry
                var entries = 0
                var totalBytes = 0L
                while (e != null) {
                    entries++
                    if (entries > 512) throw IOException("ZIP contains too many entries (limit 512)")
                    if (!e.isDirectory && e.name.endsWith(".img", ignoreCase = true)) {
                        val n = e.name.substringAfterLast('/').substringAfterLast('\\')
                        if (!n.matches(Regex("[A-Za-z0-9._-]{1,120}\\.img", RegexOption.IGNORE_CASE)) || n == ".img" || n.startsWith("."))
                            throw IOException("Invalid or unsafe image filename in ZIP: $n")
                        if (staged.any { it.second.equals(n, true) }) throw IOException("ZIP contains duplicate image filename: $n")
                        val f = File(stage, n)
                        var written = 0L
                        f.outputStream().buffered().use { o ->
                            val buf = ByteArray(65536)
                            while (true) {
                                val count = z.read(buf)
                                if (count < 0) break
                                if (count == 0) throw IOException("ZIP stream returned a zero-byte read")
                                written += count
                                totalBytes += count
                                if (written > 1024L * 1024 * 1024 || totalBytes > 4L * 1024 * 1024 * 1024)
                                    throw IOException("ZIP extraction size limit exceeded")
                                o.write(buf, 0, count)
                            }
                        }
                        if (written <= 0L || f.length() != written) throw IOException("Empty or incomplete image entry: $n")
                        staged.add(f to n)
                    }
                    z.closeEntry()
                    e = z.nextEntry
                }
            }
            if (staged.isEmpty()) throw IOException("ZIP contains no supported .img files")
            // Commit only after every image has been fully read and ZIP CRC validation succeeded.
            val now = System.currentTimeMillis()
            staged.forEachIndexed { index, pair ->
                val source = pair.first
                val originalName = pair.second
                val stem = originalName.substringBeforeLast('.')
                var dest = File(dir, originalName)
                if (dest.exists()) dest = File(dir, "${stem}_${now}_$index.img")
                if (dest.exists() || !source.renameTo(dest)) throw IOException("Could not safely finalize extracted image: $originalName")
                committed.add(dest)
            }
            val stagedQueueItems = committed.map { file -> QItem("", Uri.fromFile(file), file.name, file.length()) }
            queue.addAll(stagedQueueItems)
            stagedQueueItems.forEach { item -> log("Unpacked ${item.name} (${item.size / 1024} KB); partition must be selected explicitly") }
        } catch (e: Exception) {
            committed.forEach { it.delete() }
            throw IOException("Firmware ZIP extraction was not committed; no extracted images were added to the flash queue: ${e.message}", e)
        } finally {
            if (stage.exists() && !stage.deleteRecursively()) log("Warning: temporary extraction directory could not be fully removed: ${stage.name}")
        }
    }

    fun unzipToQueue(uri: Uri) = io("Unpack") { unzipInternal(uri) }

    /** Folder where every downloaded or unpacked firmware file is kept. */
    fun fwDir(): File = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "fw").also { if (!it.exists()) it.mkdirs() }

    /** Brand of the connected phone (from the model database, else from the USB vendor) and its firmware sites. */
    fun brandName(): String = db.model(product)?.optString("brand")?.ifBlank { null } ?: vendor
    fun brandLinks(): List<Pair<String, String>> = db.brandLinks(brandName())

    fun fwLinks(): List<Pair<String, String>> = db.firmware(product)

    fun fwFiles(): List<File> =
        fwDir().listFiles { f -> f.isFile && (f.name.endsWith(".img") || f.name.endsWith(".zip")) }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()

    /** Take a file from the firmware folder into the flash queue (zip files are unpacked). */
    fun useFwFile(f: File) {
        if (f.name.endsWith(".zip")) unzipToQueue(Uri.fromFile(f))
        else if (f.isFile && f.canRead() && f.length() > 0 && queue.none { it.name == f.name })
            queue.add(QItem("", Uri.fromFile(f), f.name, f.length()))
    }

    fun download(url: String) = io("Download", true) {
        var current = URL(url)
        if (!current.protocol.equals("https", true)) throw IOException("Firmware downloads require HTTPS")
        var c: HttpURLConnection? = null
        var finalResponse: HttpURLConnection? = null
        try {
            var redirects = 0
            while (true) {
                if (!current.protocol.equals("https", true)) throw IOException("HTTPS redirect to a non-HTTPS URL was blocked")
                c = current.openConnection() as HttpURLConnection
                c.instanceFollowRedirects = false
                c.connectTimeout = 15000
                c.readTimeout = 30000
                val status = c.responseCode
                if (status in 300..399) {
                    val location = c.getHeaderField("Location") ?: throw IOException("Redirect response has no Location header")
                    c.disconnect()
                    redirects++
                    if (redirects > 5) throw IOException("Too many firmware download redirects")
                    current = URL(current, location)
                    continue
                }
                if (status !in 200..299) throw IOException("Firmware server returned HTTP $status")
                finalResponse = c
                break
            }
            val response = finalResponse ?: throw IOException("No firmware download response")
            val total = response.contentLengthLong
            if (total <= 0L) throw IOException("Firmware server did not provide a trustworthy Content-Length; refusing an unverifiable/incomplete download")
            var name = current.path.substringAfterLast('/').ifBlank { "download.bin" }.replace(Regex("[^A-Za-z0-9._-]"), "_")
            if (name == "." || name == ".." || name.isBlank()) name = "download.bin"
            val dir = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "fw")
            if (!dir.exists() && !dir.mkdirs()) throw IOException("Cannot create firmware directory")
            if (total > 0 && dir.usableSpace < total) throw IOException("Not enough storage for this download")
            val temp = File(dir, ".$name.${System.currentTimeMillis()}.download")
            var tempCreated = false
            var finalizedTarget: File? = null
            var downloaded = 0L
            try {
                if (!temp.createNewFile()) throw IOException("A temporary download file with this name already exists; refusing overwrite")
                tempCreated = true
                response.inputStream.use { input ->
                    temp.outputStream().buffered().use { output ->
                        val b = ByteArray(65536)
                        while (true) {
                            val n = input.read(b)
                            if (n < 0) break
                            if (n == 0) throw IOException("Download stream returned a zero-byte read")
                            downloaded += n
                            if (downloaded > 4L * 1024 * 1024 * 1024) throw IOException("Download exceeds the 4 GiB safety limit")
                            output.write(b, 0, n)
                            if (total > 0) prog(downloaded.toFloat() / total)
                        }
                    }
                }
                if (total > 0 && downloaded != total) throw IOException("Incomplete download: expected $total bytes, received $downloaded")
                if (downloaded <= 0L || temp.length() != downloaded) throw IOException("Downloaded file is empty or incomplete")
                var target = File(dir, name)
                if (target.exists()) target = File(dir, "${name.substringBeforeLast('.', name)}_${System.currentTimeMillis()}${name.substringAfterLast('.', "").let { if (it.isBlank()) "" else ".$it" }}")
                if (target.exists() || !temp.renameTo(target)) throw IOException("Could not safely finalize downloaded file")
                tempCreated = false
                finalizedTarget = target
                log("Downloaded ${target.name} (${downloaded} bytes) from HTTPS")
                if (target.name.endsWith(".zip", true)) unzipInternal(Uri.fromFile(target))
                else queue.add(QItem("", Uri.fromFile(target), target.name, target.length()))
                finalizedTarget = null
            } catch (e: Exception) {
                if (tempCreated && temp.exists()) temp.delete()
                finalizedTarget?.delete()
                throw e
            }
        } finally {
            finalResponse?.disconnect()
            c?.disconnect()
        }
    }

    // ---------------- ADB sideload ----------------

    fun sideload(uri: Uri, publisherChecksum: String) = io("ADB sideload", true) {
        val expectedHash = publisherChecksum.trim().lowercase()
        if (!expectedHash.matches(Regex("[0-9a-f]{64}"))) throw IOException("A trusted publisher SHA-256 checksum is required for ADB sideload")
        val controllerBattery = safetyBatteryPercent()
        if (controllerBattery == null || controllerBattery < AppSettings.minBattery) throw IOException("Controller phone battery must be at least ${AppSettings.minBattery}% for firmware sideload")
        if (expected.isBlank()) throw IOException("Confirm the intended target product ID in FlashForge before starting Recovery Sideload")
        if (mode != Mode.ADB) throw IOException("ADB sideload requires an ADB-interface device. Normal Android ADB/Fastboot modes are not assumed to be Recovery Sideload.")
        val d = device ?: throw IOException("No USB device")
        val (n, s) = meta(uri)
        if (!n.endsWith(".zip", true)) throw IOException("Recovery ADB sideload accepts ZIP update packages only")
        activeFileName = n
        activePartition = "recovery-adb-sideload"
        activeSha256 = expectedHash
        lastConfirmedStep = "Package metadata and publisher checksum format validated; package staging has not started"
        writeJournal(activeOperationLabel, "RUNNING")
        val cache = ctx.cacheDir
        if (cache.usableSpace < s) throw IOException("Not enough controller-phone storage to stage the sideload package")
        val temp = File(cache, "ff-sideload-${System.nanoTime()}.partial")
        val staged = File(cache, "ff-sideload-${System.nanoTime()}.zip")
        var tempCreated = false
        var stagedCreated = false
        try {
            if (!temp.createNewFile()) throw IOException("Could not reserve a unique private sideload staging filename")
            tempCreated = true
            if (staged.exists()) throw IOException("Private sideload staging target already exists; refusing overwrite")
            val digest = MessageDigest.getInstance("SHA-256")
            var copied = 0L
            val source = ctx.contentResolver.openInputStream(uri) ?: throw IOException("Cannot open selected sideload package")
            source.use { input ->
                temp.outputStream().buffered().use { output ->
                    val buffer = ByteArray(65536)
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        if (count == 0) throw IOException("Sideload package provider returned a zero-byte read")
                        copied += count
                        if (copied > s) throw IOException("Sideload package grew while being staged")
                        digest.update(buffer, 0, count)
                        output.write(buffer, 0, count)
                    }
                }
            }
            if (copied != s || temp.length() != s) throw IOException("Sideload package is incomplete: expected $s bytes, staged $copied bytes")
            val actualHash = digest.digest().joinToString("") { "%02x".format(it) }
            if (!actualHash.equals(expectedHash, true)) throw IOException("Sideload package SHA-256 does not match the trusted publisher checksum")
            if (!temp.renameTo(staged)) throw IOException("Could not safely finalize the private sideload staging file")
            tempCreated = false
            stagedCreated = true
            lastConfirmedStep = "Package copied to private app storage and publisher SHA-256 verified; recovery protocol not yet started"
            writeJournal(activeOperationLabel, "RUNNING")
            val c = usb.openDevice(d) ?: throw IOException("openDevice failed")
            val a = AdbSideload(c, d)
            activeAdbConnection = c
            activeAdb = a
            try {
                if (!a.open()) throw IOException("No ADB interface. On the phone choose Recovery > Apply update from ADB.")
                lastConfirmedStep = "ADB recovery interface claimed; recovery banner and sideload protocol are being verified; installation is not confirmed"
                writeJournal(activeOperationLabel, "RUNNING")
                log("Sideloading $n ...")
                val res = a.sideload(ctx.contentResolver, Uri.fromFile(staged), s, expectedHash, speedProbe { s }, { log(it) })
                log("Result: $res")
                if (!res.startsWith("OK")) throw IOException("ADB sideload failed or is unsupported: $res")
                lastConfirmedStep = "Recovery sideload transport completed and package SHA-256 matched; recovery installation result must still be confirmed on device"
                writeJournal(activeOperationLabel, "RUNNING")
            } finally {
                try { a.close() } catch (e: Exception) { android.util.Log.w("FlashForge", "ADB session close failed", e) }
                try { c.close() } catch (e: Exception) { android.util.Log.w("FlashForge", "ADB USB connection close failed", e) }
                if (activeAdb === a) activeAdb = null
                if (activeAdbConnection === c) activeAdbConnection = null
            }
        } finally {
            if (tempCreated && temp.exists()) temp.delete()
            if (stagedCreated && staged.exists()) staged.delete()
        }
    }

    // ---------------- log and database ----------------

    fun exportLog() {
        try {
            val f = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "flashforge-log.txt")
            val history = prefs.getString("operation_history", "[]") ?: "[]"
            val journal = prefs.getString("operation_journal", "{}") ?: "{}"
            f.writeText(logs.joinToString("\n") + "\n\nCURRENT OPERATION JOURNAL\n" + journal + "\n\nPERSISTENT OPERATION HISTORY\n" + history)
            log("Log and persistent operation history saved to ${f.absolutePath}")
            val text = f.readText().takeLast(200_000)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "FlashForge log")
                putExtra(Intent.EXTRA_TEXT, text)
            }
            ctx.startActivity(Intent.createChooser(send, "Share log").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { log("Could not export log: ${e.message}") }
    }

    fun updateDb(url: String) {
        dbUrl = url
        prefs.edit().putString("dburl", url).apply()
        if (url.isBlank()) { log("Enter the raw GitHub URL of devices.json"); return }
        io("Database") {
            log(db.update(url))
            dbInfo = "v${db.version}, ${db.count()} models"
        }
    }

    override fun onCleared() {
        viewModelClosing = true
        if (busy) {
            if (activeOperationLabel.startsWith("Flash", true) || activeOperationLabel.equals("ADB sideload", true) || activeOperationLabel.contains("erase", true) || activeOperationLabel.contains("unlock", true) || activeOperationLabel.contains("slot", true)) {
                analyzerStatus = "BLOCKED"
                analyzerMessage = "Application lifecycle ended during a firmware/destructive operation. Inspect the target device before retrying."
                analyzerChecks.add("BLOCKED — app lifecycle interruption; no automatic resume")
            }
            lastConfirmedStep = "Application ViewModel is closing; current operation is not confirmed complete"
            finalizeJournal(activeOperationLabel, "INTERRUPTED", "Application lifecycle ended during an active operation. Inspect the device before any retry.")
            closeInterruptionJournaled = true
        }
        try { fb?.close() } catch (e: Exception) { android.util.Log.w("FlashForge", "Fastboot close during ViewModel cleanup failed", e) }
        fb = null
        closeActiveAdb()
        super.onCleared()
    }
}
