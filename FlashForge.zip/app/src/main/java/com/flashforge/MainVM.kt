package com.flashforge

import android.app.Application
import android.app.PendingIntent
import android.content.Context
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.zip.ZipInputStream

class MainVM(app: Application) : AndroidViewModel(app) {
    companion object { const val ACTION = "com.flashforge.USB_PERMISSION" }

    private val ctx = app
    private val usb = app.getSystemService(Context.USB_SERVICE) as UsbManager
    private val prefs = app.getSharedPreferences("flashforge", Context.MODE_PRIVATE)
    private val db = DeviceDb(app)
    private var fb: Fastboot? = null

    var screen by mutableStateOf(Screen.DEVICE)
    var device by mutableStateOf<UsbDevice?>(null)
    var mode by mutableStateOf(Mode.NONE)
    var vendor by mutableStateOf("")
    var usbId by mutableStateOf("")
    var product by mutableStateOf("")
    var modelName by mutableStateOf("")
    var modelNote by mutableStateOf("")
    var chip by mutableStateOf("")
    var isAB by mutableStateOf(false)
    var unlocked by mutableStateOf("?")
    var slot by mutableStateOf("?")
    var userspace by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var progress by mutableFloatStateOf(0f)
    var expected by mutableStateOf(prefs.getString("expected", "") ?: "")
    var dbUrl by mutableStateOf(prefs.getString("dburl", "") ?: "")
    var dbInfo by mutableStateOf("v${db.version}, ${db.count()} models")

    /** Optional vendor loader/DA selection. Stored only as a user-selected reference; never auto-executed. */
    fun optionalLoader(key: String): Uri? = prefs.getString("optional_loader_$key", null)?.let(Uri::parse)

    fun setOptionalLoader(key: String, uri: Uri?) {
        if (uri == null) {
            prefs.edit().remove("optional_loader_$key").apply()
            log("Optional ${key.uppercase()} loader selection cleared")
            return
        }
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) { /* Some document providers do not offer persistable grants. */ }
        prefs.edit().putString("optional_loader_$key", uri.toString()).apply()
        log("Optional ${key.uppercase()} loader selected: ${uri.lastPathSegment ?: "document"}. Selection is stored only; no chipset write operation is enabled.")
    }

    // ---- cable alert and floating bubble ----
    var cableWarn by mutableStateOf<String?>(null)
    var bubbleOn by mutableStateOf(prefs.getBoolean("bubble", true))
    var overlayOk by mutableStateOf(false)
    var notifOk by mutableStateOf(true)
    private var slowCount = 0
    private var cableIgnored = false
    @Volatile private var failed = false
    private val slowMbs = 2.0

    val vars = mutableStateMapOf<String, String>()
    val parts = mutableStateListOf<String>()
    val queue = mutableStateListOf<QItem>()
    val logs = mutableStateListOf<String>()
    // A file is flash-eligible only after its expected SHA-256 has matched.
    val verifiedFirmware = mutableStateMapOf<String, String>()

    // ---- connection light (red / yellow / green) ----
    var link by mutableStateOf(Link.RED)
    var linkNote by mutableStateOf("No device. Connect the phone with an OTG cable.")
    var linkPct by mutableStateOf(0)
    private var pending = false
    private var connecting = false
    private var ready = false
    private var connectedAt = 0L
    private val detachTimes = ArrayList<Long>()
    private val flapLimit = 3 // USB drops within 20 seconds before the cable alert shows

    init {
        FlashStatus.bubbleOn = bubbleOn
        refreshPerms()
        viewModelScope.launch {
            while (true) {
                delay(500)
                updateLink()
            }
        }
    }

    /** Main thread only. Red = no link, yellow = connecting or dropping, green = stable and ready. */
    private fun updateLink() {
        val now = System.currentTimeMillis()
        detachTimes.removeAll { now - it > 20000 }
        val flapping = detachTimes.size >= flapLimit
        val r = when {
            flapping -> {
                raiseCable("The USB connection dropped ${detachTimes.size} times in 20 seconds.")
                Triple(Link.YELLOW, "Connection keeps dropping. Change the USB cable.", 35)
            }
            pending -> Triple(Link.YELLOW, "Waiting for USB permission. Tap Allow.", 20)
            device == null -> Triple(Link.RED, "No device. Connect the phone with an OTG cable.", 0)
            connecting -> Triple(Link.YELLOW, "Connecting and reading the device...", 60)
            ready && now - connectedAt >= 2000 -> Triple(Link.GREEN, "Stable connection. Ready.", 100)
            ready -> Triple(Link.YELLOW, "Verifying the link...", 90)
            else -> Triple(Link.YELLOW, "Device found but not ready. Put it in a known mode.", 50)
        }
        link = r.first
        linkNote = r.second
        linkPct = r.third
    }

    private fun markReady() {
        connectedAt = System.currentTimeMillis()
        ready = true
    }

    fun log(s: String) {
        logs.add(s)
        if (logs.size > 400) logs.removeAt(0)
    }

    private fun hex(i: Int) = "%04X".format(i)

    private fun io(label: String, bubble: Boolean = false, block: () -> Unit) {
        if (busy) { log("Busy. Wait for the current task to finish."); return }
        busy = true
        progress = 0f
        cableIgnored = false
        slowCount = 0
        failed = false
        if (bubble) {
            FlashStatus.label = label
            FlashStatus.progress = 0f
            FlashStatus.speed = 0.0
            FlashStatus.warn = false
            FlashStatus.warnText = ""
            FlashStatus.result = 0
            FlashStatus.running = true
            startBubble()
        }
        viewModelScope.launch(Dispatchers.IO) {
            try { block() } catch (e: Exception) { failed = true; log("ERROR [$label]: ${e.message}") } finally {
                busy = false
                if (bubble) {
                    if (!failed) FlashStatus.progress = 1f
                    FlashStatus.result = if (failed) 2 else 1
                    FlashStatus.running = false
                }
            }
        }
    }

    // ---------------- cable alert ----------------

    private fun prog(f: Float) {
        progress = f
        FlashStatus.progress = f
    }

    /** Progress callback that also measures the real USB speed once per second. */
    private fun speedProbe(total: () -> Long): (Float) -> Unit {
        var t0 = System.nanoTime()
        var b0 = 0L
        return { f ->
            prog(f)
            val now = System.nanoTime()
            if (now - t0 >= 1_000_000_000L) {
                val b = (f * total()).toLong()
                val mbs = (b - b0) / 1048576.0 / ((now - t0) / 1e9)
                t0 = now
                b0 = b
                onSpeed(mbs)
            }
        }
    }

    private fun onSpeed(mbs: Double) {
        FlashStatus.speed = mbs
        if (mbs < slowMbs) {
            slowCount++
        } else slowCount = 0
    }

    private fun usbCheck(r: Fastboot.Res) {
        if (r.ok) return
        failed = true
        val t = r.text
    }

    private fun raiseCable(why: String) {
        if (cableIgnored || cableWarn != null) return
        cableWarn = why
        FlashStatus.warnText = why
        FlashStatus.warn = true
        FlashStatus.warnSeq = FlashStatus.warnSeq + 1
        log("CABLE WARNING: $why")
    }

    fun cableContinue() {
        cableIgnored = true
        cableWarn = null
        FlashStatus.warn = false
        log("Cable warning ignored for this task")
    }

    fun cableChange() {
        slowCount = 0
        detachTimes.clear()
        cableWarn = null
        FlashStatus.warn = false
        log("Change the data cable, then run the task again if it failed")
    }

    // ---------------- floating bubble ----------------

    private fun startBubble() {
        if (!Settings.canDrawOverlays(ctx)) log("Floating bubble is off: grant the overlay permission in the Device tab.")
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, BubbleService::class.java))
        } catch (e: Exception) {
            log("Bubble service not started: ${e.message}")
        }
    }

    fun refreshPerms() {
        overlayOk = Settings.canDrawOverlays(ctx)
        notifOk = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }

    fun toggleBubble() {
        bubbleOn = !bubbleOn
        FlashStatus.bubbleOn = bubbleOn
        prefs.edit().putBoolean("bubble", bubbleOn).apply()
    }

    /** 20 second demo: press Home while it runs to see the bubble over the launcher. */
    fun testBubble() {
        if (busy) return
        busy = true
        failed = false
        FlashStatus.label = "Bubble test"
        FlashStatus.progress = 0f
        FlashStatus.speed = 0.0
        FlashStatus.warn = false
        FlashStatus.warnText = ""
        FlashStatus.result = 0
        FlashStatus.running = true
        startBubble()
        log("Bubble test for 20 seconds. Press Home to see the bubble.")
        viewModelScope.launch {
            for (i in 1..80) {
                delay(250)
                prog(i / 80f)
                FlashStatus.speed = 18.0 + (i % 5)
            }
            FlashStatus.result = 1
            FlashStatus.running = false
            busy = false
            progress = 0f
        }
    }

    private fun need(): Fastboot = fb ?: throw IOException("No fastboot device connected")

    // ---------------- USB connection ----------------

    fun scan() {
        val d = usb.deviceList.values.firstOrNull()
        if (d == null) { if (device != null) onDetached(); return }
        if (device?.deviceId == d.deviceId && mode != Mode.NONE) return
        if (usb.hasPermission(d)) connect(d) else {
            val pi = PendingIntent.getBroadcast(
                ctx, 0, Intent(ACTION).setPackage(ctx.packageName),
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            pending = true
            usb.requestPermission(d, pi)
        }
        updateLink()
    }

    private fun connect(d: UsbDevice) {
        device = d
        mode = ModeDetector.detect(d)
        vendor = db.vendor(d.vendorId)
        usbId = hex(d.vendorId) + ":" + hex(d.productId)
        chip = ModeDetector.chipHint(mode)
        log("Detected $vendor  USB $usbId  mode ${mode.label}")
        screen = when (mode) {
            Mode.FASTBOOT -> Screen.DEVICE
            Mode.ADB -> Screen.ROM
            else -> Screen.MODES
        }
        pending = false
        ready = false
        connecting = mode == Mode.FASTBOOT
        if (mode == Mode.FASTBOOT) io("Connect") {
            try {
                val c = usb.openDevice(d) ?: throw IOException("openDevice failed")
                val f = Fastboot(c, d) { partition, uri, requestedSize ->
                    // Re-read URI metadata at the transport boundary. A changed/replaced file
                    // or unknown provider size is blocked before Fastboot sends DOWNLOAD.
                    val (currentName, currentSize) = meta(uri)
                    if (currentSize <= 0L || currentSize != requestedSize) {
                        throw IOException("file size/identity changed or cannot be verified (queued=$requestedSize, current=$currentSize)")
                    }
                    verifyFlashGate(partition, uri, currentName, currentSize)
                }
                if (!f.open()) { c.close(); throw IOException("Cannot claim the fastboot interface") }
                fb = f
                refreshInternal(f)
                markReady()
            } finally {
                connecting = false
            }
        } else {
            if (mode != Mode.UNKNOWN) markReady()
        }
        updateLink()
    }

    fun onDetached() {
        if (device != null) detachTimes.add(System.currentTimeMillis())
        pending = false; connecting = false; ready = false
        try { fb?.close() } catch (e: Exception) { }
        fb = null
        device = null; mode = Mode.NONE; vendor = ""; usbId = ""; product = ""
        modelName = ""; modelNote = ""; chip = ""; slot = "?"; unlocked = "?"
        isAB = false; userspace = false
        log("Device disconnected")
        updateLink()
    }

    // ---------------- device info ----------------

    private fun refreshInternal(f: Fastboot) {
        vars.clear(); parts.clear()
        val all = f.cmd("getvar:all", 20000)
        all.info.forEach { l ->
            if (l.startsWith("partition-size:")) parts.add(l.removePrefix("partition-size:").trim())
            else {
                val i = l.indexOf(": ")
                if (i > 0) vars[l.substring(0, i).trim()] = l.substring(i + 2).trim()
            }
        }
        product = f.getvar("product") ?: ""
        slot = f.getvar("current-slot")?.trim()?.removePrefix("_") ?: "?"
        isAB = (f.getvar("slot-count")?.trim()?.toIntOrNull() ?: 0) > 1
        unlocked = f.getvar("unlocked") ?: "?"
        userspace = f.getvar("is-userspace")?.trim() == "yes"
        val m = db.model(product)
        if (m != null) {
            modelName = m.optString("brand") + " " + m.optString("name")
            modelNote = m.optString("note")
            chip = m.optString("chip")
        } else {
            modelName = "Not in database"
            modelNote = "Add this product ID to devices.json or update the database in the Log tab."
        }
        log("Product '$product'  slot $slot  unlocked $unlocked  A/B $isAB  fastbootd $userspace")
    }

    fun refresh() = io("Refresh") { refreshInternal(need()) }

    fun changeExpected(s: String) {
        expected = s
        prefs.edit().putString("expected", s).apply()
    }

    private fun guardOk(): Boolean {
        if (expected.isBlank()) {
            log("BLOCKED: expected product ID is not confirmed. Detect the device, then explicitly set the expected product ID.")
            return false
        }
        if (product.isBlank() || !expected.equals(product, true)) {
            log("BLOCKED: expected product '$expected' but connected device reports '${product.ifBlank { "unknown" }}'")
            return false
        }
        if (mode != Mode.FASTBOOT || !ready || fb == null) {
            log("BLOCKED: a ready Fastboot connection is required")
            return false
        }
        return true
    }

    /** Common fail-closed gate used by every image write path. Requires a publisher checksum
     * previously matched through the VERIFY action, and recalculates it immediately before transfer. */
    private fun verifyFlashGate(partition: String, uri: Uri, name: String, size: Long): String {
        if (!guardOk()) throw IOException("Safety Analyzer BLOCKED: exact expected product ID and ready Fastboot device are required")
        if (!partition.matches(Regex("[A-Za-z0-9_:-]{1,64}"))) throw IOException("Safety Analyzer BLOCKED: invalid partition name")
        if (size <= 0L) throw IOException("Safety Analyzer BLOCKED: image size is unknown or empty")
        val key = uri.toString() + "|" + size
        val expectedDigest = verifiedFirmware[key] ?: throw IOException("Safety Analyzer BLOCKED: publisher SHA-256 is not verified. Add this image to the queue and use VERIFY first.")
        val battery = safetyBatteryPercent()
        if (battery == null || battery < 40) throw IOException("Safety Analyzer BLOCKED: controller phone battery must be at least 40% (currently ${battery?.let { "$it%" } ?: "unavailable"})")
        val q = QItem(partition, uri, name, size)
        val actual = calculateSha256(q)
        if (!actual.equals(expectedDigest, true)) {
            verifiedFirmware.remove(key)
            throw IOException("Safety Analyzer BLOCKED: file changed after verification or SHA-256 mismatch")
        }
        val rawSize = need().getvar("partition-size:$partition")?.trim()?.removePrefix("0x")
        val capacity = rawSize?.toLongOrNull(16)
            ?: throw IOException("Safety Analyzer BLOCKED: bootloader did not verify partition '$partition' size")
        if (capacity <= 0L || size > capacity) throw IOException("Safety Analyzer BLOCKED: image ($size bytes) exceeds or cannot fit verified partition ($capacity bytes)")
        return actual
    }

    fun adoptDetectedProduct() {
        if (product.isBlank() || mode != Mode.FASTBOOT) { log("Cannot adopt product ID: no identified Fastboot device"); return }
        changeExpected(product)
        log("Expected product ID set to '$product'. Confirm that this is the intended target before flashing.")
    }

    fun safetyBatteryPercent(): Int? {
        val intent = ctx.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED)) ?: return null
        val level = intent.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1)
        return if (level >= 0 && scale > 0) (level * 100 / scale) else null
    }

    // ---------------- fastboot commands ----------------

    fun fbCmd(c: String) = io(c) {
        val destructive = listOf("erase", "flashing unlock", "oem unlock", "flashing lock", "oem lock", "set_active", "flash", "wipe", "format").any { c.trim().startsWith(it, true) }
        if (destructive && !guardOk()) throw IOException("BLOCKED: device identity is not verified")
        if (c.trim().equals("flashing lock", true) || c.trim().equals("oem lock", true))
            throw IOException("BLOCKED: bootloader locking requires a separately reviewed stock-firmware and device-specific compatibility procedure; this app cannot currently prove those conditions")
        val r = need().cmd(c, 120000)
        log("> $c => ${if (r.ok) "OKAY" else "FAIL"} ${r.text}")
        r.info.forEach { log("  $it") }
    }

    fun changeSlot(s: String) = io("Slot") {
        if (!guardOk()) throw IOException("BLOCKED: device identity is not verified")
        if (s !in listOf("a", "b") || !isAB) throw IOException("BLOCKED: unsupported slot selection")
        val f = need()
        val r = f.cmd("set_active:$s")
        log("set_active:$s => ${if (r.ok) "OKAY" else "FAIL " + r.text}")
        slot = f.getvar("current-slot")?.trim()?.removePrefix("_") ?: "?"
        log("Active slot is now $slot")
    }

    fun wipe() = io("Wipe", true) {
        if (!guardOk()) throw IOException("BLOCKED: device identity is not verified")
        val f = need()
        val a = f.cmd("erase:userdata", 120000)
        log("erase:userdata => ${if (a.ok) "OKAY" else "FAIL " + a.text}")
        val b = f.cmd("erase:metadata", 60000)
        log("erase:metadata => ${if (b.ok) "OKAY" else "skipped (" + b.text + ")"}")
    }

    private fun meta(uri: Uri): Pair<String, Long> {
        var name = "file"
        var size = 0L
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = c.getString(ni) ?: "file"
                if (si >= 0) size = c.getLong(si)
            }
        }
        if (size == 0L && uri.scheme == "file") {
            val f = File(uri.path ?: "")
            name = f.name; size = f.length()
        }
        return Pair(name, size)
    }

    /** Single application-level route for every image flash (single-image, recovery, boot, queue).
     * Fastboot independently invokes the mandatory authorization callback again at the USB
     * transport boundary immediately before issuing DOWNLOAD, providing defense in depth.
     */
    private fun executeVerifiedFlash(f: Fastboot, partition: String, uri: Uri, name: String, size: Long) {
        if (size <= 0L) throw IOException("Safety Analyzer BLOCKED: image size is unknown or empty")
        log("Safety Analyzer: evaluating $name -> $partition")
        val result = f.flash(partition, ctx.contentResolver, uri, size, speedProbe { size })
        result.info.forEach { log("  $it") }
        usbCheck(result)
        log("flash $name -> $partition => ${if (result.ok) "OKAY" else "FAIL " + result.text}")
        if (!result.ok) throw IOException("Flash stopped; no further destructive command or automatic retry was issued: ${result.text}")
    }

    fun flashOne(part: String, uri: Uri) = io("Flash", true) {
        val (n, s) = meta(uri)
        executeVerifiedFlash(need(), part.trim(), uri, n, s)
    }

    /** vbmeta auto-patching weakens Android Verified Boot; intentionally fail closed. */
    fun flashVbmeta(uri: Uri) = io("VBMETA safety block", true) {
        throw IOException("BLOCKED: automatic vbmeta patching is disabled. It can weaken Android Verified Boot. Use a device-specific reviewed procedure and an unmodified, publisher-verified image.")
    }

    fun backup(p: String) = io("Backup", true) {
        if (!guardOk()) throw IOException("BLOCKED: exact device identity is required before backup")
        if (!p.matches(Regex("[A-Za-z0-9_]{1,48}"))) throw IOException("Invalid partition name")
        val dir = File(ctx.getExternalFilesDir(null), "backups")
        if (!dir.exists() && !dir.mkdirs()) throw IOException("Cannot create backup directory")
        val out = File(dir, "${product}_${p}_${System.currentTimeMillis()}.img")
        var tot = 1L
        val r = out.outputStream().use { need().fetch(p, it, { n -> tot = n }, speedProbe { tot }) }
        usbCheck(r)
        if (!r.ok) { out.delete(); throw IOException("Partition read failed; backup is not available: ${r.text}") }
        if (tot <= 0L || out.length() != tot) { out.delete(); throw IOException("Backup size verification failed") }
        val digest = sha256File(out)
        File(dir, out.name + ".json").writeText(JSONObject().put("product", product).put("partition", p).put("size", out.length()).put("sha256", digest).put("created", System.currentTimeMillis()).toString(2))
        log("backup $p => OKAY ${out.absolutePath}; SHA-256 $digest")
    }

    private fun sha256File(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buf = ByteArray(65536)
            while (true) { val n = input.read(buf); if (n < 0) break; md.update(buf, 0, n) }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    // ---------------- queue, hash, profiles ----------------

    fun addFile(uri: Uri, part: String) {
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) { }
        val (n, s) = meta(uri)
        queue.add(QItem(part.ifBlank { n.substringBeforeLast('.').lowercase() }, uri, n, s))
    }

    fun move(i: Int) {
        if (i > 0 && i < queue.size) {
            val x = queue.removeAt(i)
            queue.add(i - 1, x)
        }
    }

    fun flashQueue() = io("Flash queue", true) {
        if (queue.isEmpty()) throw IOException("Flash queue is empty")
        if (!guardOk()) throw IOException("Safety Analyzer BLOCKED: expected product ID is missing or mismatched")
        val f = need()
        queue.toList().forEachIndexed { i, q ->
            log("[${i + 1}/${queue.size}] Preparing ${q.name} -> ${q.part}; mandatory safety gate will run inside Fastboot before DOWNLOAD")
            executeVerifiedFlash(f, q.part, q.uri, q.name, q.size)
        }
        log("Queue finished")
    }

    private fun calculateSha256(q: QItem, showProgress: Boolean = false): String {
        val md = MessageDigest.getInstance("SHA-256")
        val ins = ctx.contentResolver.openInputStream(q.uri) ?: throw IOException("cannot open file")
        var total = 0L
        ins.use { stream ->
            val b = ByteArray(65536)
            while (true) {
                val n = stream.read(b)
                if (n < 0) break
                md.update(b, 0, n)
                total += n
                if (showProgress) prog(total.toFloat() / maxOf(q.size, 1L))
            }
        }
        if (q.size > 0 && total != q.size) throw IOException("File size changed or metadata mismatch: expected ${q.size}, read $total bytes")
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    fun hash(q: QItem, expect: String) = io("SHA-256") {
        val expectedHash = expect.trim().lowercase()
        if (!expectedHash.matches(Regex("[0-9a-f]{64}"))) {
            verifiedFirmware.remove(q.uri.toString() + "|" + q.size)
            throw IOException("Enter a valid 64-character SHA-256 checksum from the firmware publisher before verification")
        }
        val actual = calculateSha256(q, showProgress = true)
        log("SHA-256 ${q.name}: $actual")
        val key = q.uri.toString() + "|" + q.size
        if (actual == expectedHash) {
            verifiedFirmware[key] = actual
            log("VERIFIED: SHA-256 matches publisher checksum for ${q.name}")
        } else {
            verifiedFirmware.remove(key)
            throw IOException("SHA-256 MISMATCH for ${q.name}. Do not flash this file.")
        }
    }

    fun saveQueue(name: String) {
        if (name.isBlank()) { log("Enter a profile name"); return }
        val a = JSONArray()
        queue.forEach { a.put(JSONObject().put("p", it.part).put("u", it.uri.toString()).put("n", it.name).put("s", it.size)) }
        prefs.edit().putString("q:$name", a.toString()).apply()
        log("Saved profile '$name' with ${queue.size} item(s)")
    }

    fun loadQueue(name: String) {
        val s = prefs.getString("q:$name", null)
        if (s == null) { log("No profile '$name'"); return }
        queue.clear()
        val a = JSONArray(s)
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            queue.add(QItem(o.getString("p"), Uri.parse(o.getString("u")), o.getString("n"), o.getLong("s")))
        }
        log("Loaded profile '$name'")
    }

    fun profileNames(): List<String> = prefs.all.keys.filter { it.startsWith("q:") }.map { it.removePrefix("q:") }

    // ---------------- firmware files ----------------

    private fun unzipInternal(uri: Uri) {
        val dir = File(ctx.getExternalFilesDir(null), "fw")
        dir.mkdirs()
        val raw = ctx.contentResolver.openInputStream(uri) ?: throw IOException("cannot open zip")
        ZipInputStream(raw.buffered()).use { z ->
            var e = z.nextEntry
            var entries = 0
            var totalBytes = 0L
            while (e != null) {
                entries++
                if (entries > 512) throw IOException("ZIP contains too many entries (limit 512)")
                if (!e.isDirectory && e.name.endsWith(".img", ignoreCase = true)) {
                    // Never use archive paths: only a validated basename is written into our private folder.
                    val n = e.name.substringAfterLast('/').substringAfterLast('\\')
                    if (n.isBlank() || n == "." || n == "..") throw IOException("Invalid image filename in ZIP")
                    val f = File(dir, n)
                    var written = 0L
                    f.outputStream().use { o ->
                        val buf = ByteArray(65536)
                        while (true) {
                            val count = z.read(buf)
                            if (count < 0) break
                            written += count
                            totalBytes += count
                            if (written > 1024L * 1024 * 1024 || totalBytes > 4L * 1024 * 1024 * 1024) {
                                throw IOException("ZIP extraction size limit exceeded")
                            }
                            o.write(buf, 0, count)
                        }
                    }
                    if (written == 0L) { f.delete(); throw IOException("Empty image entry: $n") }
                    queue.add(QItem(n.removeSuffix(".img").lowercase(), Uri.fromFile(f), n, f.length()))
                    log("Unpacked $n (${f.length() / 1024} KB)")
                }
                z.closeEntry()
                e = z.nextEntry
            }
        }
    }

    fun unzipToQueue(uri: Uri) = io("Unpack") { unzipInternal(uri) }

    /** Folder where every downloaded or unpacked firmware file is kept. */
    fun fwDir(): File = File(ctx.getExternalFilesDir(null), "fw").also { it.mkdirs() }

    /** Brand of the connected phone (from the model database, else from the USB vendor) and its firmware sites. */
    fun brandName(): String = db.model(product)?.optString("brand")?.ifBlank { null } ?: vendor
    fun brandLinks(): List<Pair<String, String>> = db.brandLinks(brandName())

    fun fwLinks(): List<Pair<String, String>> = db.firmware(product)

    fun fwFiles(): List<File> =
        fwDir().listFiles { f -> f.isFile && (f.name.endsWith(".img") || f.name.endsWith(".zip")) }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()

    /** Take a file from the firmware folder into the flash queue (zip files are unpacked). */
    fun useFwFile(f: File) {
        if (f.name.endsWith(".zip")) unzipToQueue(Uri.fromFile(f))
        else if (queue.none { it.name == f.name })
            queue.add(QItem(f.name.substringBeforeLast('.').lowercase(), Uri.fromFile(f), f.name, f.length()))
    }

    fun download(url: String) = io("Download", true) {
        if (!url.startsWith("https://", true)) throw IOException("Firmware downloads require HTTPS")
        val c = URL(url).openConnection() as HttpURLConnection
        c.instanceFollowRedirects = true
        c.connectTimeout = 15000
        c.readTimeout = 30000
        val status = c.responseCode
        if (status !in 200..299) { c.disconnect(); throw IOException("Firmware server returned HTTP $status") }
        val total = c.contentLengthLong
        val name = url.substringAfterLast('/').substringBefore('?').ifBlank { "download.bin" }.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val dir = File(ctx.getExternalFilesDir(null), "fw")
        dir.mkdirs()
        val f = File(dir, name)
        val temp = File(dir, name + ".download")
        if (total > 0 && dir.usableSpace < total) throw IOException("Not enough storage for this download")
        try { c.inputStream.use { i ->
            temp.outputStream().use { o ->
                val b = ByteArray(65536)
                var t = 0L
                while (true) {
                    val n = i.read(b)
                    if (n < 0) break
                    o.write(b, 0, n)
                    t += n
                    if (total > 0) prog(t.toFloat() / total)
                }
            }
        }
        if (total > 0 && temp.length() != total) throw IOException("Incomplete download: expected $total bytes, received ${temp.length()}")
        if (temp.length() <= 0L) throw IOException("Downloaded file is empty")
        if (f.exists() && !f.delete()) throw IOException("Cannot replace existing download")
        if (!temp.renameTo(f)) throw IOException("Could not finalize downloaded file")
        } catch (e: Exception) { temp.delete(); throw e } finally { c.disconnect() }
        log("Downloaded ${f.absolutePath}")
        if (name.endsWith(".zip")) unzipInternal(Uri.fromFile(f))
        else queue.add(QItem(name.substringBeforeLast('.').lowercase(), Uri.fromFile(f), name, f.length()))
    }

    // ---------------- ADB sideload ----------------

    fun sideload(uri: Uri) = io("Sideload", true) {
        val d = device ?: throw IOException("No device")
        val (n, s) = meta(uri)
        val c = usb.openDevice(d) ?: throw IOException("openDevice failed")
        try {
            val a = AdbSideload(c, d)
            if (!a.open()) throw IOException("No ADB interface. On the phone choose Recovery > Apply update from ADB.")
            log("Sideloading $n ...")
            val res = a.sideload(ctx.contentResolver, uri, s, speedProbe { s }, { log(it) })
            log("Result: $res")
            if (!res.startsWith("OK")) {
                failed = true
            }
        } finally { c.close() }
    }

    // ---------------- log and database ----------------

    fun exportLog() {
        val f = File(ctx.getExternalFilesDir(null), "flashforge-log.txt")
        f.writeText(logs.joinToString("\n"))
        log("Log saved to ${f.absolutePath}")
    }

    fun updateDb(url: String) {
        dbUrl = url
        prefs.edit().putString("dburl", url).apply()
        if (url.isBlank()) { log("Enter the raw GitHub URL of devices.json"); return }
        io("Database") {
            log(db.update(url))
            dbInfo = "v${db.version}, ${db.count()} models"
        }
    }
}
