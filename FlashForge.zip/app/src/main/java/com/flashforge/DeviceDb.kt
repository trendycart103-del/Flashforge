package com.flashforge

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class DeviceDb(private val ctx: Context) {
    private val file = File(ctx.filesDir, "devices.json")
    private var root: JSONObject = load()

    private fun load(): JSONObject = try {
        val txt = if (file.exists()) file.readText()
        else ctx.assets.open("devices.json").bufferedReader().use { it.readText() }
        JSONObject(txt)
    } catch (e: Exception) {
        JSONObject("{\"version\":0,\"vendors\":{},\"models\":[]}")
    }

    val version: Int get() = root.optInt("version")

    fun vendor(vid: Int): String =
        root.optJSONObject("vendors")?.optString("%04x".format(vid), "Unknown vendor") ?: "Unknown vendor"

    fun model(product: String): JSONObject? {
        val a = root.optJSONArray("models") ?: return null
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.optString("product").equals(product, true)) return o
        }
        return null
    }

    /** Firmware links of a model: "firmware": [{"name": "...", "url": "https://..."}] in devices.json. */
    fun firmware(product: String): List<Pair<String, String>> {
        val a = model(product)?.optJSONArray("firmware") ?: return emptyList()
        return (0 until a.length()).mapNotNull {
            val o = a.optJSONObject(it) ?: return@mapNotNull null
            val u = o.optString("url")
            if (u.isBlank()) null else o.optString("name", u.substringAfterLast('/')) to u
        }
    }

    /** Well-known firmware websites of a brand: "brandLinks": {"Samsung": [{"name", "url"}]}. */
    fun brandLinks(brand: String): List<Pair<String, String>> {
        val a = root.optJSONObject("brandLinks")?.optJSONArray(brand) ?: return emptyList()
        return (0 until a.length()).mapNotNull {
            val o = a.optJSONObject(it) ?: return@mapNotNull null
            val u = o.optString("url")
            if (u.isBlank()) null else o.optString("name", u) to u
        }
    }

    fun count(): Int = root.optJSONArray("models")?.length() ?: 0

    /** Download and atomically apply a bounded HTTPS database update on a background thread. */
    fun update(url: String): String {
        val parsed = URL(url)
        require(parsed.protocol.equals("https", true)) { "Database update requires HTTPS" }
        val c = parsed.openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.instanceFollowRedirects = false
        try {
            c.setRequestProperty("Accept", "application/json")
            c.connect()
            if (c.responseCode !in 200..299) throw IOException("Database server returned HTTP ${c.responseCode}")
            val declared = c.contentLengthLong
            if (declared > 2L * 1024 * 1024) throw IOException("Database file exceeds 2 MB limit")
            val bytes = c.inputStream.use { input ->
                val out = java.io.ByteArrayOutputStream()
                val buf = ByteArray(8192)
                var total = 0
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > 2 * 1024 * 1024) throw IOException("Database file exceeds 2 MB limit")
                    out.write(buf, 0, n)
                }
                out.toByteArray()
            }
            val txt = bytes.toString(Charsets.UTF_8)
            val n = JSONObject(txt)
            require(n.optInt("version", -1) >= 0) { "Invalid database version" }
            require(n.optJSONObject("vendors") != null && n.optJSONArray("models") != null) {
                "Invalid database structure: vendors/models are required"
            }
            if (n.optInt("version") < version) return "Local database v$version is newer than remote v${n.optInt("version")}"
            val tmp = File(ctx.filesDir, "devices.json.tmp")
            tmp.writeText(txt)
            try {
                java.nio.file.Files.move(
                    tmp.toPath(), file.toPath(),
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                    java.nio.file.StandardCopyOption.ATOMIC_MOVE
                )
            } catch (e: Exception) {
                tmp.delete()
                throw IOException("Cannot safely commit updated database", e)
            }
            root = n
            return "Database updated to v${n.optInt("version")} (${count()} models)"
        } finally {
            c.disconnect()
        }
    }
}
