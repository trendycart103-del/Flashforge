package com.flashforge

import android.content.ContentResolver
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.net.Uri
import java.io.OutputStream
import java.security.MessageDigest

/** Fastboot protocol over USB bulk endpoints (host side). */
class Fastboot(
    private val conn: UsbDeviceConnection,
    private val dev: UsbDevice,
    /** Mandatory authorization callback. There is deliberately no unguarded flash API. */
    private val authorizeFlash: (partition: String, uri: Uri, size: Long) -> String,
    /** Re-authorizes every destructive command at the USB transport boundary. */
    private val authorizeDestructive: (command: String) -> Unit
) {
    private var inEp: UsbEndpoint? = null
    private var outEp: UsbEndpoint? = null
    private var iface: UsbInterface? = null
    @Volatile private var protocolUncertain: Boolean = false
    val isProtocolUsable: Boolean get() = !protocolUncertain

    class Res(val ok: Boolean, val text: String, val info: List<String>)

    fun open(): Boolean {
        return try {
            for (i in 0 until dev.interfaceCount) {
                val f = dev.getInterface(i)
                if (f.interfaceClass == 0xFF && f.interfaceSubclass == 0x42 && f.interfaceProtocol == 0x03) {
                    var a: UsbEndpoint? = null
                    var b: UsbEndpoint? = null
                    for (e in 0 until f.endpointCount) {
                        val ep = f.getEndpoint(e)
                        if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                            if (ep.direction == UsbConstants.USB_DIR_IN) a = ep else b = ep
                        }
                    }
                    if (a != null && b != null && conn.claimInterface(f, true)) {
                        inEp = a; outEp = b; iface = f
                        return true
                    }
                }
            }
            false
        } catch (e: Exception) {
            android.util.Log.e("FlashForgeFastboot", "Could not open Fastboot USB interface", e)
            protocolUncertain = true
            false
        }
    }

    fun close() {
        try { iface?.let { conn.releaseInterface(it) } } catch (e: Exception) { android.util.Log.w("FlashForgeFastboot", "USB interface release failed", e) }
        try { conn.close() } catch (e: Exception) { android.util.Log.w("FlashForgeFastboot", "USB connection close failed", e) }
        iface = null; inEp = null; outEp = null
        protocolUncertain = true
    }

    private fun send(b: ByteArray, len: Int = b.size): Boolean {
        var off = 0
        while (off < len) {
            val n = minOf(16384, len - off)
            val r = try { conn.bulkTransfer(outEp, b, off, n, 10000) } catch (_: Exception) {
                protocolUncertain = true
                return false
            }
            if (r <= 0) return false
            off += r
        }
        return true
    }

    private fun recv(timeout: Int): String? {
        val buf = ByteArray(512)
        val n = try { conn.bulkTransfer(inEp, buf, buf.size, timeout) } catch (_: Exception) {
            protocolUncertain = true
            return null
        }
        return if (n <= 0) null else String(buf, 0, n, Charsets.UTF_8)
    }

    /** Generic command path intentionally refuses raw flash writes. */
    fun cmd(c: String, timeout: Int = 60000): Res {
        if (protocolUncertain) return Res(false, "USB/Fastboot protocol state is uncertain; reconnect and re-identify the device", emptyList())
        val normalized = c.trim()
        if (normalized.startsWith("flash:", ignoreCase = true)) {
            return Res(false, "BLOCKED: raw flash commands are forbidden; use the mandatory Safety Analyzer guarded flash() path", emptyList())
        }
        if (isPotentiallyDestructive(normalized)) {
            try { authorizeDestructive(normalized) }
            catch (e: Exception) { return Res(false, "BLOCKED by destructive-command Safety Gate: ${e.message ?: "authorization failed"}", emptyList()) }
        } else {
            val readOnly = normalized.startsWith("getvar:", true) || normalized.startsWith("fetch:", true) ||
                normalized.equals("reboot", true) || normalized.equals("reboot-bootloader", true) ||
                normalized.equals("reboot-recovery", true) || normalized.equals("reboot-fastboot", true)
            if (!readOnly) return Res(false, "BLOCKED: unsupported raw Fastboot command; only reviewed read-only commands are available", emptyList())
        }
        return command(normalized, timeout)
    }

    private fun isPotentiallyDestructive(c: String): Boolean {
        val v = c.lowercase()
        return v.startsWith("erase:") || v.startsWith("format:") || v.startsWith("wipe:") ||
            v.startsWith("flashing unlock") || v.startsWith("flashing lock") ||
            v.startsWith("oem ") || v.startsWith("set_active:") ||
            v.startsWith("create-logical-partition:") || v.startsWith("resize-logical-partition:") ||
            v.startsWith("delete-logical-partition:") || v.startsWith("update-super:") ||
            v.startsWith("flash:") || v.startsWith("download:") || v.startsWith("partition:")
    }

    private fun command(c: String, timeout: Int = 60000): Res {
        if (protocolUncertain) return Res(false, "Fastboot connection is not synchronized", emptyList())
        if (!send(c.toByteArray(Charsets.UTF_8))) { protocolUncertain = true; return Res(false, "USB write failed; reconnect required", emptyList()) }
        val info = ArrayList<String>()
        while (true) {
            val r = recv(timeout) ?: run { protocolUncertain = true; return Res(false, "timeout or USB read failed; reconnect required", info) }
            when {
                r.startsWith("INFO") -> info.add(r.substring(4))
                r.startsWith("OKAY") -> return Res(true, r.substring(4), info)
                r.startsWith("DATA") -> return Res(true, r, info)
                r.startsWith("FAIL") -> return Res(false, r.substring(4), info)
                else -> { protocolUncertain = true; return Res(false, "bad response: $r; reconnect required", info) }
            }
        }
    }

    fun getvar(name: String): String? {
        val r = cmd("getvar:$name", 5000)
        if (!r.ok) return null
        return r.text.ifEmpty { r.info.firstOrNull() ?: "" }
    }

    /**
     * The only image-write entry point. The mandatory authorization callback is invoked
     * inside the transport layer immediately before any download/flash command, so callers
     * cannot bypass the MainVM safety policy by calling Fastboot directly.
     */
    fun flash(
        part: String,
        resolver: ContentResolver,
        uri: Uri,
        size: Long,
        progress: (Float) -> Unit,
        onStep: (String) -> Unit = {}
    ): Res {
        if (protocolUncertain) return Res(false, "Fastboot connection is not synchronized; reconnect before flashing", emptyList())
        if (!part.matches(Regex("[A-Za-z0-9_]{1,48}"))) return Res(false, "Invalid partition name", emptyList())
        if (size <= 0) return Res(false, "Safety Analyzer BLOCKED: empty or unknown file size", emptyList())
        if (size > 0xffffffffL) return Res(false, "Safety Analyzer BLOCKED: this Fastboot download protocol path cannot represent files larger than 4 GiB", emptyList())
        val digest = try {
            authorizeFlash(part, uri, size)
        } catch (e: Exception) {
            return Res(false, "Safety Analyzer BLOCKED: ${e.message ?: "authorization failed"}", emptyList())
        }
        val maxRaw = getvar("max-download-size")?.trim()?.removePrefix("0x")?.removePrefix("0X")
        val max = maxRaw?.toLongOrNull(16)
        if (max != null && max > 0 && size > max) {
            return Res(false, "Image transfer size $size exceeds the bootloader-advertised max-download-size $max", emptyList())
        }
        // Open the source BEFORE asking the bootloader to enter DATA mode. A missing URI
        // must never strand the protocol after DOWNLOAD has been accepted.
        val source = try { resolver.openInputStream(uri) } catch (e: Exception) {
            return Res(false, "Cannot open firmware file before transfer: ${e.message}", emptyList())
        } ?: return Res(false, "Cannot open firmware file before transfer", emptyList())
        try {
            val s = source
            val d = command("download:%08x".format(size), 60000)
            if (!d.ok || !d.text.startsWith("DATA")) return Res(false, "download refused: ${d.text}", d.info)
            try { onStep("Bootloader accepted DOWNLOAD; image data transfer is in progress. No FLASH command has been issued yet.") }
            catch (e: Exception) { protocolUncertain = true; return Res(false, "Could not persist transfer state after DOWNLOAD: ${e.message}; reconnect required", emptyList()) }
            val transferDigest = MessageDigest.getInstance("SHA-256")
            var sent = 0L
            val buf = ByteArray(16384)
            while (sent < size) {
                val want = minOf(buf.size.toLong(), size - sent).toInt()
                val n = try { s.read(buf, 0, want) } catch (e: Exception) {
                    protocolUncertain = true
                    return Res(false, "File read failed after DOWNLOAD began at $sent bytes: ${e.message}; reconnect required; no FLASH command was issued", emptyList())
                }
                if (n < 0) {
                    protocolUncertain = true
                    return Res(false, "File ended early at $sent bytes; reconnect required; no FLASH command was issued", emptyList())
                }
                if (n == 0) {
                    protocolUncertain = true
                    return Res(false, "File provider returned a zero-byte read; transfer stopped and reconnect is required", emptyList())
                }
                transferDigest.update(buf, 0, n)
                if (!send(buf, n)) {
                    protocolUncertain = true
                    return Res(false, "USB write failed at $sent bytes; reconnect required; no FLASH command was issued", emptyList())
                }
                sent += n
                try { progress(sent.toFloat() / size) } catch (e: Exception) {
                    protocolUncertain = true
                    return Res(false, "Progress reporting failed during USB transfer: ${e.message}; reconnect required; no FLASH command was issued", emptyList())
                }
            }
            val extra = try { s.read() } catch (e: Exception) {
                protocolUncertain = true
                return Res(false, "Could not confirm end-of-file after transfer: ${e.message}; reconnect required", emptyList())
            }
            if (extra != -1) {
                protocolUncertain = true
                return Res(false, "Safety Analyzer BLOCKED: file grew during transfer; reconnect required; no FLASH command was issued", emptyList())
            }
            val streamedDigest = transferDigest.digest().joinToString("") { "%02x".format(it) }
            if (!streamedDigest.equals(digest, ignoreCase = true)) {
                protocolUncertain = true
                return Res(false, "Safety Analyzer BLOCKED: file contents changed during USB transfer; reconnect required; no FLASH command was issued", emptyList())
            }
            val response = recv(60000)
            if (response == null) {
                protocolUncertain = true
                return Res(false, "No response after data transfer; reconnect required; no FLASH command was issued", emptyList())
            }
            if (!response.startsWith("OKAY")) {
                protocolUncertain = true
                return Res(false, response, emptyList())
            }
            try { onStep("Bootloader acknowledged the image transfer and SHA-256 matched. FLASH command is about to be issued; write result is not yet confirmed.") }
            catch (e: Exception) { protocolUncertain = true; return Res(false, "Could not persist pre-flash state: ${e.message}; reconnect required; FLASH command was not issued", emptyList()) }
            val result = command("flash:$part", 180000)
            if (!result.ok) protocolUncertain = true
            return Res(result.ok, result.text, listOf("Pre-flash safety authorization passed; SHA-256 $digest") + result.info)
        } finally {
            try { source.close() } catch (e: Exception) { android.util.Log.w("FlashForgeFastboot", "Firmware input stream close failed after transfer", e) }
        }
    }

    /** Reads a partition with the fastboot "fetch" command (needs bootloader support). */
    fun fetch(part: String, out: OutputStream, onSize: (Long) -> Unit = {}, progress: (Float) -> Unit): Res {
        val r = cmd("fetch:$part")
        if (!r.ok || !r.text.startsWith("DATA")) return Res(false, "fetch not supported or refused: ${r.text}", r.info)
        val total = r.text.substring(4).trim().toLongOrNull(16) ?: run { protocolUncertain = true; return Res(false, "bad size reply; reconnect required", emptyList()) }
        try { onSize(total) } catch (e: Exception) {
            protocolUncertain = true
            return Res(false, "Could not record backup size after FETCH began: ${e.message}; reconnect required", emptyList())
        }
        if (total == 0L) {
            val end = recv(30000) ?: run { protocolUncertain = true; return Res(false, "no final response for empty partition; reconnect required", emptyList()) }
            if (!end.startsWith("OKAY")) protocolUncertain = true
            return Res(end.startsWith("OKAY"), end.drop(4), emptyList())
        }
        val buf = ByteArray(65536)
        var got = 0L
        while (got < total) {
            val remain = total - got
            val len = minOf(65536L, remain).toInt()
            val n = try { conn.bulkTransfer(inEp, buf, len, 30000) } catch (e: Exception) {
                protocolUncertain = true
                return Res(false, "USB read failed at $got: ${e.message}; reconnect required", emptyList())
            }
            if (n <= 0) { protocolUncertain = true; return Res(false, "USB read failed or stalled at $got; reconnect required", emptyList()) }
            val take = minOf(n.toLong(), remain).toInt()
            try { out.write(buf, 0, take) } catch (e: Exception) {
                protocolUncertain = true
                return Res(false, "Backup output failed at $got bytes; Fastboot response stream may be incomplete; reconnect required: ${e.message}", emptyList())
            }
            got += take
            try { progress(got.toFloat() / total) } catch (e: Exception) {
                protocolUncertain = true
                return Res(false, "Backup progress reporting failed at $got bytes: ${e.message}; reconnect required", emptyList())
            }
        }
        val end = recv(30000) ?: run { protocolUncertain = true; return Res(false, "no final response; reconnect required", emptyList()) }
        if (!end.startsWith("OKAY")) protocolUncertain = true
        return Res(end.startsWith("OKAY"), end.drop(4), emptyList())
    }
}
