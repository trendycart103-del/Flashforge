package com.flashforge

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlin.math.abs

/** Shared live state between the view model, the floating bubble and the notification. */
object FlashStatus {
    @Volatile var running = false
    @Volatile var label = ""
    @Volatile var progress = 0f
    @Volatile var speed = 0.0
    @Volatile var warn = false
    @Volatile var warnText = ""
    @Volatile var warnSeq = 0
    @Volatile var result = 0      // 0 none, 1 finished, 2 failed
    @Volatile var appFg = true
    @Volatile var bubbleOn = true
}

/** The round floating bubble drawn on top of every app. */
class BubbleView(c: Context) : View(c) {
    private val d = c.resources.displayMetrics.density
    private val navy = 0xFF0B1F4B.toInt()
    private val blue = 0xFF0B5FFF.toInt()
    private val orange = 0xFFFF6A00.toInt()
    private val green = 0xFF00A04A.toInt()
    private val red = 0xFFE53935.toInt()
    private val amber = 0xFFFFC400.toInt()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; isFakeBoldText = true; typeface = android.graphics.Typeface.MONOSPACE }
    private val mark = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val rect = RectF()
    private var shown = 0f

    override fun onDraw(cv: Canvas) {
        val s = FlashStatus
        val w = width.toFloat()
        val cx = w / 2f
        val cy = w / 2f
        val now = System.currentTimeMillis()
        val running = s.running
        val warn = running && s.warn
        val ringColor = when {
            warn -> red
            !running && s.result == 2 -> red
            !running && s.result == 1 -> green
            else -> orange
        }
        // smooth percent: the shown value glides toward the real progress
        if (running) {
            if (s.progress < shown - 0.2f) shown = 0f
            shown += (s.progress - shown) * 0.12f
        } else shown = if (s.result == 1) 1f else s.progress
        if (running && !warn) {
            fill.color = orange
            fill.alpha = (45 + 40 * Math.sin(now / 220.0)).toInt()
            cv.drawCircle(cx, cy, w / 2f - 0.5f * d, fill)
            fill.alpha = 255
        }
        fill.color = navy
        cv.drawCircle(cx, cy, w / 2f - 1.5f * d, fill)
        val sw = 4f * d
        val r = w / 2f - 5f * d
        rect.set(cx - r, cy - r, cx + r, cy + r)
        track.strokeWidth = sw
        track.color = blue
        track.alpha = 120
        cv.drawCircle(cx, cy, r, track)
        arc.strokeWidth = sw
        arc.color = ringColor
        when {
            running && s.progress <= 0f -> cv.drawArc(rect, ((now / 4) % 360).toFloat(), 100f, false, arc)
            running -> {
                cv.drawArc(rect, -90f, maxOf(shown, 0.02f) * 360f, false, arc)
                if (!warn) {
                    arc.color = 0xFFFFFFFF.toInt()
                    arc.alpha = 170
                    arc.strokeWidth = sw * 0.45f
                    cv.drawArc(rect, ((now / 3) % 360).toFloat(), 38f, false, arc)
                    arc.alpha = 255
                    arc.strokeWidth = sw
                }
            }
            else -> cv.drawArc(rect, -90f, 360f, false, arc)
        }
        when {
            warn -> {
                val on = (now / 400) % 2L == 0L
                txt.color = if (on) amber else 0xFFFFFFFF.toInt()
                txt.textSize = 26f * d
                cv.drawText("!", cx, cy + 9f * d, txt)
            }
            running -> {
                txt.color = 0xFFFFFFFF.toInt()
                val pct = (shown * 100).toInt().coerceIn(0, 100)
                if (s.speed > 0.0) {
                    txt.textSize = 13f * d
                    cv.drawText("$pct%", cx, cy + 1f * d, txt)
                    txt.textSize = 8f * d
                    txt.color = amber
                    cv.drawText(String.format("%.1f", s.speed) + "MB/s", cx, cy + 12f * d, txt)
                } else {
                    txt.textSize = 15f * d
                    cv.drawText("$pct%", cx, cy + 5.5f * d, txt)
                }
            }
            s.result == 1 -> {
                mark.color = green
                mark.strokeWidth = 4.5f * d
                val p = Path()
                p.moveTo(cx - 9f * d, cy + 1f * d)
                p.lineTo(cx - 3f * d, cy + 7f * d)
                p.lineTo(cx + 9f * d, cy - 7f * d)
                cv.drawPath(p, mark)
            }
            s.result == 2 -> {
                mark.color = red
                mark.strokeWidth = 4.5f * d
                cv.drawLine(cx - 7f * d, cy - 7f * d, cx + 7f * d, cy + 7f * d, mark)
                cv.drawLine(cx + 7f * d, cy - 7f * d, cx - 7f * d, cy + 7f * d, mark)
            }
        }
        if (running) postInvalidateOnAnimation()
    }
}

/**
 * Foreground service. Keeps the process alive while a flash runs in the background, shows a progress
 * notification, and draws a draggable bubble over every app (needs the overlay permission).
 */
class BubbleService : Service() {
    companion object {
        const val CH_RUN = "flashforge_run"
        const val CH_ALERT = "flashforge_alert"
        const val ID_RUN = 41
        const val ID_ALERT = 42
    }

    private var wm: WindowManager? = null
    private var view: BubbleView? = null
    private var lp: WindowManager.LayoutParams? = null
    private val h = Handler(Looper.getMainLooper())
    private var doneAt = 0L
    private var lastKey = ""
    private var lastWarnSeq = 0
    private var finishPosted = false
    private val sizePx get() = (64 * resources.displayMetrics.density).toInt()
    private val marginPx get() = (6 * resources.displayMetrics.density).toInt()

    private val tick = object : Runnable {
        override fun run() {
            step()
            h.postDelayed(this, 250)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH_RUN, "Flash progress", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Flash alerts", NotificationManager.IMPORTANCE_HIGH))
        ServiceCompat.startForeground(this, ID_RUN, buildNotif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        lastWarnSeq = FlashStatus.warnSeq
        addBubble()
        h.post(tick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        doneAt = 0L
        finishPosted = false
        if (view == null) addBubble()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        try { view?.let { wm?.removeView(it) } } catch (e: Exception) { android.util.Log.w("FlashForgeBubble", "Bubble view cleanup failed", e) }
        view = null
        super.onDestroy()
    }

    private fun appIntent(): Intent =
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)

    private fun contentPi(): PendingIntent =
        PendingIntent.getActivity(this, 0, appIntent(), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun openApp() {
        try { startActivity(appIntent()) } catch (e: Exception) {
            try { contentPi().send() } catch (e2: Exception) { android.util.Log.e("FlashForgeBubble", "Could not open app from bubble", e2) }
        }
    }

    private fun addBubble() {
        if (!Settings.canDrawOverlays(this)) return
        try {
            val manager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val v = BubbleView(this)
            val p = WindowManager.LayoutParams(
                sizePx, sizePx,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            )
            p.gravity = Gravity.TOP or Gravity.START
            p.x = resources.displayMetrics.widthPixels - sizePx - marginPx
            p.y = (160 * resources.displayMetrics.density).toInt()
            v.setOnTouchListener(object : View.OnTouchListener {
                var sx = 0
                var sy = 0
                var tx = 0f
                var ty = 0f
                var moved = false
                override fun onTouch(view: View, e: MotionEvent): Boolean {
                    val q = lp ?: return false
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> { sx = q.x; sy = q.y; tx = e.rawX; ty = e.rawY; moved = false }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = e.rawX - tx
                            val dy = e.rawY - ty
                            if (abs(dx) > 12f || abs(dy) > 12f) moved = true
                            if (moved) {
                                q.x = sx + dx.toInt()
                                q.y = sy + dy.toInt()
                                try { wm?.updateViewLayout(view, q) } catch (ex: Exception) { android.util.Log.w("FlashForgeBubble", "Could not update bubble position", ex) }
                            }
                        }
                        MotionEvent.ACTION_UP -> {
                            if (!moved) { view.visibility = View.GONE; openApp() } else {
                                val sw = resources.displayMetrics.widthPixels
                                q.x = if (q.x + sizePx / 2 < sw / 2) marginPx else sw - sizePx - marginPx
                                try { wm?.updateViewLayout(view, q) } catch (ex: Exception) { android.util.Log.w("FlashForgeBubble", "Could not update bubble position", ex) }
                            }
                        }
                    }
                    return true
                }
            })
            manager.addView(v, p)
            wm = manager
            view = v
            lp = p
        } catch (e: Exception) {
            view = null
        }
    }

    private fun buildNotif(): Notification {
        val s = FlashStatus
        val pct = (s.progress * 100).toInt().coerceIn(0, 100)
        val title = when {
            s.running && s.warn -> "Check the data cable"
            s.running -> "FlashForge  " + s.label
            s.result == 1 -> "Finished"
            s.result == 2 -> "Failed"
            else -> "FlashForge"
        }
        val text = when {
            s.running && s.warn -> s.warnText
            s.running -> "$pct%" + (if (s.speed > 0.0) "   " + String.format("%.1f", s.speed) + " MB/s" else "")
            else -> s.label
        }
        val b = NotificationCompat.Builder(this, CH_RUN)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setColor(0xFFE4501A.toInt())
            .setContentIntent(contentPi())
        if (s.running) b.setProgress(100, pct, s.progress <= 0f)
        return b.build()
    }

    private fun alert(title: String, text: String) {
        try {
            val n = NotificationCompat.Builder(this, CH_ALERT)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setColor(0xFFE53935.toInt())
                .setContentIntent(contentPi())
                .build()
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(ID_ALERT, n)
        } catch (e: Exception) { android.util.Log.e("FlashForgeBubble", "Could not post bubble alert notification", e) }
    }

    private fun step() {
        val s = FlashStatus
        val now = System.currentTimeMillis()
        if (!s.running) {
            if (s.result == 0) { stopSelf(); return }
            if (doneAt == 0L) doneAt = now
            if (!finishPosted) {
                finishPosted = true
                if (!s.appFg) alert(if (s.result == 1) "FlashForge finished" else "FlashForge failed", s.label)
            }
            if (now - doneAt > 8000L) { stopSelf(); return }
        } else {
            doneAt = 0L
            finishPosted = false
        }
        view?.visibility = if (s.appFg || !s.bubbleOn) View.GONE else View.VISIBLE
        view?.invalidate()
        val pct = (s.progress * 100).toInt()
        val key = "${s.running}|$pct|${s.warn}|${s.result}|${s.speed.toInt()}"
        if (key != lastKey) {
            lastKey = key
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(ID_RUN, buildNotif())
        }
        if (s.warnSeq != lastWarnSeq) {
            lastWarnSeq = s.warnSeq
            if (s.warn && !s.appFg) alert("Change the data cable", s.warnText)
        }
    }
}
