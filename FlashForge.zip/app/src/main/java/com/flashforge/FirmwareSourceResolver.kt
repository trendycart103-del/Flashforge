package com.flashforge

import android.net.Uri

/** Manufacturer-owned firmware/support entry points. These are portals, not guessed direct ROM files. */
object FirmwareSourceResolver {
    data class Source(val title: String, val url: String, val official: Boolean = true)

    private val sources = mapOf(
        "samsung" to listOf(Source("Samsung Official Support", "https://www.samsung.com/us/support/")),
        "xiaomi" to listOf(Source("Xiaomi Official Support", "https://www.mi.com/global/support/")),
        "google" to listOf(
            Source("Google Pixel Factory Images", "https://developers.google.com/android/images"),
            Source("Google Pixel Full OTA Images", "https://developers.google.com/android/ota")
        ),
        "motorola" to listOf(Source("Motorola Rescue and Smart Assistant", "https://en-us.support.motorola.com/app/rsa")),
        "oneplus" to listOf(Source("OnePlus Official Software Upgrade", "https://www.oneplus.com/support/softwareupgrade")),
        "sony" to listOf(Source("Sony Open Devices Downloads", "https://developer.sony.com/open-source/aosp-on-xperia-open-devices/downloads")),
        "huawei" to listOf(Source("Huawei Official Support", "https://consumer.huawei.com/en/support/")),
        "oppo" to listOf(Source("OPPO Official Support", "https://www.oppo.com/en/support/")),
        "vivo" to listOf(Source("vivo Official Support", "https://www.vivo.com/en/support/")),
        "asus" to listOf(Source("ASUS Official Support", "https://www.asus.com/support/")),
        "lg" to listOf(Source("LG Official Support", "https://www.lg.com/us/support/")),
        "htc" to listOf(Source("HTC Official Support", "https://www.htc.com/us/support/")),
        "zte" to listOf(Source("ZTE Official Support", "https://www.ztedevices.com/en/support/")),
        "hmd" to listOf(Source("HMD Official Support", "https://www.hmd.com/en_int/support"))
    )

    fun forBrand(brand: String, model: String, region: String): List<Source> {
        val key = brand.trim().lowercase()
        val query = listOf(brand, model, region, "official firmware download")
            .filter { it.isNotBlank() }.joinToString(" ")
        val portal = sources[key].orEmpty()
        val scopedSearch = when (key) {
            "samsung" -> "https://www.google.com/search?q=" + Uri.encode("site:samsung.com $query")
            "xiaomi" -> "https://www.google.com/search?q=" + Uri.encode("site:mi.com $query")
            "google" -> "https://developers.google.com/android/images"
            "motorola" -> "https://www.google.com/search?q=" + Uri.encode("site:motorola.com $query")
            "oneplus" -> "https://www.google.com/search?q=" + Uri.encode("site:oneplus.com $query")
            else -> if (portal.isNotEmpty()) "https://www.google.com/search?q=" + Uri.encode("site:${Uri.parse(portal.first().url).host} $query") else ""
        }
        return buildList {
            addAll(portal)
            if (scopedSearch.isNotBlank() && portal.none { it.url == scopedSearch })
                add(Source("Search this exact model on manufacturer domain", scopedSearch))
        }
    }
}
