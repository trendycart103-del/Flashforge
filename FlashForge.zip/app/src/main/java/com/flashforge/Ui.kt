package com.flashforge

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.layout.layout
import kotlin.math.roundToInt
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Soft light palette: navy text, orange section accents, pastel background. */
object C {
    val bg: Color get() = AppSettings.color("bg")
    val panel: Color get() = AppSettings.color("panel")
    val line: Color get() = AppSettings.color("text")
    val ink: Color get() = AppSettings.color("text")
    val blue: Color get() = AppSettings.color("blue")
    val orange: Color get() = AppSettings.color("orange")
    val amber: Color get() = AppSettings.color("amber")
    val green: Color get() = AppSettings.color("green")
    val red: Color get() = AppSettings.color("red")
    val yellow: Color get() = AppSettings.color("yellow")
    val yellowDark = Color(0xFF8A5A00)
    val text: Color get() = AppSettings.color("text")
    val dim: Color get() = AppSettings.color("dim")
    val off = Color(0xFFD9DEEA)
}

val Sans = FontFamily.Default

/** Lamp colour and readable text colour for each connection state. */
val Link.tint: Color get() = when (this) {
    Link.RED -> C.red
    Link.YELLOW -> C.yellow
    Link.GREEN -> C.green
}
val Link.ink: Color get() = when (this) {
    Link.RED -> C.red
    Link.YELLOW -> C.yellowDark
    Link.GREEN -> C.green
}
val Link.pill: String get() = when (this) {
    Link.RED -> "Not Connected"
    Link.YELLOW -> "Connecting"
    Link.GREEN -> "Connected"
}

// ---------------- shapes ----------------

val CardShape = RoundedCornerShape(32.dp)
val PanelShape = RoundedCornerShape(28.dp)
val FieldShape = RoundedCornerShape(18.dp)
val TabShape = RoundedCornerShape(18.dp)
val NavShape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)

/** Slanted button: both ends cut at an angle. */
val BtnShape = GenericShape { size, _ ->
    val s = size.height * 0.32f
    moveTo(s, 0f)
    lineTo(size.width, 0f)
    lineTo(size.width - s, size.height)
    lineTo(0f, size.height)
    close()
}

// ---------------- background ----------------

fun Modifier.blueprint(): Modifier = this.background(C.bg).drawBehind {
    // Soft pastel blobs on a pale blue-white base (pink, mint, lavender, peach).
    if (!AppSettings.blobs) return@drawBehind
    val w = size.width
    val h = size.height
    drawCircle(Color(0xFFFFE3EC), radius = w * 0.27f, center = Offset(w * 0.88f, h * 0.06f))
    drawCircle(Color(0xFFD6F5E7), radius = w * 0.27f, center = Offset(w * 0.04f, h * 0.42f))
    drawCircle(Color(0xFFE6E0FB), radius = w * 0.31f, center = Offset(w * 0.00f, h * 0.86f))
    drawCircle(Color(0xFFFBEBCB), radius = w * 0.32f, center = Offset(w * 0.96f, h * 0.83f))
}

// ---------------- text helpers ----------------

private val Acronyms = setOf("ROM", "ZIP", "ADB", "USB", "OEM", "SHA", "EDL", "OTG", "GSI", "FRP", "IMG", "AB", "AP", "BL", "CP", "CSC")

/** "REBOOT TO RECOVERY" -> "Reboot to recovery"; acronyms and one-letter words stay as they are. */
fun nice(t: String): String {
    val out = t.split(" ").joinToString(" ") { w ->
        val core = w.filter { it.isLetter() }
        if (core.length > 1 && core.all { it.isUpperCase() } && core !in Acronyms) w.lowercase() else w
    }
    return out.replaceFirstChar { it.uppercase() }
}

@Composable
fun T(s: String, c: Color = C.text, sz: Int = 12, bold: Boolean = false, mod: Modifier = Modifier) {
    Text(
        s, color = c, fontFamily = Sans, fontSize = (sz + 2).sp, lineHeight = ((sz + 2) * 1.35f).sp,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium, modifier = mod
    )
}

private val GoodValues = setOf("yes", "unlocked", "granted", "allowed", "on")

@Composable
fun KV(k: String, v: String) {
    val vc = if (v.trim().lowercase() in GoodValues) C.green else C.text
    Row(
        Modifier.fillMaxWidth()
            .drawBehind { drawLine(C.ink.copy(alpha = 0.08f), Offset(0f, size.height), Offset(size.width, size.height), 1.dp.toPx()) }
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(k, color = C.dim, fontFamily = Sans, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(0.5f))
        Text(
            v, color = vc, fontFamily = Sans, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.End, modifier = Modifier.weight(0.5f)
        )
    }
}

/** Rounded white card with an orange dot title. The outline turns blue on touch or focus. */
@Composable
fun Panel(title: String, startOpen: Boolean = true, content: @Composable ColumnScope.() -> Unit) {
    var open by remember { mutableStateOf(startOpen) }
    val frac by animateFloatAsState(if (open) 1f else 0f, tween(260), label = "panelOpen")
    var focused by remember { mutableStateOf(false) }
    var pressed by remember { mutableStateOf(false) }
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val active = focused || pressed
    val appear by animateFloatAsState(if (shown) 1f else 0f, tween(450), label = "appear")
    val bw by animateDpAsState(if (active) 2.dp else 1.dp, tween(200), label = "bw")
    val bc by animateColorAsState(if (active) C.blue else C.ink.copy(alpha = 0.06f), tween(250), label = "bc")
    val glow by animateFloatAsState(if (active) 0.08f else 0f, tween(300), label = "glow")
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 7.dp)
            .graphicsLayer { alpha = appear; translationY = (1f - appear) * 48f }
            .background(C.panel.copy(alpha = 0.82f), PanelShape)
            .background(C.blue.copy(alpha = glow), PanelShape)
            .border(bw, bc, PanelShape)
            .onFocusChanged { focused = it.hasFocus }
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val e = awaitPointerEvent(PointerEventPass.Initial)
                        pressed = e.changes.any { it.pressed }
                    }
                }
            }
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().clip(FieldShape).clickable { open = !open }.padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(13.dp).background(C.orange, CircleShape))
            Spacer(Modifier.width(10.dp))
            Text(
                title, color = C.amber, fontFamily = Sans, fontSize = 15.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.weight(1f)
            )
            Text(if (open) "\u2212" else "+", color = C.amber, fontFamily = Sans, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        // The content stays composed while folded (so typed text and state are kept); it is only measured to zero height.
        Column(
            Modifier.clipToBounds().layout { m, c ->
                val p = m.measure(c)
                val h = (p.height * frac).roundToInt()
                layout(p.width, h) { p.placeRelative(0, 0) }
            }
        ) {
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
fun Rw(content: @Composable RowScope.() -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), content = content)
}

/** Picks the graphical icon that is drawn inside a button, from the button label. */
fun iconFor(t: String): Int {
    val u = t.uppercase()
    return when {
        u.startsWith("REFRESH") || u.startsWith("READ TABLE") -> R.drawable.b_refresh
        u.startsWith("SLOT") -> R.drawable.b_slot
        u.startsWith("REBOOT TO RECOVERY") || u == "RECOVERY" -> R.drawable.b_recovery
        u == "SYSTEM" || u.startsWith("REBOOT SYSTEM") -> R.drawable.b_power
        u == "BOOTLOADER" -> R.drawable.b_boot
        u == "FASTBOOTD" -> R.drawable.b_term
        u.startsWith("ADD IMAGE") -> R.drawable.b_image
        u.startsWith("UNPACK") -> R.drawable.b_zip
        u.startsWith("FLASH") -> R.drawable.b_bolt
        u.startsWith("SAVE") -> R.drawable.b_save
        u.startsWith("DOWNLOAD") || u.startsWith("UPDATE") -> R.drawable.b_download
        u.startsWith("ERASE") || u.startsWith("DELETE") || u.startsWith("WIPE") -> R.drawable.b_trash
        u.startsWith("BACKUP") -> R.drawable.b_backup
        u.startsWith("CREATE") -> R.drawable.b_plus
        u.startsWith("RESIZE") -> R.drawable.b_resize
        u.startsWith("UNLOCK") -> R.drawable.b_unlock
        u.startsWith("LOCK") -> R.drawable.b_lock
        u.startsWith("CHOOSE") -> R.drawable.b_folder
        u.startsWith("SIDELOAD") -> R.drawable.b_upload
        u.startsWith("EXPORT") -> R.drawable.b_export
        u.startsWith("CLEAR") -> R.drawable.b_clear
        u.startsWith("GRANT") || u.startsWith("BUBBLE") || u.startsWith("TEST") -> R.drawable.b_bubble
        u.startsWith("ALLOW") -> R.drawable.b_bell
        else -> 0
    }
}

/** Small rounded-square icon button (used in the flash queue). */
@Composable
fun IconBtn(res: Int, on: () -> Unit) {
    val sh = RoundedCornerShape(12.dp)
    Box(
        Modifier
            .padding(horizontal = 3.dp)
            .size(38.dp)
            .clip(sh)
            .background(C.panel)
            .border(1.dp, C.ink.copy(alpha = 0.12f), sh)
            .clickable(onClick = on),
        contentAlignment = Alignment.Center
    ) { Image(painterResource(res), null, Modifier.size(22.dp)) }
}

/** Gradient pairs (start, end) in the style of the reference screenshot. */
private val BtnGradients = listOf(
    Color(0xFFFF5252) to Color(0xFFFFB300),  // coral to amber
    Color(0xFF00B0FF) to Color(0xFF5B5BFF),  // sky to indigo
    Color(0xFF00C98D) to Color(0xFF0E9AA7),  // green to teal
    Color(0xFF8E5BFF) to Color(0xFFE040C8),  // violet to magenta
    Color(0xFF1E88E5) to Color(0xFF26A69A),  // blue to teal
    Color(0xFFFF7043) to Color(0xFFEC407A)   // orange to pink
)
private val DangerGradient = Color(0xFFFF3D57) to Color(0xFFFF8A3D)

private fun gradFor(t: String, danger: Boolean): Pair<Color, Color> {
    if (danger) return DangerGradient
    val u = t.uppercase()
    return when {
        u.startsWith("FLASH") -> BtnGradients[0]
        u.startsWith("REFRESH") || u.startsWith("READ") -> BtnGradients[1]
        u.startsWith("UNLOCK") || u.startsWith("LOCK") -> BtnGradients[2]
        u.startsWith("BACKUP") || u.startsWith("SAVE") -> BtnGradients[3]
        u.startsWith("DOWNLOAD") || u.startsWith("UPDATE") -> BtnGradients[4]
        else -> BtnGradients[(t.hashCode() and 0x7fffffff) % BtnGradients.size]
    }
}

@Composable
fun Btn(t: String, enabled: Boolean = true, danger: Boolean = false, mod: Modifier = Modifier, icon: Int = iconFor(t), on: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pr by src.collectIsPressedAsState()
    val sc by animateFloatAsState(
        if (pr) 0.94f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "btnScale"
    )
    val (g1, g2) = gradFor(t, danger)
    val brush = if (enabled) Brush.linearGradient(listOf(g1, g2)) else Brush.linearGradient(listOf(C.off, C.off))
    Button(
        onClick = on, enabled = enabled,
        modifier = mod
            .padding(vertical = 4.dp)
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .background(brush, BtnShape),
        shape = BtnShape,
        interactionSource = src,
        elevation = null,
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent, contentColor = Color.White,
            disabledContainerColor = Color.Transparent, disabledContentColor = C.dim
        )
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            if (icon != 0) {
                Box(
                    Modifier.size(32.dp).background(Color.White.copy(alpha = 0.92f), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(painterResource(icon), null, Modifier.size(22.dp), alpha = if (enabled) 1f else 0.45f)
                }
                Spacer(Modifier.width(7.dp))
            }
            Text(
                nice(t), fontFamily = Sans, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 2, textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun ConfirmBtn(t: String, msg: String, enabled: Boolean = true, danger: Boolean = true, mod: Modifier = Modifier, go: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Btn(t, enabled, danger, mod) { open = true }
    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            confirmButton = { TextButton(onClick = { open = false; go() }) { Text("CONFIRM", color = C.red, fontFamily = Sans, fontWeight = FontWeight.Bold) } },
            dismissButton = { TextButton(onClick = { open = false }) { Text("CANCEL", color = C.dim, fontFamily = Sans, fontWeight = FontWeight.SemiBold) } },
            title = { Text(nice(t), fontFamily = Sans, fontWeight = FontWeight.Bold) },
            text = { Text(msg, fontFamily = Sans, fontSize = 15.sp, fontWeight = FontWeight.Medium) },
            shape = PanelShape,
            containerColor = C.panel, titleContentColor = C.amber, textContentColor = C.text
        )
    }
}

@Composable
fun Field(v: String, onv: (String) -> Unit, label: String) {
    OutlinedTextField(
        value = v, onValueChange = onv, singleLine = true, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        shape = FieldShape,
        label = { Text(label, fontFamily = Sans, fontSize = 13.sp, fontWeight = FontWeight.Medium) },
        textStyle = TextStyle(fontFamily = Sans, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = C.text),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = C.text, unfocusedTextColor = C.text,
            focusedContainerColor = C.panel.copy(alpha = 0.85f),
            unfocusedContainerColor = C.panel.copy(alpha = 0.55f),
            focusedBorderColor = C.blue, unfocusedBorderColor = C.ink.copy(alpha = 0.22f),
            focusedLabelColor = C.blue, unfocusedLabelColor = C.dim, cursorColor = C.blue
        )
    )
}

@Composable
fun PickBtn(label: String, mod: Modifier = Modifier, on: (Uri) -> Unit) {
    val l = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) on(u) }
    Btn(label, mod = mod) { l.launch(arrayOf("*/*")) }
}

// ---------------- header card ----------------

/** App logo: the Flash Forge mark (two phones joined by an OTG/USB cable, flash window and fastboot gear). */
@Composable
fun AppLogo(size: androidx.compose.ui.unit.Dp = 56.dp) {
    Image(painterResource(R.drawable.ic_logo), contentDescription = "FlashForge logo", modifier = Modifier.size(size))
}

/** Two-tone wordmark: "Flash" in text colour, "Forge" in the logo orange. */
@Composable
fun AppWordmark(fontSize: androidx.compose.ui.unit.TextUnit = 22.sp) {
    Text(
        buildAnnotatedString {
            withStyle(SpanStyle(color = C.text)) { append("Flash") }
            withStyle(SpanStyle(color = Color(0xFFE4501A))) { append("Forge") }
        },
        fontFamily = Sans, fontSize = fontSize, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false
    )
}

/** Connection state pill: green = linked, blinking yellow = linking, red = no link. */
@Composable
fun LinkPill(vm: MainVM) {
    val l = vm.link
    val inf = rememberInfiniteTransition(label = "link")
    val blink by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(450, easing = LinearEasing), RepeatMode.Reverse), label = "blink")
    val main by animateColorAsState(l.tint, tween(300), label = "linkColor")
    val dotAlpha = if (l == Link.YELLOW && blink < 0.5f) 0.2f else 1f
    Row(
        Modifier.clip(CircleShape).background(main.copy(alpha = 0.16f)).padding(horizontal = 9.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(12.dp).background(main.copy(alpha = dotAlpha), CircleShape))
        Spacer(Modifier.width(8.dp))
        Text(l.pill, color = l.ink, fontFamily = Sans, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
fun Header(vm: MainVM) {
    Column(
        Modifier.fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .background(C.panel.copy(alpha = 0.85f), CardShape)
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppLogo()
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                AppWordmark()
                if (vm.mode != Mode.NONE) {
                    Text(
                        vm.vendor + " | " + vm.usbId + " | " + vm.mode.label.lowercase(),
                        color = C.dim, fontFamily = Sans, fontSize = 15.sp, fontWeight = FontWeight.Medium
                    )
                }
            }
            Spacer(Modifier.width(6.dp))
            LinkPill(vm)
        }
        if (vm.mode != Mode.NONE) {
            Spacer(Modifier.height(8.dp))
            Text(
                vm.linkNote + "  " + vm.linkPct.toString() + "%",
                color = C.dim, fontFamily = Sans, fontSize = 12.sp, fontWeight = FontWeight.Medium,
                maxLines = 1
            )
        }
    }
}

// ---------------- bottom navigation ----------------

private val NavItemWidth = 86.dp

@Composable
fun TabItem(s: Screen, sel: Boolean, onClick: () -> Unit) {
    val sc by animateFloatAsState(
        if (sel) 1.15f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "tabScale"
    )
    val col by animateColorAsState(if (sel) C.blue else C.dim, tween(250), label = "tabColor")
    val bgA by animateFloatAsState(if (sel) 0.10f else 0f, tween(300), label = "tabBg")
    Column(
        Modifier
            .width(NavItemWidth)
            .padding(horizontal = 3.dp, vertical = 8.dp)
            .clip(TabShape)
            .background(C.blue.copy(alpha = bgA))
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painterResource(s.icon), null,
            Modifier.size(30.dp).graphicsLayer { scaleX = sc; scaleY = sc; alpha = if (sel) 1f else 0.85f }
        )
        Spacer(Modifier.height(3.dp))
        Text(
            nice(s.title), color = col, fontFamily = Sans, fontSize = 12.sp,
            fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium, maxLines = 1, softWrap = false,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun TabBar(vm: MainVM) {
    val sv = rememberScrollState()
    val density = LocalDensity.current
    val screenW = LocalConfiguration.current.screenWidthDp
    val tabs = Screen.values().filter { AppSettings.tabVisible(it) }
    LaunchedEffect(vm.screen, tabs.size) {
        val itemPx = with(density) { NavItemWidth.toPx() }
        val viewPx = with(density) { screenW.dp.toPx() }
        val target = (tabs.indexOf(vm.screen).coerceAtLeast(0) * itemPx - (viewPx - itemPx) / 2f).toInt().coerceAtLeast(0)
        sv.animateScrollTo(target)
    }
    Row(
        Modifier.fillMaxWidth()
            .shadow(12.dp, NavShape)
            .background(C.panel.copy(alpha = 0.95f), NavShape)
            .horizontalScroll(sv)
            .padding(horizontal = 6.dp)
    ) {
        tabs.forEach { s -> TabItem(s, vm.screen == s) { vm.screen = s } }
    }
}

/** Flash progress bar: flowing gradient, moving stripes, glowing head with sparks. Sweeps while loading. */
@Composable
fun FlashBar(busy: Boolean, progress: Float, modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "flashbar")
    val phase by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(700, easing = LinearEasing)), label = "stripe")
    val sweep by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1300, easing = LinearEasing)), label = "sweep")
    val pulse by inf.animateFloat(0.55f, 1f, infiniteRepeatable(tween(450), RepeatMode.Reverse), label = "pulse")
    val p by animateFloatAsState(if (busy) progress else 0f, tween(350), label = "barP")
    val loading = busy && progress <= 0f
    Canvas(modifier.fillMaxWidth().height(18.dp)) {
        val w = size.width
        val h = size.height
        val r = h / 2f
        val shape = Path().apply { addRoundRect(RoundRect(0f, 0f, w, h, CornerRadius(r, r))) }
        drawPath(shape, C.off)
        if (!busy) return@Canvas
        val grad = listOf(Color(0xFF3D6BFF), Color(0xFF8A55E8), Color(0xFFD9467F), Color(0xFFFF7A1A))
        clipPath(shape) {
            if (loading) {
                val segW = w * 0.34f
                val x0 = -segW + (w + segW) * sweep
                drawRect(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, Color(0xFF3D6BFF), Color(0xFFD9467F), Color(0xFFFF7A1A), Color.Transparent),
                        startX = x0, endX = x0 + segW
                    ),
                    topLeft = Offset(x0, 0f), size = androidx.compose.ui.geometry.Size(segW, h)
                )
            } else {
                val fillW = (maxOf(p, 0.03f) * w).coerceAtMost(w)
                clipRect(0f, 0f, fillW, h) {
                    drawRect(Brush.horizontalGradient(grad, startX = 0f, endX = maxOf(fillW, 1f)), size = androidx.compose.ui.geometry.Size(fillW, h))
                    val sw = h * 1.3f
                    var i = -2
                    while (i * sw < fillW + sw) {
                        val x = i * sw + phase * sw
                        val stripe = Path().apply {
                            moveTo(x, h); lineTo(x + sw * 0.45f, h); lineTo(x + sw * 0.45f + h * 0.6f, 0f); lineTo(x + h * 0.6f, 0f); close()
                        }
                        drawPath(stripe, Color.White.copy(alpha = 0.22f))
                        i++
                    }
                }
                val hx = fillW
                drawCircle(Color(0xFFFF7A1A).copy(alpha = 0.35f * pulse), radius = h * 1.0f * pulse, center = Offset(hx, r))
                drawCircle(Color.White, radius = h * 0.32f, center = Offset(hx, r))
                for (k in 0 until 3) {
                    val t = (phase + k / 3f) % 1f
                    drawCircle(
                        Color.White.copy(alpha = (1f - t) * 0.9f), radius = h * 0.09f,
                        center = Offset(hx - t * h * 2.2f, r + (k - 1) * h * 0.22f)
                    )
                }
            }
        }
    }
}

@Composable
fun Footer(vm: MainVM) {
    val p by animateFloatAsState(if (vm.busy) vm.progress else 0f, tween(300), label = "progress")
    Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            FlashBar(vm.busy, vm.progress, Modifier.weight(1f))
            if (vm.busy) {
                Spacer(Modifier.width(10.dp))
                Text(
                    if (vm.progress <= 0f) "..." else (p * 100).toInt().toString() + "%",
                    color = C.blue, fontFamily = Sans, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        T(vm.logs.lastOrNull() ?: "Ready", C.dim, 11, true)
    }
}

@Composable
fun AppUi(vm: MainVM) {
    val d = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(d.density, d.fontScale * AppSettings.textScale)) {
        AppUiBody(vm)
    }
}

@Composable
private fun AppUiBody(vm: MainVM) {
    MaterialTheme(
        colorScheme = lightColorScheme(primary = C.blue, background = C.bg, surface = C.panel, onSurface = C.text, onBackground = C.text)
    ) {
        Box(Modifier.fillMaxSize().background(C.bg)) {
        AppBackground()
        Column(Modifier.fillMaxSize()) {
            Header(vm)
            Box(Modifier.weight(1f).fillMaxWidth()) {
                AnimatedContent(
                    targetState = vm.screen,
                    transitionSpec = {
                        (fadeIn(tween(280)) + slideInHorizontally(tween(280)) { it / 8 }) togetherWith fadeOut(tween(120))
                    },
                    label = "screen"
                ) { s ->
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp)) {
                        when (s) {
                            Screen.DEVICE -> DevicePage(vm)
                            Screen.FLASH -> FlashPage(vm)
                            Screen.PART -> PartPage(vm)
                            Screen.UNLOCK -> UnlockPage(vm)
                            Screen.ROM -> RomPage(vm)
                            Screen.ROOT -> RootPage(vm)
                            Screen.MODES -> ModesPage(vm)
                            Screen.LOG -> LogPage(vm)
                            Screen.SAFETY -> SafetyPage(vm)
                            Screen.SETTINGS -> SettingsPage(vm)
                        }
                    }
                }
            }
            Footer(vm)
            TabBar(vm)
        }
        }
        vm.cableWarn?.let { why ->
            AlertDialog(
                onDismissRequest = { },
                icon = { Image(painterResource(R.drawable.ic_cable), null, Modifier.size(52.dp)) },
                title = { Text("CHANGE THE DATA CABLE", fontFamily = Sans, fontWeight = FontWeight.Bold, fontSize = 17.sp) },
                text = {
                    Column {
                        Text(why, fontFamily = Sans, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Use a short, good quality DATA cable (not a charge-only cable) and plug it straight into the phone or a good OTG adapter, without a hub. The task keeps running; if it fails, swap the cable and run it again.",
                            fontFamily = Sans, fontSize = 13.sp, fontWeight = FontWeight.Medium
                        )
                    }
                },
                confirmButton = { TextButton(onClick = { vm.cableChange() }) { Text("I WILL CHANGE IT", color = C.blue, fontFamily = Sans, fontWeight = FontWeight.Bold) } },
                dismissButton = { TextButton(onClick = { vm.cableContinue() }) { Text("CONTINUE ANYWAY", color = C.dim, fontFamily = Sans, fontWeight = FontWeight.SemiBold) } },
                shape = PanelShape,
                containerColor = C.panel, titleContentColor = C.red, textContentColor = C.text
            )
        }
    }
}
