package com.flashforge

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

/**
 * All user-changeable values of the app. Everything is stored in its own SharedPreferences file and read
 * through Compose state, so a change on the Settings page is applied immediately.
 * Safety gates (product ID check, checksums, slot and partition-size checks) are NOT settings and cannot be turned off here.
 */
object AppSettings {
    const val MIN_BATTERY_FLOOR = 40

    val colorDefaults: Map<String, Long> = linkedMapOf(
        "bg" to 0xFFF4F8FFL,
        "panel" to 0xFFFFFFFFL,
        "text" to 0xFF1B2766L,
        "dim" to 0xFF5D6C9BL,
        "blue" to 0xFF3A66FFL,
        "orange" to 0xFFFF7A1AL,
        "amber" to 0xFFB85208L,
        "green" to 0xFF0E7A45L,
        "red" to 0xFFE5334DL,
        "yellow" to 0xFFFFB300L
    )

    val colorLabels: Map<String, String> = linkedMapOf(
        "bg" to "Background",
        "panel" to "Cards and panels",
        "text" to "Main text",
        "dim" to "Secondary text",
        "blue" to "Accent (selected tab, focus)",
        "orange" to "Section dot",
        "amber" to "Section titles and warnings",
        "green" to "Success",
        "red" to "Error and danger",
        "yellow" to "Connecting lamp"
    )

    /** Tabs that can never be hidden. */
    private val alwaysVisible = setOf(Screen.DEVICE, Screen.SAFETY, Screen.SETTINGS)

    private var sp: SharedPreferences? = null
    private val overrides = mutableStateMapOf<String, Long>()
    private val hidden = mutableStateListOf<String>()

    var blobs by mutableStateOf(true)
    var textScale by mutableStateOf(1.0f)
    var slowMbs by mutableStateOf(2.0)
    var flapLimit by mutableIntStateOf(3)
    var slowSamples by mutableIntStateOf(3)
    var logMax by mutableIntStateOf(400)
    var minBattery by mutableIntStateOf(MIN_BATTERY_FLOOR)
    var defBackup by mutableStateOf("boot")
    var defRecovery by mutableStateOf("recovery")
    var defPatched by mutableStateOf("boot")

    /** Bumped on reset so text fields on the Settings page reload their value. */
    var resetTick by mutableIntStateOf(0)

    fun init(ctx: Context) {
        if (sp != null) return
        val p = ctx.applicationContext.getSharedPreferences("flashforge_settings", Context.MODE_PRIVATE)
        try {
            colorDefaults.keys.forEach { k -> if (p.contains("c_$k")) overrides[k] = p.getLong("c_$k", colorDefaults.getValue(k)) }
            blobs = p.getBoolean("blobs", true)
            textScale = p.getFloat("scale", 1.0f).coerceIn(0.8f, 1.4f)
            slowMbs = p.getFloat("slow", 2.0f).toDouble().coerceIn(0.5, 10.0)
            flapLimit = p.getInt("flap", 3).coerceIn(2, 6)
            slowSamples = p.getInt("samples", 3).coerceIn(2, 10)
            logMax = p.getInt("logmax", 400).coerceIn(100, 2000)
            minBattery = p.getInt("minbat", MIN_BATTERY_FLOOR).coerceIn(MIN_BATTERY_FLOOR, 90)
            defBackup = cleanPart(p.getString("d_backup", "boot") ?: "boot")
            defRecovery = cleanPart(p.getString("d_recovery", "recovery") ?: "recovery")
            defPatched = cleanPart(p.getString("d_patched", "boot") ?: "boot")
            hidden.clear()
            (p.getString("hidden", "") ?: "").split(",").filter { n -> Screen.values().any { it.name == n && it !in alwaysVisible } }.forEach { hidden.add(it) }
        } catch (e: Exception) {
            android.util.Log.w("FlashForge", "Settings could not be read; defaults are used", e)
        }
        sp = p
    }

    private fun persist() {
        val e = sp?.edit() ?: return
        e.clear()
        overrides.forEach { (k, v) -> e.putLong("c_$k", v) }
        e.putBoolean("blobs", blobs)
        e.putFloat("scale", textScale)
        e.putFloat("slow", slowMbs.toFloat())
        e.putInt("flap", flapLimit)
        e.putInt("samples", slowSamples)
        e.putInt("logmax", logMax)
        e.putInt("minbat", minBattery)
        e.putString("d_backup", defBackup)
        e.putString("d_recovery", defRecovery)
        e.putString("d_patched", defPatched)
        e.putString("hidden", hidden.joinToString(","))
        e.apply()
    }

    // ---- colours ----
    fun color(key: String): Color = Color(overrides[key] ?: colorDefaults.getValue(key))

    fun hex(key: String): String = "%06X".format(color(key).toArgb() and 0xFFFFFF)

    /** rgb = six hex digits. Returns false (and changes nothing) for anything else. */
    fun setColor(key: String, rgb: String): Boolean {
        if (key !in colorDefaults || rgb.length != 6 || !rgb.all { it in "0123456789ABCDEFabcdef" }) return false
        overrides[key] = 0xFF000000L or rgb.toLong(16)
        persist()
        return true
    }

    fun resetColors() {
        overrides.clear()
        resetTick++
        persist()
    }

    // ---- display ----
    fun changeBlobs() { blobs = !blobs; persist() }

    fun stepTextScale(d: Float) {
        textScale = (Math.round((textScale + d) * 100f) / 100f).coerceIn(0.8f, 1.4f)
        persist()
    }

    // ---- tabs ----
    fun tabVisible(s: Screen): Boolean = s in alwaysVisible || s.name !in hidden
    fun tabCanHide(s: Screen): Boolean = s !in alwaysVisible

    fun toggleTab(s: Screen) {
        if (!tabCanHide(s)) return
        if (s.name in hidden) hidden.remove(s.name) else hidden.add(s.name)
        persist()
    }

    // ---- defaults ----
    fun cleanPart(s: String): String = s.trim().filter { it.isLetterOrDigit() || it == '_' || it == '-' }.take(40)

    fun setDefBackup(s: String) { defBackup = cleanPart(s); persist() }
    fun setDefRecovery(s: String) { defRecovery = cleanPart(s); persist() }
    fun setDefPatched(s: String) { defPatched = cleanPart(s); persist() }

    // ---- USB cable alert and log ----
    fun stepSlowMbs(d: Double) { slowMbs = (Math.round((slowMbs + d) * 10.0) / 10.0).coerceIn(0.5, 10.0); persist() }
    fun stepFlapLimit(d: Int) { flapLimit = (flapLimit + d).coerceIn(2, 6); persist() }
    fun stepSlowSamples(d: Int) { slowSamples = (slowSamples + d).coerceIn(2, 10); persist() }
    fun stepLogMax(d: Int) { logMax = (logMax + d).coerceIn(100, 2000); persist() }

    // ---- safety limit (can only be raised above the built-in minimum) ----
    fun stepMinBattery(d: Int) { minBattery = (minBattery + d).coerceIn(MIN_BATTERY_FLOOR, 90); persist() }

    fun resetAll() {
        overrides.clear()
        hidden.clear()
        blobs = true
        textScale = 1.0f
        slowMbs = 2.0
        flapLimit = 3
        slowSamples = 3
        logMax = 400
        minBattery = MIN_BATTERY_FLOOR
        defBackup = "boot"
        defRecovery = "recovery"
        defPatched = "boot"
        resetTick++
        persist()
    }
}
