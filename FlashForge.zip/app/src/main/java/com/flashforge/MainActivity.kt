package com.flashforge

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.hardware.usb.UsbManager
import android.hardware.usb.UsbDevice
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val vm: MainVM by viewModels()

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        vm.refreshPerms()
        askOverlayPermission()
    }

    /** Asks (once per fresh start, only while missing) for the permissions the floating bubble needs. */
    private fun askBubblePermissions() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS) else askOverlayPermission()
    }

    private fun askOverlayPermission() {
        if (Settings.canDrawOverlays(this)) return
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            android.util.Log.w("FlashForge", "Could not open the overlay permission screen", e)
        }
    }

    private fun openRequestedScreen(i: Intent?) {
        if (i?.getStringExtra(EXTRA_SCREEN) == "FLASH") vm.screen = Screen.FLASH
    }

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    @Suppress("DEPRECATION")
                    val detached = if (Build.VERSION.SDK_INT >= 33)
                        i.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                    else i.getParcelableExtra(UsbManager.EXTRA_DEVICE) as? UsbDevice
                    vm.onDetached(detached)
                }
                else -> vm.scan()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val f = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
            addAction(MainVM.ACTION)
        }
        ContextCompat.registerReceiver(this, rx, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        setContent { AppUi(vm) }
        openRequestedScreen(intent)
        if (savedInstanceState == null) askBubblePermissions()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        openRequestedScreen(intent)
    }

    override fun onStart() {
        super.onStart()
        FlashStatus.appFg = true
    }

    override fun onStop() {
        FlashStatus.appFg = false
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        FlashStatus.appFg = true
        vm.refreshPerms()
        vm.scan()
    }

    override fun onDestroy() {
        unregisterReceiver(rx)
        super.onDestroy()
    }

    companion object {
        const val EXTRA_SCREEN = "open_screen"
    }
}
