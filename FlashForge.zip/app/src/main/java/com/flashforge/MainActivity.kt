package com.flashforge

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbManager
import android.hardware.usb.UsbDevice
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val vm: MainVM by viewModels()

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    @Suppress("DEPRECATION")
                    val detached = if (Build.VERSION.SDK_INT >= 33)
                        i.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                    else i.getParcelableExtra(UsbManager.EXTRA_DEVICE) as? UsbDevice
                    vm.onDetached(detached)
                }
                else -> vm.scan()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val f = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
            addAction(MainVM.ACTION)
        }
        ContextCompat.registerReceiver(this, rx, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        setContent { AppUi(vm) }
    }

    override fun onStart() {
        super.onStart()
        FlashStatus.appFg = true
    }

    override fun onStop() {
        FlashStatus.appFg = false
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        FlashStatus.appFg = true
        vm.refreshPerms()
        vm.scan()
    }

    override fun onDestroy() {
        unregisterReceiver(rx)
        super.onDestroy()
    }
}
