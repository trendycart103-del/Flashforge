package com.flashforge

import android.content.ContentResolver
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.net.Uri
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import java.security.MessageDigest

/** Minimal ADB host: connects to a recovery in "Apply update from ADB" mode and serves a ZIP. */
class AdbSideload(private val conn: UsbDeviceConnection, private val dev: UsbDevice) {
    private var inEp: UsbEndpoint? = null
    private var outEp: UsbEndpoint? = null
    private var iface: UsbInterface? = null

    fun close() {
        try { iface?.let { conn.releaseInterface(it) } } catch (e: Exception) { android.util.Log.w("FlashForgeAdb", "ADB interface release failed", e) }
        iface = null; inEp = null; outEp = null
    }

    private class Pkt(val cmd: Int, val a0: Int, val a1: Int, val data: ByteArray)

    companion object {
        const val A_CNXN = 0x4e584e43
        const val A_OPEN = 0x4e45504f
        const val A_OKAY = 0x59414b4f
        const val A_WRTE = 0x45545257
        const val A_AUTH = 0x48545541
        const val BLOCK = 65536
    }

    fun open(): Boolean {
        for (i in 0 until dev.interfaceCount) {
            val f = dev.getInterface(i)
            if (f.interfaceClass == 0xFF && f.interfaceSubclass == 0x42 && f.interfaceProtocol == 0x01) {
                var a: UsbEndpoint? = null
                var b: UsbEndpoint? = null
                for (e in 0 until f.endpointCount) {
                    val ep = f.getEndpoint(e)
                    if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                        if (ep.direction == UsbConstants.USB_DIR_IN) a = ep else b = ep
                    }
                }
                if (a != null && b != null && conn.claimInterface(f, true)) {
                    inEp = a; outEp = b; iface = f
                    return true
                }
            }
        }
        return false
    }

    private fun sendPkt(cmd: Int, a0: Int, a1: Int, data: ByteArray = ByteArray(0), len: Int = data.size): Boolean {
        val h = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN)
        if (len < 0 || len > BLOCK || len > data.size) return false
        var sum = 0L
        for (i in 0 until len) sum = (sum + (data[i].toInt() and 0xff)) and 0xffffffffL
        val checksum = sum.toInt()
        h.putInt(cmd); h.putInt(a0); h.putInt(a1); h.putInt(len); h.putInt(checksum); h.putInt(cmd xor -1)
        if (!writeExact(h.array(), 24)) return false
        return len == 0 || writeExact(data, len)
    }

    private fun writeExact(data: ByteArray, length: Int): Boolean {
        var off = 0
        while (off < length) {
            val n = minOf(16384, length - off)
            val r = conn.bulkTransfer(outEp, data, off, n, 10000)
            if (r <= 0) return false
            off += r
        }
        return true
    }

    private fun readExact(data: ByteArray, length: Int, timeout: Int): Boolean {
        var off = 0
        while (off < length) {
            val n = minOf(16384, length - off)
            val r = conn.bulkTransfer(inEp, data, off, n, timeout)
            if (r <= 0) return false
            off += r
        }
        return true
    }

    private fun readPkt(timeout: Int): Pkt? {
        val hb = ByteArray(24)
        if (!readExact(hb, 24, timeout)) return null
        val h = ByteBuffer.wrap(hb).order(ByteOrder.LITTLE_ENDIAN)
        val cmd = h.int
        val a0 = h.int
        val a1 = h.int
        val len = h.int
        val checksum = h.int
        val magic = h.int
        if (magic != (cmd xor -1) || len < 0 || len > BLOCK) return null
        val data = ByteArray(len)
        if (len > 0 && !readExact(data, len, timeout)) return null
        val actual = data.fold(0L) { acc, byte -> (acc + (byte.toInt() and 0xff)) and 0xffffffffL }.toInt()
        if (actual != checksum) return null
        return Pkt(cmd, a0, a1, data)
    }

    fun sideload(resolver: ContentResolver, uri: Uri, size: Long, publisherChecksum: String, progress: (Float) -> Unit, log: (String) -> Unit): String {
        if (size <= 0L) return "BLOCKED: package size is missing or empty"
        if (!publisherChecksum.matches(Regex("[0-9a-fA-F]{64}"))) return "BLOCKED: a trusted publisher SHA-256 checksum is required for ADB sideload"
        // Open and validate the source before starting ADB protocol negotiation, so a bad URI
        // cannot leave recovery waiting for a package that the host cannot read.
        val pfd = try { resolver.openFileDescriptor(uri, "r") } catch (e: Exception) {
            return "Cannot open sideload package before connecting: ${e.message}"
        } ?: return "Cannot open sideload package"
        return pfd.use { descriptor ->
            if (descriptor.statSize <= 0L || descriptor.statSize != size) return "BLOCKED: package size is unknown or changed (selected=$size, file=${descriptor.statSize})"
            val channel = FileInputStream(descriptor.fileDescriptor).channel
            val expectedDigest = MessageDigest.getInstance("SHA-256")
            val hashBuffer = ByteBuffer.allocate(65536)
            var hashed = 0L
            channel.position(0)
            while (hashed < size) {
                hashBuffer.clear()
                hashBuffer.limit(minOf(hashBuffer.capacity().toLong(), size - hashed).toInt())
                val count = channel.read(hashBuffer)
                if (count <= 0) return "Could not read complete sideload package for integrity check"
                expectedDigest.update(hashBuffer.array(), 0, count)
                hashed += count
            }
            if (channel.size() != size) return "BLOCKED: sideload package size changed during integrity check"
            val expectedHash = expectedDigest.digest()
            val expectedHex = expectedHash.joinToString("") { "%02x".format(it) }
            if (!expectedHex.equals(publisherChecksum, true)) return "BLOCKED: package SHA-256 does not match the supplied publisher checksum"
            channel.position(0)
            if (!sendPkt(A_CNXN, 0x01000001, 256 * 1024, "host::\u0000".toByteArray())) return "CNXN send failed"
            val p = readPkt(5000) ?: return "No reply. Is the phone on 'Apply update from ADB'?"
            if (p.cmd == A_AUTH) return "Device asks for ADB authorization. Use recovery sideload mode."
            if (p.cmd != A_CNXN) return "Unexpected reply from device"
            val banner = String(p.data).trim('\u0000')
            log("Banner: $banner")
            val state = banner.substringBefore(':').trim().lowercase()
            if (state !in setOf("sideload", "recovery"))
                return "BLOCKED: recovery sideload state was not confirmed (ADB banner state='$state'). Normal Android ADB mode is not accepted; choose Recovery > Apply update from ADB."
            val svc = "sideload-host:$size:$BLOCK\u0000".toByteArray()
            if (!sendPkt(A_OPEN, 1, 0, svc)) return "OPEN failed"
            serve(channel, size, expectedHash, progress, log)
        }
    }

    private fun serve(ch: FileChannel, size: Long, expectedHash: ByteArray, progress: (Float) -> Unit, log: (String) -> Unit): String {
        val transferHash = MessageDigest.getInstance("SHA-256")
        var nextExpectedOffset = 0L
        while (true) {
            val p = readPkt(30000) ?: return "Timeout while waiting for device"
            when (p.cmd) {
                A_OKAY -> { }
                A_WRTE -> {
                    val msg = String(p.data).trim('\u0000').trim()
                    if (!sendPkt(A_OKAY, 1, p.a0)) return "Could not acknowledge recovery request"
                    if (msg.startsWith("DONEDONE") || msg.startsWith("DONE")) {
                        if (nextExpectedOffset != size) return "Recovery ended sideload before all package bytes were requested"
                        val actualHash = transferHash.digest()
                        if (!MessageDigest.isEqual(expectedHash, actualHash)) return "Sideload package content changed during transfer; installation result is not trusted"
                        val hex = actualHash.joinToString("") { "%02x".format(it) }
                        log("Sideload package local SHA-256 verified across transfer: $hex (this is integrity checking, not publisher authentication)")
                        progress(1f)
                        return "OK - transfer complete"
                    }
                    if (msg.startsWith("FAIL")) return "Device reported: $msg"
                    val idx = msg.toLongOrNull() ?: return "Bad block request: $msg"
                    if (idx < 0L || idx > Long.MAX_VALUE / BLOCK) return "Invalid or overflowing block request"
                    val off = idx * BLOCK
                    if (off >= size) return "Block request beyond end of file"
                    if (off != nextExpectedOffset) return "Out-of-order or duplicate recovery block request; transfer stopped"
                    val want = minOf(BLOCK.toLong(), size - off).toInt()
                    val bb = ByteBuffer.allocate(want)
                    try { ch.position(off) } catch (e: Exception) { return "Invalid package offset: ${e.message}" }
                    while (bb.hasRemaining()) {
                        val n = try { ch.read(bb) } catch (e: Exception) { return "Package read failed: ${e.message}" }
                        if (n <= 0) return "Could not read requested ZIP block"
                    }
                    transferHash.update(bb.array(), 0, want)
                    if (!sendPkt(A_WRTE, 1, p.a0, bb.array(), want)) return "USB write failed"
                    nextExpectedOffset += want
                    progress(nextExpectedOffset.toFloat() / size)
                }
                else -> return "Unexpected packet 0x${Integer.toHexString(p.cmd)}"
            }
        }
    }
}
