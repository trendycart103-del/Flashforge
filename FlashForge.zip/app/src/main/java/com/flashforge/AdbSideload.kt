package com.flashforge

import android.content.ContentResolver
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.net.Uri
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

/** Minimal ADB host: connects to a recovery in "Apply update from ADB" mode and serves a ZIP. */
class AdbSideload(private val conn: UsbDeviceConnection, private val dev: UsbDevice) {
    private var inEp: UsbEndpoint? = null
    private var outEp: UsbEndpoint? = null
    private var iface: UsbInterface? = null

    private class Pkt(val cmd: Int, val a0: Int, val a1: Int, val data: ByteArray)

    companion object {
        const val A_CNXN = 0x4e584e43
        const val A_OPEN = 0x4e45504f
        const val A_OKAY = 0x59414b4f
        const val A_WRTE = 0x45545257
        const val A_AUTH = 0x48545541
        const val BLOCK = 65536
    }

    fun open(): Boolean {
        for (i in 0 until dev.interfaceCount) {
            val f = dev.getInterface(i)
            if (f.interfaceClass == 0xFF && f.interfaceSubclass == 0x42 && f.interfaceProtocol == 0x01) {
                var a: UsbEndpoint? = null
                var b: UsbEndpoint? = null
                for (e in 0 until f.endpointCount) {
                    val ep = f.getEndpoint(e)
                    if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                        if (ep.direction == UsbConstants.USB_DIR_IN) a = ep else b = ep
                    }
                }
                if (a != null && b != null && conn.claimInterface(f, true)) {
                    inEp = a; outEp = b; iface = f
                    return true
                }
            }
        }
        return false
    }

    private fun sendPkt(cmd: Int, a0: Int, a1: Int, data: ByteArray = ByteArray(0), len: Int = data.size): Boolean {
        val h = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN)
        if (len < 0 || len > BLOCK || len > data.size) return false
        val checksum = data.take(len).fold(0L) { acc, byte -> (acc + (byte.toInt() and 0xff)) and 0xffffffffL }.toInt()
        h.putInt(cmd); h.putInt(a0); h.putInt(a1); h.putInt(len); h.putInt(checksum); h.putInt(cmd xor -1)
        if (!writeExact(h.array(), 24)) return false
        return len == 0 || writeExact(data, len)
    }

    private fun writeExact(data: ByteArray, length: Int): Boolean {
        var off = 0
        while (off < length) {
            val n = minOf(16384, length - off)
            val r = conn.bulkTransfer(outEp, data, off, n, 10000)
            if (r <= 0) return false
            off += r
        }
        return true
    }

    private fun readExact(data: ByteArray, length: Int, timeout: Int): Boolean {
        var off = 0
        while (off < length) {
            val n = minOf(16384, length - off)
            val r = conn.bulkTransfer(inEp, data, off, n, timeout)
            if (r <= 0) return false
            off += r
        }
        return true
    }

    private fun readPkt(timeout: Int): Pkt? {
        val hb = ByteArray(24)
        if (!readExact(hb, 24, timeout)) return null
        val h = ByteBuffer.wrap(hb).order(ByteOrder.LITTLE_ENDIAN)
        val cmd = h.int
        val a0 = h.int
        val a1 = h.int
        val len = h.int
        val checksum = h.int
        val magic = h.int
        if (magic != (cmd xor -1) || len < 0 || len > BLOCK) return null
        val data = ByteArray(len)
        if (len > 0 && !readExact(data, len, timeout)) return null
        val actual = data.fold(0L) { acc, byte -> (acc + (byte.toInt() and 0xff)) and 0xffffffffL }.toInt()
        if (actual != checksum) return null
        return Pkt(cmd, a0, a1, data)
    }

    fun sideload(resolver: ContentResolver, uri: Uri, size: Long, progress: (Float) -> Unit, log: (String) -> Unit): String {
        if (!sendPkt(A_CNXN, 0x01000001, 256 * 1024, "host::\u0000".toByteArray())) return "CNXN send failed"
        val p = readPkt(5000) ?: return "No reply. Is the phone on 'Apply update from ADB'?"
        if (p.cmd == A_AUTH) return "Device asks for ADB authorization. Use recovery sideload mode."
        if (p.cmd != A_CNXN) return "Unexpected reply from device"
        log("Banner: " + String(p.data).trim('\u0000'))
        val svc = "sideload-host:$size:$BLOCK\u0000".toByteArray()
        if (!sendPkt(A_OPEN, 1, 0, svc)) return "OPEN failed"
        val pfd = resolver.openFileDescriptor(uri, "r") ?: return "Cannot open file"
        return pfd.use { serve(FileInputStream(it.fileDescriptor).channel, size, progress) }
    }

    private fun serve(ch: FileChannel, size: Long, progress: (Float) -> Unit): String {
        while (true) {
            val p = readPkt(30000) ?: return "Timeout while waiting for device"
            when (p.cmd) {
                A_OKAY -> { }
                A_WRTE -> {
                    val msg = String(p.data).trim('\u0000').trim()
                    sendPkt(A_OKAY, 1, p.a0)
                    if (msg.startsWith("DONEDONE")) { progress(1f); return "OK - transfer complete" }
                    if (msg.startsWith("DONE")) { progress(1f); return "OK" }
                    if (msg.startsWith("FAIL")) return "Device reported: $msg"
                    val idx = msg.toLongOrNull() ?: return "Bad block request: $msg"
                    val off = idx * BLOCK
                    if (off >= size) return "Block request beyond end of file"
                    val want = minOf(BLOCK.toLong(), size - off).toInt()
                    val bb = ByteBuffer.allocate(want)
                    ch.position(off)
                    while (bb.hasRemaining()) { val n = ch.read(bb); if (n <= 0) return "Could not read requested ZIP block" }
                    if (!sendPkt(A_WRTE, 1, p.a0, bb.array(), want)) return "USB write failed"
                    progress(off.toFloat() / size)
                }
                else -> return "Unexpected packet 0x${Integer.toHexString(p.cmd)}"
            }
        }
    }
}
