package com.flashforge

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
private fun Stepper(label: String, value: String, onLess: () -> Unit, onMore: () -> Unit) {
    KV(label, value)
    Rw {
        Btn("LESS", mod = Modifier.weight(1f)) { onLess() }
        Btn("MORE", mod = Modifier.weight(1f)) { onMore() }
    }
}

@Composable
private fun ColorRow(key: String, label: String) {
    var text by remember(AppSettings.resetTick) { mutableStateOf(AppSettings.hex(key)) }
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(48.dp)
                .background(AppSettings.color(key), FieldShape)
                .border(1.dp, C.ink.copy(alpha = 0.3f), FieldShape)
        )
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) {
            Field(text, { v ->
                val t = v.trim().removePrefix("#").uppercase().filter { it.isLetterOrDigit() }.take(6)
                text = t
                if (t.length == 6) AppSettings.setColor(key, t)
            }, "$label (RRGGBB)")
        }
    }
}

@Composable
fun SettingsPage(vm: MainVM) {
    Panel("COLORS") {
        T("Type a 6-digit hex colour (for example 3A66FF). The app changes at once.", C.dim, 11)
        Spacer(Modifier.size(6.dp))
        AppSettings.colorLabels.forEach { (k, label) -> ColorRow(k, label) }
        Spacer(Modifier.size(6.dp))
        ConfirmBtn("RESET COLORS", "Restore the default colors?", danger = false) { AppSettings.resetColors() }
    }
    Panel("DISPLAY") {
        Stepper("Text size", "${Math.round(AppSettings.textScale * 100)}%", { AppSettings.stepTextScale(-0.05f) }, { AppSettings.stepTextScale(0.05f) })
        Spacer(Modifier.size(6.dp))
        Btn(if (AppSettings.blobs) "BACKGROUND SHAPES: ON" else "BACKGROUND SHAPES: OFF") { AppSettings.changeBlobs() }
    }
    Panel("TABS") {
        T("Choose which tabs appear in the bottom bar. Device, Safety and Settings always stay.", C.dim, 11)
        Spacer(Modifier.size(6.dp))
        Screen.values().filter { AppSettings.tabCanHide(it) }.chunked(2).forEach { pair ->
            Rw {
                pair.forEach { s ->
                    Btn(nice(s.title) + if (AppSettings.tabVisible(s)) ": ON" else ": OFF", mod = Modifier.weight(1f)) { AppSettings.toggleTab(s) }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
    BubblePanel(vm)
    Panel("DEVICE DATABASE (${vm.dbInfo})") {
        Field(vm.dbUrl, { vm.dbUrl = it }, "Raw GitHub URL of devices.json")
        Btn("UPDATE DATABASE", !vm.busy) { vm.updateDb(vm.dbUrl) }
    }
    Panel("DEFAULT PARTITION NAMES") {
        T("Used as the starting value in the Custom ROM and Root tabs. You can still change them on each page.", C.dim, 11)
        Field(AppSettings.defBackup, { AppSettings.setDefBackup(it) }, "Backup partition")
        Field(AppSettings.defRecovery, { AppSettings.setDefRecovery(it) }, "Recovery partition")
        Field(AppSettings.defPatched, { AppSettings.setDefPatched(it) }, "Patched boot image partition")
    }
    Panel("USB CABLE ALERT") {
        T("The alert asks you to change the cable when the link is unstable or slow.", C.dim, 11)
        Stepper("Slow speed below", "%.1f MiB/s".format(AppSettings.slowMbs), { AppSettings.stepSlowMbs(-0.5) }, { AppSettings.stepSlowMbs(0.5) })
        Stepper("Slow samples in a row", "${AppSettings.slowSamples}", { AppSettings.stepSlowSamples(-1) }, { AppSettings.stepSlowSamples(1) })
        Stepper("USB drops in 20 seconds", "${AppSettings.flapLimit}", { AppSettings.stepFlapLimit(-1) }, { AppSettings.stepFlapLimit(1) })
    }
    Panel("LOG") {
        Stepper("Lines kept in the USB log", "${AppSettings.logMax}", { AppSettings.stepLogMax(-100) }, { AppSettings.stepLogMax(100) })
    }
    Panel("SAFETY LIMIT") {
        Stepper("Minimum controller battery", "${AppSettings.minBattery}%", { AppSettings.stepMinBattery(-5) }, { AppSettings.stepMinBattery(5) })
        T("This limit can only be raised, never below ${AppSettings.MIN_BATTERY_FLOOR}%. Product ID check, checksums, slot and partition-size checks cannot be turned off.", C.amber, 11)
    }
    Panel("RESET") {
        ConfirmBtn("RESET ALL SETTINGS", "Restore every setting on this page (colors, tabs, defaults, limits) to its default? The database URL and bubble are kept.") { AppSettings.resetAll() }
    }
}
