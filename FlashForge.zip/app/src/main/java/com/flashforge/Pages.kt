package com.flashforge

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

private fun nm(u: Uri?): String = u?.lastPathSegment?.substringAfterLast('/') ?: "no file chosen"

@Composable
fun DevicePage(vm: MainVM) {
    val on = vm.mode == Mode.FASTBOOT && !vm.busy
    Panel("DETECTED DEVICE") {
        KV("Vendor", vm.vendor.ifBlank { "-" })
        KV("USB ID", vm.usbId.ifBlank { "-" })
        KV("Mode", vm.mode.label)
        KV("Product ID", vm.product.ifBlank { "-" })
        KV("Model", vm.modelName.ifBlank { "-" })
        KV("Chip", vm.chip.ifBlank { "-" })
        KV("Bootloader unlocked", vm.unlocked)
        KV("Fastbootd", if (vm.userspace) "yes" else "no")
        if (vm.modelNote.isNotBlank()) T(vm.modelNote, C.amber, 12, mod = Modifier.padding(top = 6.dp))
        Spacer(Modifier.height(8.dp))
        Btn("REFRESH INFO", on) { vm.refresh() }
    }
    Panel("SLOT CONTROL") {
        Rw {
            for (s in listOf("a", "b")) {
                if (vm.slot == s) {
                    Box(
                        Modifier.weight(1f).padding(vertical = 4.dp).heightIn(min = 56.dp)
                            .background(C.amber.copy(alpha = 0.12f), FieldShape)
                            .border(2.dp, C.amber, FieldShape).padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        T("SLOT ${s.uppercase()}  ACTIVE", C.amber, 12, true)
                    }
                } else {
                    ConfirmBtn(
                        "SLOT ${s.uppercase()}",
                        "Make slot ${s.uppercase()} active? If that slot holds no valid system the phone will not boot.",
                        enabled = on && vm.isAB, danger = false, mod = Modifier.weight(1f)
                    ) { vm.changeSlot(s) }
                }
            }
        }
        if (!vm.isAB && vm.mode == Mode.FASTBOOT) T("This phone has no A/B slots.", C.dim, 11)
    }
    Panel("REBOOT") {
        Rw {
            Btn("SYSTEM", on, mod = Modifier.weight(1f)) { vm.fbCmd("reboot") }
            Btn("BOOTLOADER", on, mod = Modifier.weight(1f)) { vm.fbCmd("reboot-bootloader") }
        }
        Rw {
            Btn("RECOVERY", on, mod = Modifier.weight(1f)) { vm.fbCmd("reboot-recovery") }
            Btn("FASTBOOTD", on, mod = Modifier.weight(1f)) { vm.fbCmd("reboot-fastboot") }
        }
    }
    Panel("MODEL GUARD") {
        Field(vm.expected, { vm.changeExpected(it) }, "Expected product ID (blocks flash if different)")
        T("Leave empty to disable. Current device reports: ${vm.product.ifBlank { "-" }}", C.dim, 11)
    }
    BubblePanel(vm)
}

@Composable
fun BubblePanel(vm: MainVM) {
    val ctx = LocalContext.current
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.refreshPerms() }
    Panel("FLOATING BUBBLE") {
        KV("Overlay permission", if (vm.overlayOk) "granted" else "not granted")
        KV("Notifications", if (vm.notifOk) "allowed" else "not allowed")
        KV("Bubble", if (vm.bubbleOn) "ON" else "OFF")
        T("While a flash, backup, sideload or download runs, a bubble floats over every app with the progress and cable warnings. Tap it to come back here, drag it to move it.", C.dim, 11, mod = Modifier.padding(top = 4.dp))
        Spacer(Modifier.height(8.dp))
        if (!vm.overlayOk) {
            Rw {
                Btn("GRANT OVERLAY PERMISSION", mod = Modifier.weight(1f)) {
                    ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
                }
            }
        }
        if (!vm.notifOk && Build.VERSION.SDK_INT >= 33) {
            Rw { Btn("ALLOW NOTIFICATIONS", mod = Modifier.weight(1f)) { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) } }
        }
        Rw {
            Btn(if (vm.bubbleOn) "BUBBLE: ON" else "BUBBLE: OFF", mod = Modifier.weight(1f)) { vm.toggleBubble() }
            Btn("TEST BUBBLE", !vm.busy, mod = Modifier.weight(1f)) { vm.testBubble() }
        }
    }
}

@Composable
fun FlashPage(vm: MainVM) {
    var part by remember { mutableStateOf("") }
    var pname by remember { mutableStateOf(vm.product) }
    var url by remember { mutableStateOf("") }
    val on = vm.mode == Mode.FASTBOOT && !vm.busy
    Panel("ADD IMAGE") {
        Field(part, { part = it }, "Partition (empty = taken from file name)")
        Rw {
            PickBtn("ADD IMAGE", Modifier.weight(1f)) { vm.addFile(it, part) }
            PickBtn("UNPACK ZIP", Modifier.weight(1f)) { vm.unzipToQueue(it) }
        }
    }
    Panel("FLASH QUEUE (${vm.queue.size})") {
        if (vm.queue.isEmpty()) T("Queue is empty. Add images in the order they must be flashed.", C.dim, 11)
        vm.queue.forEachIndexed { i, q ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T("${i + 1}. ${q.name}", C.text, 12)
                    T("to ${q.part}   ${q.size / 1024} KB", C.dim, 11)
                }
                IconBtn(R.drawable.b_up) { vm.move(i) }
                IconBtn(R.drawable.b_trash) { vm.verifiedFirmware.remove(q.uri.toString() + "|" + q.size); vm.queue.removeAt(i) }
            }
            var expectedHash by remember(q.uri.toString()) { mutableStateOf("") }
            Field(expectedHash, { expectedHash = it }, "Trusted SHA-256 for ${q.name}")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Btn("VERIFY SHA-256", !vm.busy && expectedHash.isNotBlank()) { vm.hash(q, expectedHash) }
                val verified = vm.verifiedFirmware[q.uri.toString() + "|" + q.size] != null
                T(if (verified) "VERIFIED" else "NOT VERIFIED", if (verified) C.green else C.amber, 10, true, Modifier.padding(start = 8.dp))
            }
        }
        ConfirmBtn(
            "FLASH ALL", "Flash ${vm.queue.size} image(s) in the listed order? A wrong image can leave the phone unbootable.",
            enabled = on && vm.queue.isNotEmpty()
        ) { vm.flashQueue() }
    }
    Panel("PHONE PROFILE") {
        Field(pname, { pname = it }, "Profile name")
        Btn("SAVE QUEUE AS PROFILE", pname.isNotBlank()) { vm.saveQueue(pname) }
        vm.profileNames().forEach { n -> TextButton(onClick = { vm.loadQueue(n) }) { T("load: $n", C.amber, 12) } }
    }
    val ctx = LocalContext.current
    val brandLinks = vm.brandLinks()
    var manualModelCode by remember { mutableStateOf("") }
    var manualRegion by remember { mutableStateOf("") }
    val detectedBrand = vm.brandName().ifBlank { "Unknown" }
    // Never include IMEI/serial values in search URLs. Use only public model identifiers.
    val modelTokens = buildList {
        if (vm.modelName.isNotBlank() && vm.modelName != "Not in database") add(vm.modelName)
        if (vm.product.isNotBlank()) add(vm.product)
        listOf("sku", "variant", "model", "device", "hardware-revision", "hw-revision").forEach { key ->
            vm.vars[key]?.takeIf { it.isNotBlank() && it != "unknown" }?.let(::add)
        }
    }.distinct()
    val officialSources = FirmwareSourceResolver.forBrand(detectedBrand, (modelTokens + manualModelCode).joinToString(" "), manualRegion)
    Panel("AUTO FIRMWARE SEARCH") {
        KV("Detected brand", detectedBrand)
        Field(manualModelCode, { manualModelCode = it }, "Exact model number (optional, e.g. SM-A145F / 23053RN02A)")
        Field(manualRegion, { manualRegion = it }, "Region / CSC (optional, e.g. INS / XSG / MIXM)")
        KV("Search identifiers", modelTokens.joinToString(" / ").ifBlank { "Model code unavailable" })
        if (modelTokens.isEmpty()) T("Exact model identifiers were not reported by this connection. Do not choose firmware using the brand name alone.", C.amber, 11)
        officialSources.forEach { source ->
            T("✓ ${source.title} · OFFICIAL", C.blue, 12, true, Modifier.fillMaxWidth().clickable {
                try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(source.url))) } catch (_: Exception) { }
            }.padding(vertical = 7.dp))
        }
        T("These links open manufacturer-owned portals or searches scoped to the manufacturer's domain; they are not guaranteed direct firmware files. Confirm exact model number, region/CSC, bootloader revision and package type before downloading. Independent mirrors are not presented as official.", C.dim, 11)
    }
    val edlLoaderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.setOptionalLoader("edl", uri)
    }
    val mtkLoaderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.setOptionalLoader("mtk", uri)
    }
    val edlLoader = vm.optionalLoader("edl")
    val mtkLoader = vm.optionalLoader("mtk")
    Panel("CHIPSET FLASH ENGINE STATUS") {
        ChipsetFlashEngines.engines.forEach { engine ->
            T(engine.title, C.text, 12, true)
            T("Transport: ${engine.transport}", C.dim, 10)
            T("Requirements: ${engine.requirements}", C.dim, 10)
            T("Status: Detection supported; write engine remains locked until the exact authorized loader/protocol is implemented and validated.", C.amber, 10)
            when (engine.mode) {
                Mode.QUALCOMM_EDL -> {
                    T("Optional loader: ${edlLoader?.lastPathSegment ?: "Not selected"}", C.dim, 10)
                    Rw {
                        Btn("SELECT OPTIONAL EDL PROGRAMMER", !vm.busy, mod = Modifier.weight(1f)) {
                            edlLoaderPicker.launch(arrayOf("*/*"))
                        }
                        if (edlLoader != null) Btn("CLEAR", !vm.busy) { vm.setOptionalLoader("edl", null) }
                    }
                    T("Optional only. Choose a signed programmer supplied for this exact model by its manufacturer or authorized service source. Selection does not run or flash it.", C.amber, 10)
                }
                Mode.MEDIATEK_BROM -> {
                    T("Optional Download Agent: ${mtkLoader?.lastPathSegment ?: "Not selected"}", C.dim, 10)
                    Rw {
                        Btn("SELECT OPTIONAL MTK DA", !vm.busy, mod = Modifier.weight(1f)) {
                            mtkLoaderPicker.launch(arrayOf("*/*"))
                        }
                        if (mtkLoader != null) Btn("CLEAR", !vm.busy) { vm.setOptionalLoader("mtk", null) }
                    }
                    T("Optional only. Use an OEM-authorized DA matched to the exact model and security state. SLA/DAA/Secure Boot requirements are not bypassed. Selection does not run or flash it.", C.amber, 10)
                }
                else -> Unit
            }
        }
        T("No generic programmer, authentication bypass, or cross-model loader is used. Optional files are stored as references only; the current build does not execute chipset loaders or claim those protocols are flash-ready.", C.dim, 10)
    }
    Panel("FIRMWARE SITES: ${vm.brandName().ifBlank { "-" }.uppercase()}") {
        if (brandLinks.isEmpty()) T("Connect a phone to see the firmware sites of its brand.", C.dim, 11)
        brandLinks.forEach { (n, u) ->
            T(n, C.blue, 12, true, Modifier.fillMaxWidth().clickable {
                try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (e: Exception) { }
            }.padding(vertical = 7.dp))
        }
        if (brandLinks.isNotEmpty()) T("Tap opens the site in your browser. After downloading, use ADD IMAGE or UNPACK ZIP above to pick the file.", C.dim, 11)
    }
    val links = vm.fwLinks()
    Panel("FIRMWARE FOR ${vm.modelName.ifBlank { "THIS PHONE" }.uppercase()}") {
        if (vm.product.isBlank()) T("Connect a phone in fastboot mode to see its firmware list.", C.dim, 11)
        else if (links.isEmpty()) T("No firmware link for '${vm.product}' in the database yet. Update the database in the Log tab or paste a URL below.", C.dim, 11)
        links.forEach { (n, u) ->
            Row(Modifier.fillMaxWidth().clickable(enabled = !vm.busy) { vm.download(u) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconBtn(R.drawable.b_download) { if (!vm.busy) vm.download(u) }
                Spacer(Modifier.padding(start = 8.dp))
                T(n, C.text, 12, mod = Modifier.weight(1f))
            }
        }
    }
    val files = remember(vm.busy, vm.queue.size) { vm.fwFiles() }
    Panel("DOWNLOADED FILES (${files.size})") {
        T(vm.fwDir().absolutePath, C.dim, 10)
        if (files.isEmpty()) T("Nothing downloaded yet.", C.dim, 11)
        files.forEach { f ->
            Row(Modifier.fillMaxWidth().clickable(enabled = !vm.busy) { vm.useFwFile(f) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T(f.name, C.text, 12)
                    T("${f.length() / 1024 / 1024} MB  - tap to add to queue", C.dim, 11)
                }
                IconBtn(R.drawable.b_trash) { f.delete(); vm.queue.removeAll { it.name == f.name } }
            }
        }
    }
    Panel("FIRMWARE DOWNLOAD") {
        Field(url, { url = it }, "Firmware URL (.img or .zip)")
        Btn("DOWNLOAD TO QUEUE", !vm.busy && url.isNotBlank()) { vm.download(url) }
    }
}

@Composable
fun PartPage(vm: MainVM) {
    var p by remember { mutableStateOf("") }
    var n by remember { mutableStateOf("") }
    var sz by remember { mutableStateOf("") }
    val on = vm.mode == Mode.FASTBOOT && !vm.busy
    Panel("PARTITION TABLE (${vm.parts.size})") {
        Btn("READ TABLE", on) { vm.refresh() }
        Spacer(Modifier.height(6.dp))
        vm.parts.forEach { l ->
            T(l, C.text, 12, mod = Modifier.fillMaxWidth().clickable { p = l.substringBefore(':').trim() }.padding(vertical = 5.dp))
        }
    }
    Panel("SELECTED PARTITION") {
        Field(p, { p = it }, "Partition name")
        Rw {
            ConfirmBtn("ERASE", "Erase partition '$p'? This cannot be undone.", on && p.isNotBlank(), true, Modifier.weight(1f)) { vm.fbCmd("erase:$p") }
            Btn("BACKUP", on && p.isNotBlank(), false, Modifier.weight(1f)) { vm.backup(p) }
        }
        T("Backup uses fastboot fetch, which needs bootloader support. Files go to the app's files/backups folder.", C.dim, 11)
    }
    Panel("LOGICAL PARTITIONS (FASTBOOTD)") {
        Field(n, { n = it }, "Name, for example product_a")
        Field(sz, { sz = it }, "Size in bytes")
        Rw {
            Btn("CREATE", on && vm.userspace && n.isNotBlank() && sz.isNotBlank(), false, Modifier.weight(1f)) { vm.fbCmd("create-logical-partition:$n:$sz") }
            Btn("RESIZE", on && vm.userspace && n.isNotBlank() && sz.isNotBlank(), false, Modifier.weight(1f)) { vm.fbCmd("resize-logical-partition:$n:$sz") }
        }
        ConfirmBtn("DELETE", "Delete logical partition '$n'?", on && vm.userspace && n.isNotBlank()) { vm.fbCmd("delete-logical-partition:$n") }
        if (!vm.userspace) T("Reboot to fastbootd (Device tab) to edit logical partitions.", C.dim, 11)
    }
}

@Composable
fun UnlockPage(vm: MainVM) {
    val on = vm.mode == Mode.FASTBOOT && !vm.busy
    Panel("BOOTLOADER STATE") {
        KV("Unlocked", vm.unlocked)
        KV("Model", vm.modelName.ifBlank { "-" })
        if (vm.modelNote.isNotBlank()) T(vm.modelNote, C.amber, 12)
        Spacer(Modifier.height(6.dp))
        Btn("REFRESH", on) { vm.refresh() }
    }
    Panel("UNLOCK OR LOCK") {
        T("Unlocking erases all data. OEM unlocking must be enabled in Developer options on the target phone. Confirm on the target phone's screen when asked. Some brands (Xiaomi, Huawei, carrier models) refuse this command.", C.red, 12)
        Spacer(Modifier.height(8.dp))
        ConfirmBtn("UNLOCK (flashing unlock)", "Unlock the bootloader and erase all data on the connected phone?", on) { vm.fbCmd("flashing unlock") }
        ConfirmBtn("UNLOCK (legacy oem unlock)", "Send the legacy 'oem unlock' command and erase all data?", on) { vm.fbCmd("oem unlock") }
        ConfirmBtn("LOCK (flashing lock)", "Lock the bootloader? Locking with modified images makes the phone unbootable.", on) { vm.fbCmd("flashing lock") }
    }
}

@Composable
fun RomPage(vm: MainVM) {
    var recPart by remember { mutableStateOf("recovery") }
    var rec by remember { mutableStateOf<Uri?>(null) }
    var rom by remember { mutableStateOf<Uri?>(null) }
    var extra by remember { mutableStateOf<Uri?>(null) }
    var bp by remember { mutableStateOf("boot") }
    val fb = vm.mode == Mode.FASTBOOT && !vm.busy
    val adb = vm.mode == Mode.ADB && !vm.busy
    Panel("STEP 1  VERIFY DEVICE") {
        KV("Product", vm.product.ifBlank { "-" })
        KV("Unlocked", vm.unlocked)
        KV("Active slot", vm.slot)
        if (vm.isAB) T("A/B phone: the custom recovery may live in boot or vendor_boot. Set the partition name in step 3.", C.amber, 11)
        if (vm.mode == Mode.SAMSUNG_DOWNLOAD) T("Samsung: this build only detects Download mode. Use a PC tool for the AP/BL/CP/CSC flash.", C.amber, 11)
        Spacer(Modifier.height(6.dp))
        Btn("REFRESH", fb) { vm.refresh() }
    }
    Panel("STEP 2  BACKUP") {
        Field(bp, { bp = it }, "Partition to back up")
        Btn("BACKUP", fb && bp.isNotBlank()) { vm.backup(bp) }
    }
    Panel("STEP 3  RECOVERY IMAGE") {
        Field(recPart, { recPart = it }, "Target partition")
        PickBtn("CHOOSE RECOVERY IMAGE") { rec = it }
        T(nm(rec), C.dim, 11)
        ConfirmBtn("FLASH RECOVERY", "Flash this image to '$recPart'?", fb && rec != null) { vm.flashOne(recPart, rec!!) }
    }
    Panel("STEP 4  WIPE DATA (OPTIONAL)") {
        ConfirmBtn("WIPE USERDATA", "Erase userdata and metadata on the connected phone?", fb) { vm.wipe() }
    }
    Panel("STEP 5  BOOT RECOVERY") {
        Btn("REBOOT TO RECOVERY", fb) { vm.fbCmd("reboot-recovery") }
        T("On the phone choose: Apply update, then Apply update from ADB. The app switches to this page when it sees the recovery.", C.dim, 11)
    }
    Panel("STEP 6  ROM ZIP (ADB SIDELOAD)") {
        PickBtn("CHOOSE ROM ZIP") { rom = it }
        T(nm(rom), C.dim, 11)
        Btn("SIDELOAD ROM", adb && rom != null) { vm.sideload(rom!!) }
    }
    Panel("STEP 7  EXTRA ZIP (GAPPS, ADD-ONS)") {
        PickBtn("CHOOSE EXTRA ZIP") { extra = it }
        T(nm(extra), C.dim, 11)
        Btn("SIDELOAD EXTRA", adb && extra != null) { vm.sideload(extra!!) }
        T("Start 'Apply update from ADB' again before each ZIP. Finish with Reboot system now on the phone.", C.dim, 11)
    }
}

@Composable
fun RootPage(vm: MainVM) {
    var boot by remember { mutableStateOf<Uri?>(null) }
    var bootPart by remember { mutableStateOf("boot") }
    var vb by remember { mutableStateOf<Uri?>(null) }
    var bp by remember { mutableStateOf("boot") }
    val fb = vm.mode == Mode.FASTBOOT && !vm.busy
    Panel("STEP 1  VERIFY DEVICE") {
        KV("Product", vm.product.ifBlank { "-" })
        KV("Unlocked", vm.unlocked)
        KV("Active slot", vm.slot)
        T("The bootloader must be unlocked. Patch the stock boot (or init_boot) image with Magisk first, on a phone that runs it.", C.amber, 11)
        Spacer(Modifier.height(6.dp))
        Btn("REFRESH", fb) { vm.refresh() }
    }
    Panel("STEP 2  BACKUP") {
        Field(bp, { bp = it }, "Partition to back up")
        Btn("BACKUP", fb && bp.isNotBlank()) { vm.backup(bp) }
    }
    Panel("STEP 3  PATCHED IMAGE") {
        Field(bootPart, { bootPart = it }, "Target partition (boot or init_boot)")
        PickBtn("CHOOSE PATCHED IMAGE") { boot = it }
        T(nm(boot), C.dim, 11)
        ConfirmBtn("FLASH PATCHED IMAGE", "Flash the patched image to '$bootPart'?", fb && boot != null) { vm.flashOne(bootPart, boot!!) }
    }
    Panel("STEP 4  VBMETA (OPTIONAL)") {
        PickBtn("CHOOSE VBMETA IMAGE") { vb = it }
        T(nm(vb), C.dim, 11)
        ConfirmBtn("FLASH VBMETA, VERITY OFF", "Flash vbmeta with verity and verification disabled?", fb && vb != null) { vm.flashVbmeta(vb!!) }
    }
    Panel("STEP 5  REBOOT AND CHECK") {
        Btn("REBOOT SYSTEM", fb) { vm.fbCmd("reboot") }
        T("Open the Magisk app on the phone to confirm root.", C.dim, 11)
    }
}

@Composable
fun ModesPage(vm: MainVM) {
    val guide = listOf(
        Mode.FASTBOOT to "Power off. Hold Volume Down + Power (Pixel, Motorola, OnePlus, Xiaomi) until the fastboot screen shows, then plug in the cable. From a running phone: adb reboot bootloader.",
        Mode.ADB to "Recovery: Apply update, then Apply update from ADB. Use the Custom ROM tab to sideload.",
        Mode.SAMSUNG_DOWNLOAD to "Power off. Hold Volume Up + Volume Down, plug in the cable, press Volume Up to accept the Download screen.",
        Mode.QUALCOMM_EDL to "From a running phone: adb reboot edl. Otherwise a vendor key combination or test point. Needs the model's firehose programmer file.",
        Mode.MEDIATEK_BROM to "Power off. Hold Volume Up (some models Volume Down) while plugging in the cable. Needs the model's download agent file.",
        Mode.UNISOC to "Power off. Hold the boot key (usually Volume Down) while plugging in the cable. Needs the FDL files."
    )
    Panel("CURRENT MODE") {
        KV("Mode", vm.mode.label)
        KV("Vendor", vm.vendor.ifBlank { "-" })
        KV("Chip", vm.chip.ifBlank { "-" })
        when (vm.mode) {
            Mode.SAMSUNG_DOWNLOAD, Mode.QUALCOMM_EDL, Mode.MEDIATEK_BROM, Mode.UNISOC ->
                T("Device recognised. The read/write protocol for this mode is not part of this build yet; the chip and mode shown here are what the protocol module will use.", C.amber, 12, mod = Modifier.padding(top = 6.dp))
            Mode.UNKNOWN -> T("Unknown USB device. Put the phone into a known mode using the guide below.", C.red, 12, mod = Modifier.padding(top = 6.dp))
            else -> { }
        }
    }
    Panel("HOW TO ENTER EACH MODE") {
        guide.forEach { (m, text) ->
            Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                T(m.label, if (vm.mode == m) C.green else C.amber, 12, true)
                T(text, C.dim, 11)
            }
        }
    }
}

@Composable
fun LogPage(vm: MainVM) {
    Panel("DEVICE DATABASE (${vm.dbInfo})") {
        Field(vm.dbUrl, { vm.dbUrl = it }, "Raw GitHub URL of devices.json")
        Btn("UPDATE DATABASE", !vm.busy) { vm.updateDb(vm.dbUrl) }
    }
    Panel("USB LOG (${vm.logs.size})") {
        Rw {
            Btn("EXPORT", mod = Modifier.weight(1f)) { vm.exportLog() }
            Btn("CLEAR", mod = Modifier.weight(1f)) { vm.logs.clear() }
        }
        Spacer(Modifier.height(6.dp))
        vm.logs.toList().asReversed().forEach { T(it, C.text, 11, mod = Modifier.padding(vertical = 2.dp)) }
    }
}

@Composable
fun SafetyPage(vm: MainVM) {
    val battery = vm.safetyBatteryPercent()
    val storage = vm.fwDir().usableSpace
    val identityOk = vm.mode == Mode.FASTBOOT && vm.product.isNotBlank() && vm.expected.isNotBlank() && vm.expected.equals(vm.product, true)
    val queueOk = vm.queue.isNotEmpty() && vm.queue.all { vm.verifiedFirmware[it.uri.toString() + "|" + it.size] != null }
    val blocked = !identityOk || vm.queue.isEmpty() || !queueOk || battery == null || battery < 40
    val color = if (blocked) C.red else C.amber
    Panel("PRE-FLASH SAFETY ANALYZER") {
        T(if (blocked) "BLOCKED" else "WARNING", color, 18, true)
        T(if (blocked) "Flashing is blocked until every critical requirement is satisfied." else "Checks shown here are not a guarantee against unknown hardware or firmware risks.", C.dim, 11)
    }
    Panel("DEVICE IDENTITY") {
        KV("Connection", if (vm.link == Link.GREEN) "Stable" else vm.linkNote)
        KV("Mode", vm.mode.label)
        KV("Detected product ID", vm.product.ifBlank { "Unavailable" })
        KV("Expected product ID", vm.expected.ifBlank { "Not confirmed" })
        KV("Model / codename", vm.modelName.ifBlank { "Unavailable" })
        KV("Active slot", vm.slot)
        KV("A/B partitions", if (vm.isAB) "Yes" else "No / unknown")
        KV("Fastbootd", if (vm.userspace) "Yes" else "No / unknown")
        Btn("USE DETECTED PRODUCT ID (CONFIRM)", vm.mode == Mode.FASTBOOT && vm.product.isNotBlank() && !vm.busy) { vm.adoptDetectedProduct() }
    }
    Panel("FIRMWARE AND PARTITION") {
        KV("Flash queue", "${vm.queue.size} image(s)")
        KV("Publisher SHA-256", if (queueOk) "Verified for queued items" else "Missing / not verified")
        vm.queue.forEach { q ->
            T("${q.name} → ${q.part} (${q.size} bytes)", C.text, 11)
            T(if (vm.verifiedFirmware[q.uri.toString() + "|" + q.size] != null) "Checksum matched; partition is rechecked immediately before transfer" else "BLOCKED: publisher checksum verification required", if (vm.verifiedFirmware[q.uri.toString() + "|" + q.size] != null) C.green else C.red, 10)
        }
        T("Partition size, slot and logical/physical compatibility must be confirmed by the connected bootloader. Unknown values are blocked.", C.amber, 11)
    }
    Panel("CONTROLLER PHONE HEALTH") {
        KV("Phone battery", battery?.let { "$it%" } ?: "Unavailable")
        KV("Minimum threshold", "40% (initial policy)")
        KV("Firmware storage free", "${storage / (1024 * 1024)} MB")
        T("This battery value belongs to the FlashForge controller phone, not the connected target phone. Target battery is not assumed.", C.dim, 10)
        if (battery != null && battery < 40) T("WARNING: controller battery is below 40%. Charge before flashing.", C.red, 11, true)
    }
    Panel("USB AND RECOVERY") {
        KV("USB state", vm.link.label)
        T("If USB disconnects or a transfer fails: do not retry automatically. Keep the device connected to power, note its current screen/mode, inspect the operation log, and follow the device manufacturer's recovery procedure. An interrupted partition write is not resumable unless that device/protocol explicitly supports safe resume.", C.dim, 11)
    }
    Panel("SAFETY DECISION") {
        T(if (blocked) "BLOCKED — DO NOT FLASH" else "WARNING — REVIEW ALL WARNINGS", if (blocked) C.red else C.amber, 14, true)
        T("A green PASS is deliberately not inferred from missing information. The current analyzer blocks when the exact product ID or trusted publisher checksum is absent.", C.dim, 11)
        Btn("OPEN FLASH QUEUE", true) { vm.screen = Screen.FLASH }
    }
}
