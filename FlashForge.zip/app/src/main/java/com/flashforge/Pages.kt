package com.flashforge

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

private fun nm(u: Uri?): String = u?.lastPathSegment?.substringAfterLast('/') ?: "no file chosen"

@Composable
fun DevicePage(vm: MainVM) {
    Panel("DETECTED DEVICE") {
        KV("Vendor", vm.vendor.ifBlank { "-" })
        KV("USB ID", vm.usbId.ifBlank { "-" })
        KV("Mode", vm.mode.label)
        KV("Product ID", vm.product.ifBlank { "-" })
        KV("Model", vm.modelName.ifBlank { "-" })
        KV("Chip", vm.chip.ifBlank { "-" })
        KV("Bootloader unlocked", vm.unlocked)
        KV("Fastbootd", if (vm.userspace) "yes" else "no")
        if (vm.modelNote.isNotBlank()) T(vm.modelNote, C.amber, 12, mod = Modifier.padding(top = 6.dp))
    }
    Panel("MODEL GUARD") {
        Field(vm.expected, { vm.changeExpected(it) }, "Expected product ID (blocks flash if different)")
        T("Leave empty to disable. Current device reports: ${vm.product.ifBlank { "-" }}", C.dim, 11)
    }
}

@Composable
fun BubblePanel(vm: MainVM) {
    val ctx = LocalContext.current
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.refreshPerms() }
    Panel("FLOATING BUBBLE", false) {
        KV("Overlay permission", if (vm.overlayOk) "granted" else "not granted")
        KV("Notifications", if (vm.notifOk) "allowed" else "not allowed")
        KV("Bubble", if (vm.bubbleOn) "ON" else "OFF")
        T("While a flash, backup, sideload or download runs, a bubble floats over every app with the progress and cable warnings. Tap it to come back here, drag it to move it.", C.dim, 11, mod = Modifier.padding(top = 4.dp))
        Spacer(Modifier.height(8.dp))
        if (!vm.overlayOk) {
            Rw {
                Btn("GRANT OVERLAY PERMISSION", mod = Modifier.weight(1f)) {
                    ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
                }
            }
        }
        if (!vm.notifOk && Build.VERSION.SDK_INT >= 33) {
            Rw { Btn("ALLOW NOTIFICATIONS", mod = Modifier.weight(1f)) { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) } }
        }
        Rw {
            Btn(if (vm.bubbleOn) "BUBBLE: ON" else "BUBBLE: OFF", mod = Modifier.weight(1f)) { vm.toggleBubble() }
            Btn("TEST BUBBLE", !vm.busy, mod = Modifier.weight(1f)) { vm.testBubble() }
        }
    }
}

@Composable
fun FlashPage(vm: MainVM) {
    var part by remember { mutableStateOf("") }
    var pname by remember { mutableStateOf(vm.product) }
    var url by remember { mutableStateOf("") }
    val on = vm.mode == Mode.FASTBOOT && !vm.busy
    Panel("ADD IMAGE") {
        Field(part, { part = it }, "Explicit target partition (required; never inferred from filename)")
        Rw {
            PickBtn("ADD IMAGE", Modifier.weight(1f)) { vm.addFile(it, part) }
            PickBtn("UNPACK ZIP", Modifier.weight(1f)) { vm.unzipToQueue(it) }
        }
    }
    Panel("FLASH QUEUE (${vm.queue.size})") {
        if (vm.queue.isEmpty()) T("Queue is empty. Add images in the order they must be flashed.", C.dim, 11)
        vm.queue.forEachIndexed { i, q ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T("${i + 1}. ${q.name}", C.text, 12)
                    T("${q.size / 1024} KB", C.dim, 11)
                }
                IconBtn(R.drawable.b_up) { vm.move(i) }
                IconBtn(R.drawable.b_trash) { vm.verifiedFirmware.remove(q.uri.toString() + "|" + q.size); vm.queue.removeAt(i) }
            }
            var queuePartition by remember(q.uri.toString()) { mutableStateOf(q.part) }
            Field(queuePartition, { queuePartition = it; vm.setQueuePartition(i, it) }, "Explicit target partition for ${q.name} (required)")
            var expectedHash by remember(q.uri.toString()) { mutableStateOf("") }
            Field(expectedHash, { expectedHash = it }, "Trusted SHA-256 for ${q.name}")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Btn("VERIFY SHA-256", !vm.busy && expectedHash.isNotBlank()) { vm.hash(q, expectedHash) }
                val verified = vm.verifiedFirmware[q.uri.toString() + "|" + q.size] != null
                T(if (verified) "VERIFIED" else "NOT VERIFIED", if (verified) C.green else C.amber, 10, true, Modifier.padding(start = 8.dp))
            }
        }
        val queueReady = vm.queue.isNotEmpty() && vm.queue.all { item ->
            item.part.matches(Regex("[A-Za-z0-9_]{1,48}")) && vm.verifiedFirmware[item.uri.toString() + "|" + item.size] != null
        }
        ConfirmBtn(
            "FLASH ALL", "Flash ${vm.queue.size} image(s) in the listed order? Every image must have an explicit partition and a matching publisher SHA-256.",
            enabled = on && queueReady && vm.safetyWarningsAcknowledged
        ) { vm.flashQueue() }
    }
    Panel("PHONE PROFILE", false) {
        Field(pname, { pname = it }, "Profile name")
        Btn("SAVE QUEUE AS PROFILE", pname.isNotBlank()) { vm.saveQueue(pname) }
        vm.profileNames().forEach { n -> TextButton(onClick = { vm.loadQueue(n) }) { T("load: $n", C.amber, 12) } }
    }
    val ctx = LocalContext.current
    val brandLinks = vm.brandLinks()
    var manualModelCode by remember { mutableStateOf("") }
    var manualRegion by remember { mutableStateOf("") }
    val detectedBrand = vm.brandName().ifBlank { "Unknown" }
    // Never include IMEI/serial values in search URLs. Use only public model identifiers.
    val modelTokens = buildList {
        if (vm.modelName.isNotBlank() && vm.modelName != "Not in database") add(vm.modelName)
        if (vm.product.isNotBlank()) add(vm.product)
        listOf("sku", "variant", "model", "device", "hardware-revision", "hw-revision").forEach { key ->
            vm.vars[key]?.takeIf { it.isNotBlank() && it != "unknown" }?.let(::add)
        }
    }.distinct()
    val officialSources = FirmwareSourceResolver.forBrand(detectedBrand, (modelTokens + manualModelCode).joinToString(" "), manualRegion)
    Panel("AUTO FIRMWARE SEARCH", false) {
        KV("Detected brand", detectedBrand)
        Field(manualModelCode, { manualModelCode = it }, "Exact model number (optional, e.g. SM-A145F / 23053RN02A)")
        Field(manualRegion, { manualRegion = it }, "Region / CSC (optional, e.g. INS / XSG / MIXM)")
        KV("Search identifiers", modelTokens.joinToString(" / ").ifBlank { "Model code unavailable" })
        if (modelTokens.isEmpty()) T("Exact model identifiers were not reported by this connection. Do not choose firmware using the brand name alone.", C.amber, 11)
        officialSources.forEach { source ->
            T("✓ ${source.title} · OFFICIAL", C.blue, 12, true, Modifier.fillMaxWidth().clickable {
                try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(source.url))) } catch (e: Exception) { android.util.Log.e("FlashForge", "Could not open firmware source ${source.url}", e) }
            }.padding(vertical = 7.dp))
        }
        T("These links open manufacturer-owned portals or searches scoped to the manufacturer's domain; they are not guaranteed direct firmware files. Confirm exact model number, region/CSC, bootloader revision and package type before downloading. Independent mirrors are not presented as official.", C.dim, 11)
    }
    val edlLoaderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.setOptionalLoader("edl", uri)
    }
    val mtkLoaderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.setOptionalLoader("mtk", uri)
    }
    val edlLoader = vm.optionalLoader("edl")
    val mtkLoader = vm.optionalLoader("mtk")
    Panel("CHIPSET FLASH ENGINE STATUS", false) {
        ChipsetFlashEngines.engines.forEach { engine ->
            T(engine.title, C.text, 12, true)
            T("Transport: ${engine.transport}", C.dim, 10)
            T("Requirements: ${engine.requirements}", C.dim, 10)
            T("Status: Detection supported; write engine remains locked until the exact authorized loader/protocol is implemented and validated.", C.amber, 10)
            when (engine.mode) {
                Mode.QUALCOMM_EDL -> {
                    T("Optional loader: ${edlLoader?.lastPathSegment ?: "Not selected"}", C.dim, 10)
                    Rw {
                        Btn("SELECT OPTIONAL EDL PROGRAMMER", !vm.busy, mod = Modifier.weight(1f)) {
                            edlLoaderPicker.launch(arrayOf("*/*"))
                        }
                        if (edlLoader != null) Btn("CLEAR", !vm.busy) { vm.setOptionalLoader("edl", null) }
                    }
                    T("Optional only. Choose a signed programmer supplied for this exact model by its manufacturer or authorized service source. Selection does not run or flash it.", C.amber, 10)
                }
                Mode.MEDIATEK_BROM -> {
                    T("Optional Download Agent: ${mtkLoader?.lastPathSegment ?: "Not selected"}", C.dim, 10)
                    Rw {
                        Btn("SELECT OPTIONAL MTK DA", !vm.busy, mod = Modifier.weight(1f)) {
                            mtkLoaderPicker.launch(arrayOf("*/*"))
                        }
                        if (mtkLoader != null) Btn("CLEAR", !vm.busy) { vm.setOptionalLoader("mtk", null) }
                    }
                    T("Optional only. Use an OEM-authorized DA matched to the exact model and security state. SLA/DAA/Secure Boot requirements are not bypassed. Selection does not run or flash it.", C.amber, 10)
                }
                else -> Unit
            }
        }
        T("No generic programmer, authentication bypass, or cross-model loader is used. Optional files are stored as references only; the current build does not execute chipset loaders or claim those protocols are flash-ready.", C.dim, 10)
    }
    Panel("FIRMWARE SITES: ${vm.brandName().ifBlank { "-" }.uppercase()}", false) {
        if (brandLinks.isEmpty()) T("Connect a phone to see the firmware sites of its brand.", C.dim, 11)
        brandLinks.forEach { (n, u) ->
            T(n, C.blue, 12, true, Modifier.fillMaxWidth().clickable {
                try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (e: Exception) { android.util.Log.e("FlashForge", "Could not open firmware link $u", e) }
            }.padding(vertical = 7.dp))
        }
        if (brandLinks.isNotEmpty()) T("Tap opens the site in your browser. After downloading, use ADD IMAGE or UNPACK ZIP above to pick the file.", C.dim, 11)
    }
    val links = vm.fwLinks()
    Panel("FIRMWARE FOR ${vm.modelName.ifBlank { "THIS PHONE" }.uppercase()}", false) {
        if (vm.product.isBlank()) T("Connect a phone in fastboot mode to see its firmware list.", C.dim, 11)
        else if (links.isEmpty()) T("No firmware link for '${vm.product}' in the database yet. Update the database in the Log tab or paste a URL below.", C.dim, 11)
        links.forEach { (n, u) ->
            Row(Modifier.fillMaxWidth().clickable(enabled = !vm.busy) { vm.download(u) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconBtn(R.drawable.b_download) { if (!vm.busy) vm.download(u) }
                Spacer(Modifier.padding(start = 8.dp))
                T(n, C.text, 12, mod = Modifier.weight(1f))
            }
        }
    }
    var filesTick by remember { mutableStateOf(0) }
    val files = remember(vm.busy, vm.queue.size, filesTick) { vm.fwFiles() }
    Panel("DOWNLOADED FILES (${files.size})", false) {
        T(vm.fwDir().absolutePath, C.dim, 10)
        if (files.isEmpty()) T("Nothing downloaded yet.", C.dim, 11)
        files.forEach { f ->
            Row(Modifier.fillMaxWidth().clickable(enabled = !vm.busy) { vm.useFwFile(f) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T(f.name, C.text, 12)
                    T("${f.length() / 1024 / 1024} MB  - tap to add to queue", C.dim, 11)
                }
                IconBtn(R.drawable.b_trash) { f.delete(); vm.queue.removeAll { it.name == f.name }; filesTick++ }
            }
        }
    }
    Panel("FIRMWARE DOWNLOAD", false) {
        Field(url, { url = it }, "Firmware URL (.img or .zip)")
        Btn("DOWNLOAD TO QUEUE", !vm.busy && url.isNotBlank()) { vm.download(url) }
    }
}

@Composable
fun PartPage(vm: MainVM) {
    var p by remember { mutableStateOf("") }
    var n by remember { mutableStateOf("") }
    var sz by remember { mutableStateOf("") }
    val on = vm.mode == Mode.FASTBOOT && !vm.busy
    Panel("PARTITION TABLE (${vm.parts.size})") {
        if (vm.parts.isEmpty()) T("Tap REFRESH at the top to read the table.", C.dim, 11)
        vm.parts.forEach { l ->
            T(l, C.text, 12, mod = Modifier.fillMaxWidth().clickable { p = l.substringBefore(':').trim() }.padding(vertical = 5.dp))
        }
    }
    Panel("SELECTED PARTITION") {
        Field(p, { p = it }, "Partition name")
        Rw {
            ConfirmBtn("ERASE", "Erase partition '$p'? This cannot be undone.", on && p.isNotBlank(), true, Modifier.weight(1f)) { vm.confirmedFbCmd("erase:$p") }
            Btn("BACKUP", on && p.isNotBlank(), false, Modifier.weight(1f)) { vm.backup(p) }
        }
        T("Backup uses fastboot fetch, which needs bootloader support. Files go to the app's files/backups folder.", C.dim, 11)
    }
    Panel("LOGICAL PARTITIONS (FASTBOOTD)", false) {
        Field(n, { n = it }, "Name, for example product_a")
        Field(sz, { sz = it }, "Size in bytes")
        Rw {
            Btn("CREATE", false, false, Modifier.weight(1f)) { }
            Btn("RESIZE", false, false, Modifier.weight(1f)) { }
        }
        ConfirmBtn("DELETE", "Logical partition modification is disabled in this build because metadata geometry and group limits cannot be verified.", false) { }
        T("Logical partition CREATE / RESIZE / DELETE are intentionally blocked until device-specific super metadata and group constraints can be verified. Existing controls are retained but disabled.", C.amber, 11)
        if (!vm.userspace) T("Fastbootd mode is required for logical partition diagnostics.", C.dim, 11)
    }
}

@Composable
fun UnlockPage(vm: MainVM) {
    val on = vm.mode == Mode.FASTBOOT && !vm.busy
    Panel("UNLOCK OR LOCK") {
        T("Unlocking erases all data. OEM unlocking must be enabled in Developer options on the target phone. Confirm on the target phone's screen when asked. Some brands (Xiaomi, Huawei, carrier models) refuse this command.", C.red, 12)
        Spacer(Modifier.height(8.dp))
        ConfirmBtn("UNLOCK (flashing unlock)", "Unlock the bootloader and erase all data on the connected phone?", on) { vm.confirmedFbCmd("flashing unlock") }
        ConfirmBtn("UNLOCK (legacy oem unlock)", "Send the legacy 'oem unlock' command and erase all data?", on) { vm.confirmedFbCmd("oem unlock") }
        ConfirmBtn("LOCK (flashing lock) — DISABLED", "Bootloader locking is disabled because this app cannot prove that every flashed partition is stock-compatible for this exact device.", false) { vm.confirmedFbCmd("flashing lock") }
        T("Bootloader relocking is intentionally unavailable. Do not lock after modified or unverified firmware.", C.amber, 11)
    }
}

@Composable
private fun SlotButtons(vm: MainVM, enabled: Boolean) {
    Rw {
        for (s in listOf("a", "b")) {
            if (vm.slot == s) {
                Box(
                    Modifier.weight(1f).padding(vertical = 4.dp).heightIn(min = 56.dp)
                        .background(C.amber.copy(alpha = 0.12f), FieldShape)
                        .border(2.dp, C.amber, FieldShape).padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    T("SLOT ${s.uppercase()}  ACTIVE", C.amber, 12, true)
                }
            } else {
                ConfirmBtn(
                    "SLOT ${s.uppercase()}",
                    "Make slot ${s.uppercase()} active? If that slot holds no valid system the phone will not boot.",
                    enabled = enabled && vm.isAB, danger = false, mod = Modifier.weight(1f)
                ) { vm.changeSlot(s) }
            }
        }
    }
    if (!vm.isAB && vm.mode == Mode.FASTBOOT) T("This phone has no A/B slots.", C.dim, 11)
}

@Composable
private fun Sub(title: String) {
    Spacer(Modifier.height(10.dp))
    T(title, C.blue, 12, true)
    Spacer(Modifier.height(4.dp))
}

@Composable
fun RomPage(vm: MainVM) {
    var recPart by remember { mutableStateOf(AppSettings.defRecovery) }
    var rec by remember { mutableStateOf<Uri?>(null) }
    var recHash by remember { mutableStateOf("") }
    var rom by remember { mutableStateOf<Uri?>(null) }
    var romHash by remember { mutableStateOf("") }
    var extra by remember { mutableStateOf<Uri?>(null) }
    var extraHash by remember { mutableStateOf("") }
    var bp by remember { mutableStateOf(AppSettings.defBackup) }
    val fb = vm.mode == Mode.FASTBOOT && !vm.busy
    val adb = vm.mode == Mode.ADB && !vm.busy
    val hex64 = Regex("[0-9a-fA-F]{64}")

    Panel("REQUIREMENTS", false) {
        KV("Model guard set", if (vm.expected.isNotBlank()) "yes" else "no")
        KV("Safety warnings acknowledged", if (vm.safetyWarningsAcknowledged) "yes" else "no")
        T("Needed: unlocked bootloader, USB cable, charged phones, ROM and recovery files with publisher SHA-256 checksums.", C.dim, 11, mod = Modifier.padding(top = 4.dp))
        T("Order: Backup > Recovery > Wipe > Reboot to recovery > ROM ZIP > Extra ZIP.", C.dim, 11)
    }

    Panel("1  SLOT (A/B phones)", true) {
        SlotButtons(vm, fb)
        if (vm.isAB) T("The custom recovery may live in boot or vendor_boot. Set the partition name in step 3.", C.amber, 11)
    }
    Panel("2  BACKUP", true) {
        Field(bp, { bp = it }, "Partition to back up")
        Btn("BACKUP", fb && bp.isNotBlank()) { vm.backup(bp) }
    }
    Panel("3  RECOVERY IMAGE", true) {
        Field(recPart, { recPart = it }, "Target partition")
        PickBtn("CHOOSE RECOVERY IMAGE") { rec = it; recHash = "" }
        T(nm(rec), C.dim, 11)
        Field(recHash, { recHash = it }, "Publisher SHA-256 checksum (64 hex characters)")
        Rw {
            Btn("VERIFY RECOVERY IMAGE", !vm.busy && rec != null && recHash.isNotBlank(), mod = Modifier.weight(1f)) { vm.verifyStandaloneImage(rec!!, recHash) }
            ConfirmBtn("FLASH RECOVERY", "Flash this verified image to '$recPart'?", fb && rec != null && vm.isImageVerified(rec) && vm.safetyWarningsAcknowledged, mod = Modifier.weight(1f)) { vm.flashOne(recPart, rec!!) }
        }
        T(if (vm.isImageVerified(rec)) "PUBLISHER CHECKSUM VERIFIED" else "IMAGE NOT VERIFIED", if (vm.isImageVerified(rec)) C.green else C.amber, 10, true)
    }
    Panel("4  WIPE DATA (OPTIONAL)", false) {
        ConfirmBtn("WIPE USERDATA", "Erase userdata and metadata on the connected phone?", fb) { vm.wipe() }
    }
    Panel("5  BOOT RECOVERY", true) {
        Btn("REBOOT TO RECOVERY", fb) { vm.fbCmd("reboot-recovery") }
        T("On the phone choose: Apply update, then Apply update from ADB. The app switches to ADB mode when it sees the recovery.", C.dim, 11)
    }
    Panel("6  ROM ZIP (ADB SIDELOAD, EXPERIMENTAL)", true) {
        T("Recovery banner and publisher SHA-256 are required. Not hardware-tested; verify package compatibility using OEM instructions.", C.amber, 11)
        PickBtn("CHOOSE ROM ZIP") { rom = it; romHash = "" }
        T(nm(rom), C.dim, 11)
        Field(romHash, { romHash = it }, "Publisher SHA-256 checksum (64 hex characters)")
        Btn("SIDELOAD ROM", adb && rom != null && romHash.matches(hex64)) { vm.sideload(rom!!, romHash) }
    }
    Panel("7  EXTRA ZIP (GAPPS, ADD-ONS, EXPERIMENTAL)", false) {
        T("Each package is independently checksum-verified. Start 'Apply update from ADB' again before each ZIP. Finish with Reboot system now on the phone.", C.amber, 11)
        PickBtn("CHOOSE EXTRA ZIP") { extra = it; extraHash = "" }
        T(nm(extra), C.dim, 11)
        Field(extraHash, { extraHash = it }, "Publisher SHA-256 checksum (64 hex characters)")
        Btn("SIDELOAD EXTRA", adb && extra != null && extraHash.matches(hex64)) { vm.sideload(extra!!, extraHash) }
    }
}

@Composable
fun RootPage(vm: MainVM) {
    var boot by remember { mutableStateOf<Uri?>(null) }
    var bootHash by remember { mutableStateOf("") }
    var bootPart by remember { mutableStateOf(AppSettings.defPatched) }
    var vb by remember { mutableStateOf<Uri?>(null) }
    var bp by remember { mutableStateOf(AppSettings.defBackup) }
    val fb = vm.mode == Mode.FASTBOOT && !vm.busy
    Panel("STEP 1  BEFORE YOU START") {
        T("The bootloader must be unlocked (see the status line at the top). Patch the stock boot (or init_boot) image with Magisk first, on a phone that runs it.", C.amber, 11)
    }
    Panel("STEP 2  BACKUP", true) {
        Field(bp, { bp = it }, "Partition to back up")
        Btn("BACKUP", fb && bp.isNotBlank()) { vm.backup(bp) }
    }
    Panel("STEP 3  PATCHED IMAGE", true) {
        Field(bootPart, { bootPart = it }, "Target partition (boot or init_boot)")
        PickBtn("CHOOSE PATCHED IMAGE") { boot = it; bootHash = "" }
        T(nm(boot), C.dim, 11)
        Field(bootHash, { bootHash = it }, "Publisher SHA-256 checksum (64 hex characters)")
        Btn("VERIFY PATCHED IMAGE", !vm.busy && boot != null && bootHash.isNotBlank()) { vm.verifyStandaloneImage(boot!!, bootHash) }
        T(if (vm.isImageVerified(boot)) "PUBLISHER CHECKSUM VERIFIED" else "IMAGE NOT VERIFIED", if (vm.isImageVerified(boot)) C.green else C.amber, 10, true)
        ConfirmBtn("FLASH PATCHED IMAGE", "Flash this verified image to '$bootPart'?", fb && boot != null && vm.isImageVerified(boot) && vm.safetyWarningsAcknowledged) { vm.flashOne(bootPart, boot!!) }
    }
    Panel("STEP 4  VBMETA (OPTIONAL)", false) {
        PickBtn("CHOOSE VBMETA IMAGE") { vb = it }
        T(nm(vb), C.dim, 11)
        ConfirmBtn("VBMETA FLASH — DISABLED", "Automatic vbmeta modification is blocked because it can weaken Android Verified Boot. Use only a separately reviewed device-specific procedure.", false) { }
        T("The selected vbmeta file is not flashed by this application. Verified Boot protections are not silently disabled.", C.amber, 11)
    }
    Panel("STEP 5  REBOOT AND CHECK", true) {
        Btn("REBOOT SYSTEM", fb) { vm.fbCmd("reboot") }
        T("Open the Magisk app on the phone to confirm root.", C.dim, 11)
    }
}

@Composable
fun ModesPage(vm: MainVM) {
    val guide = listOf(
        Mode.FASTBOOT to "Power off. Hold Volume Down + Power (Pixel, Motorola, OnePlus, Xiaomi) until the fastboot screen shows, then plug in the cable. From a running phone: adb reboot bootloader.",
        Mode.ADB to "Recovery: Apply update, then Apply update from ADB. Use the Custom ROM tab to sideload.",
        Mode.SAMSUNG_DOWNLOAD to "Power off. Hold Volume Up + Volume Down, plug in the cable, press Volume Up to accept the Download screen.",
        Mode.QUALCOMM_EDL to "From a running phone: adb reboot edl. Otherwise a vendor key combination or test point. Needs the model's firehose programmer file.",
        Mode.MEDIATEK_BROM to "Power off. Hold Volume Up (some models Volume Down) while plugging in the cable. Needs the model's download agent file.",
        Mode.UNISOC to "Power off. Hold the boot key (usually Volume Down) while plugging in the cable. Needs the FDL files."
    )
    Panel("CURRENT MODE") {
        KV("Mode", vm.mode.label)
        KV("Vendor", vm.vendor.ifBlank { "-" })
        KV("Chip", vm.chip.ifBlank { "-" })
        when (vm.mode) {
            Mode.SAMSUNG_DOWNLOAD, Mode.QUALCOMM_EDL, Mode.MEDIATEK_BROM, Mode.UNISOC ->
                T("Device recognised. The read/write protocol for this mode is not part of this build yet; the chip and mode shown here are what the protocol module will use.", C.amber, 12, mod = Modifier.padding(top = 6.dp))
            Mode.UNKNOWN -> T("Unknown USB device. Put the phone into a known mode using the guide below.", C.red, 12, mod = Modifier.padding(top = 6.dp))
            else -> { }
        }
    }
    Panel("HOW TO ENTER EACH MODE", false) {
        guide.forEach { (m, text) ->
            Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                T(m.label, if (vm.mode == m) C.green else C.amber, 12, true)
                T(text, C.dim, 11)
            }
        }
    }
}

@Composable
fun LogPage(vm: MainVM) {
    Panel("DEVICE DATABASE (${vm.dbInfo})", false) {
        Field(vm.dbUrl, { vm.dbUrl = it }, "Raw GitHub URL of devices.json")
        Btn("UPDATE DATABASE", !vm.busy) { vm.updateDb(vm.dbUrl) }
    }
    Panel("USB LOG (${vm.logs.size})") {
        Rw {
            Btn("EXPORT", mod = Modifier.weight(1f)) { vm.exportLog() }
            Btn("CLEAR", mod = Modifier.weight(1f)) { vm.logs.clear() }
        }
        Spacer(Modifier.height(6.dp))
        vm.logs.toList().asReversed().forEach { T(it, C.text, 11, mod = Modifier.padding(vertical = 2.dp)) }
    }
}

@Composable
fun SafetyPage(vm: MainVM) {
    val battery = vm.safetyBatteryPercent()
    val storage = vm.fwDir().usableSpace
    val identityOk = vm.mode == Mode.FASTBOOT && vm.link == Link.GREEN && vm.product.isNotBlank() && vm.expected.isNotBlank() && vm.expected.equals(vm.product, true)
    val queueOk = vm.queue.isNotEmpty() && vm.queue.all { item ->
        item.part.matches(Regex("[A-Za-z0-9_]{1,48}")) && vm.verifiedFirmware[item.uri.toString() + "|" + item.size] != null
    }
    val effectiveStatus = if (!identityOk || battery == null || battery < AppSettings.minBattery) "BLOCKED" else vm.analyzerStatus
    val statusColor = when (effectiveStatus) {
        "PASS" -> C.green
        "BLOCKED" -> C.red
        else -> C.amber
    }
    Panel("PRE-FLASH SAFETY ANALYZER") {
        T(effectiveStatus, statusColor, 18, true)
        T(vm.analyzerMessage, C.dim, 11)
        T("This analyzer is also invoked automatically inside every image-flash transport path. Opening this page is not a substitute for the mandatory gate.", C.amber, 11)
    }
    Panel("DEVICE IDENTITY", false) {
        KV("Connection", if (vm.link == Link.GREEN) "Stable" else vm.linkNote)
        KV("Mode", vm.mode.label)
        KV("Detected product ID", vm.product.ifBlank { "Unavailable" })
        KV("Expected product ID", vm.expected.ifBlank { "Not confirmed" })
        KV("Model / codename", vm.modelName.ifBlank { "Unavailable" })
        KV("Active slot", vm.slot)
        KV("A/B partitions", if (vm.isAB) "Yes" else if (vm.mode == Mode.FASTBOOT) "No / unknown" else "Unavailable")
        KV("Fastbootd", if (vm.userspace) "Yes" else if (vm.mode == Mode.FASTBOOT) "No / unknown" else "Unavailable")
        Btn("USE DETECTED PRODUCT ID (CONFIRM)", vm.mode == Mode.FASTBOOT && vm.product.isNotBlank() && !vm.busy) { vm.adoptDetectedProduct() }
    }
    Panel("FIRMWARE AND PARTITION", false) {
        KV("Flash queue", if (vm.queue.isEmpty()) "No queued images" else "${vm.queue.size} image(s)")
        KV("Queue SHA-256", if (queueOk) "Verified for queued items" else if (vm.queue.isEmpty()) "Standalone image paths verify separately" else "Missing / not verified")
        vm.queue.forEach { item ->
            T("${item.name} → ${item.part.ifBlank { "PARTITION NOT SELECTED" }} (${item.size} bytes)", C.text, 11)
            T(if (vm.verifiedFirmware[item.uri.toString() + "|" + item.size] != null) "Publisher checksum matched; file is re-hashed before transfer" else "BLOCKED: publisher checksum verification required", if (vm.verifiedFirmware[item.uri.toString() + "|" + item.size] != null) C.green else C.red, 10)
        }
        T("Every image needs an explicit partition. Slot, logical/physical type and actual partition capacity are queried again from the bootloader immediately before transfer.", C.amber, 11)
    }
    Panel("CONTROLLER PHONE HEALTH", false) {
        KV("Controller phone battery", battery?.let { "$it%" } ?: "Unavailable")
        KV("Minimum threshold", "${AppSettings.minBattery}% (never below ${AppSettings.MIN_BATTERY_FLOOR}%)")
        KV("Firmware storage free", "${storage / (1024 * 1024)} MB")
        T("This battery value belongs to the FlashForge controller phone, not the connected target phone. Target battery is not assumed.", C.dim, 10)
        if (battery == null || battery < AppSettings.minBattery) T("BLOCKED: controller battery is unavailable or below ${AppSettings.minBattery}%.", C.red, 11, true)
    }
    Panel("WARNINGS — REVIEW BEFORE FLASHING") {
        vm.analyzerWarnings.forEach { T("• $it", C.amber, 11, mod = Modifier.padding(vertical = 3.dp)) }
        T(if (vm.safetyWarningsAcknowledged) "Warnings acknowledged for this connected-device session. They remain visible and the result remains WARNING." else "Warnings are not treated as PASS. Explicit acknowledgement is required before the first image write in this session.", C.dim, 11)
        Rw {
            Btn(if (vm.safetyWarningsAcknowledged) "WARNINGS ACKNOWLEDGED" else "ACKNOWLEDGE WARNINGS", !vm.busy, mod = Modifier.weight(1f)) { vm.acknowledgeSafetyWarnings() }
            Btn("CLEAR ACK", !vm.busy, mod = Modifier.weight(1f)) { vm.clearSafetyWarningAcknowledgement() }
        }
    }
    Panel("LAST ANALYZER CHECKS", false) {
        if (vm.analyzerChecks.isEmpty()) T("No image preflight has run in this session yet. The first flash attempt will run it automatically.", C.dim, 11)
        vm.analyzerChecks.forEach { T(it, if (it.startsWith("PASS")) C.green else if (it.startsWith("BLOCKED")) C.red else C.amber, 10, mod = Modifier.padding(vertical = 2.dp)) }
    }
    Panel("USB AND RECOVERY", false) {
        KV("USB state", vm.link.label)
        T("If USB disconnects or a transfer fails: do not retry automatically. Reconnect and identify the device again, inspect its current screen/mode and the operation log, then follow the OEM recovery procedure. Interrupted partition writes are not resumed by this app.", C.dim, 11)
    }
    Panel("SAFETY DECISION") {
        T(when (effectiveStatus) {
            "PASS" -> "PASS — implemented pre-flash checks passed"
            "BLOCKED" -> "BLOCKED — DO NOT FLASH"
            else -> "WARNING — REVIEW AND ACKNOWLEDGE; WARNINGS REMAIN"
        }, statusColor, 14, true)
        T("A PASS is not a guarantee against unknown hardware, firmware, or vendor-specific risks. A WARNING never becomes a silent PASS.", C.dim, 11)
        Btn("OPEN FLASH QUEUE", true) { vm.screen = Screen.FLASH }
    }
}
