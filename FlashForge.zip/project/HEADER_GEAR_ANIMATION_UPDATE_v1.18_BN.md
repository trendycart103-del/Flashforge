# FlashForge v1.18 — Header Gear Animation Update

- Header-এর বাম পাশের আগের যোগ করা FlashForge logo/icon আর দেখানো হয় না।
- তার জায়গায় দুটি interlocking settings gear যুক্ত করা হয়েছে।
- বড় নীল gear ও ছোট কমলা gear বিপরীত দিকে আলাদা গতিতে ক্রমাগত ঘোরে।
- Gear mark Canvas/vector drawing দিয়ে তৈরি; নতুন bitmap asset বা external dependency লাগে না।
- বাকি header status, bottom navigation, page content ও বিদ্যমান feature অপরিবর্তিত রাখা হয়েছে।

Build note: source পরিবর্তন করা হয়েছে; APK compile success দাবি করা হচ্ছে না।
