# FlashForge v1.23 — Kotlin Build Error Fix (বাংলা)

এই আপডেটটি v1.22 ZIP এবং GitHub Actions-এ দেখানো Kotlin compiler error-এর ভিত্তিতে তৈরি।

## সংশোধন
- `Background.kt`: `androidx.compose.foundation.layout.matchParentSize`-এর ভুল top-level import সরানো হয়েছে। `matchParentSize()` এখানে `BoxScope`-এর receiver extension হিসেবে ব্যবহৃত হচ্ছে।
- `Ui.kt`: `Shadow`-এর import `androidx.compose.ui.text.Shadow` থেকে সঠিক `androidx.compose.ui.graphics.Shadow`-এ পরিবর্তন করা হয়েছে। TextStyle-এর shadow parameter এই graphics Shadow type ব্যবহার করে।
- App version `1.23`, versionCode `19` করা হয়েছে।

## যাচাইয়ের অবস্থা
- ZIP source-এ স্ক্রিনশটে দেখানো ১০টি compiler diagnostic-এর জন্য প্রাসঙ্গিক import correction করা হয়েছে।
- এই পরিবেশে Gradle wrapper নেই এবং system Gradle-ও উপলভ্য নয়; তাই Android Gradle Build চালিয়ে compile success নিশ্চিত করা যায়নি।
- GitHub Actions-এ নতুন ZIP commit/push করে পুনরায় `Build debug APK` চালিয়ে যাচাই করতে হবে।
