FlashForge v1.47 — Compact connection LED

- Reduced the visible LED housing/lens to a compact 23dp indicator while retaining a 40dp header footprint aligned with Settings and About.
- LED color continues to read only MainVM.link (RED/YELLOW/GREEN), the existing USB connection state machine. No simulated or separate connection detector was added.
- No project modules or original files were removed.
