# FlashForge v1.17 — Bottom Navigation UI Update

## পরিবর্তন
- Bottom navigation-এর সাতটি menu item-এর জন্য পৃথক, পরিষ্কার, রঙভিত্তিক vector icon যোগ করা হয়েছে। পুরোনো shared drawable icon অপরিবর্তিত রাখা হয়েছে, যাতে অন্য পেজের icon/design অকারণে না বদলে যায়।
- প্রতিটি মেনুর নিজস্ব accent color নির্ধারণ করা হয়েছে: Device (cyan), Flash (orange), ROM & Root (violet), Log (teal), Safety (rose), Settings (blue), About (amber)।
- Selected tab-এ soft tinted circular tile, subtle outline, icon scale feedback এবং ছোট active indicator যুক্ত হয়েছে।
- Page transition-এ আগের fade + একমুখী slide-এর বদলে direction-aware slide, fade ও subtle scale transition ব্যবহার করা হয়েছে। কোন tab-এ এগোনো হচ্ছে বা পিছোনো হচ্ছে তার ভিত্তিতে transition-এর দিক বদলায়।
- বিদ্যমান tab visibility, horizontal scrolling, screen routing এবং page content অপরিবর্তিত রাখা হয়েছে।

## Build status
এই পরিবেশে Gradle 8.7/Android SDK build tool ইনস্টল নেই, তাই এখানে assemble/lint চালিয়ে APK compile নিশ্চিত করা যায়নি। GitHub Actions workflow-এ `testDebugUnitTest lintDebug assembleDebug` চালানোর জন্য প্রজেক্ট প্রস্তুত রাখা হয়েছে।
