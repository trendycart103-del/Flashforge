# FlashForge UI Update v1.41 — Horizontal Neon Tabs & Wheel Controls

- Main navigation remains a single horizontal tab strip and now scrolls horizontally when all destinations do not fit on screen.
- Main navigation labels include the full `ROM & ROOT` name; Device, Flash, ROM & Root, Log, Safety, Settings and About remain accessible.
- Shared page action buttons use a raised metallic neon surface with cyan/magenta edge lighting, gloss and a circular icon orb.
- Compact icon controls are now circular metallic neon controls to match the supplied wheel reference.
- Existing Device mode wheel, Flash action wheel and ROM & Root action wheel remain the page-specific radial controls.
- UI-only changes: no device, ADB, Fastboot, firmware flashing, ROM, root, chipset or safety operation logic was intentionally changed.

Validation: source-level inspection and ZIP integrity check completed. Android Gradle compilation could not be run because Gradle/Android SDK are unavailable in this environment.
