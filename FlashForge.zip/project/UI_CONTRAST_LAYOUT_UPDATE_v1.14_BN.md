# FlashForge UI Contrast/Layout Update v1.14 (Bangla)

## পরিবর্তন
- Main app background থেকে wallpaper/image rendering বাদ দিয়ে clean, high-contrast light gradient ব্যবহার করা হয়েছে।
- UI blueprint/blob decoration বন্ধ করা হয়েছে।
- Common panel/surface transparency 0.82 থেকে 0.98 করা হয়েছে, যাতে background content আর text-এর সঙ্গে মিশে না যায়।
- Flash Page-এর Automatic vbmeta warning আলাদা amber surface, border, padding ও spacing-সহ দেখানো হয়; button row-এর সঙ্গে overlap হওয়া এড়ানো হয়েছে।
- Settings-এ wallpaper picker-কে misleading না রেখে background mode সম্পর্কে স্পষ্ট লেখা দেখানো হয়েছে; wallpapers এখন UI-এর পেছনে render হয় না।
- Version 1.13 / code 12 থেকে 1.14 / code 13।

## Validation
- ZIP integrity: verified after packaging.
- XML parsing: checked.
- JSON parsing: checked where JSON resources exist.
- Android Gradle build/runtime UI test: not run (Gradle/Android SDK unavailable in this environment).
- The screenshot issue is addressed at the source layout/surface level; actual device visual confirmation is still required.
