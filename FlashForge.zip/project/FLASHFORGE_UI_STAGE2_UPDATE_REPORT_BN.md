# FlashForge UI Stage 2 – Update Report (বাংলা)

## ভিত্তি
এই আপডেটটি `FlashForge-UI-only-neon-update(1).zip`-এর ওপর করা হয়েছে। মূল কার্যকরী কোড, USB detection, Fastboot/ADB transport, flashing guards, checksum verification এবং safety workflow অক্ষত রেখে UI স্তরে পরিবর্তন করা হয়েছে।

## সম্পন্ন UI পরিবর্তন
1. ব্যবহারকারীর সরবরাহ করা 5×5 3D icon sheet থেকে 25টি স্বচ্ছ PNG icon crop করে `drawable-nodpi`-তে যোগ করা হয়েছে।
2. Device/Flash/ROM & Root/Log/Safety/Settings/About navigation-এ সংশ্লিষ্ট 3D icon ব্যবহার করা হয়েছে।
3. Device এবং Flash পেজে ব্যবহৃত ModeWheel-কে পাঁচটি glossy radial sector-এ রূপান্তর করা হয়েছে: EDL, BROM, Download, Fastboot এবং Recovery। প্রতিটি sector আগের guarded `WheelMode` command-এ যুক্ত; নতুন low-level flashing command যোগ করা হয়নি।
4. Tab bar-কে glossy purple 3D rounded tile, বড় icon, উজ্জ্বল outline ও নির্বাচিত tab indicator দিয়ে নতুনভাবে সাজানো হয়েছে। ছোট স্ক্রিনে horizontal scrolling বজায় আছে।
5. Flash tools dashboard-এর tiles-এ emoji-র বদলে supplied 3D icon ব্যবহার এবং glossy purple tile styling যোগ করা হয়েছে।
6. Log ও Safety পেজের প্রধান section-এ মিলযুক্ত 3D icon যোগ করা হয়েছে; About পেজের InfoCard-গুলোকে theme-aware rounded card ও outline-এ সাজানো হয়েছে।
7. ROM & Root পেজে আটটি launch tile যোগ করা হয়েছে: Install Custom ROM, Install Root/Magisk, Xposed Modules, ROM Manager, Install Recovery, Kernel Manager, Manage ROM, Uninstall Root। বিদ্যমান Unlock/ROM/Root/Partitions workflow বজায় আছে। Xposed Modules, ROM Manager, Kernel Manager ও Uninstall Root আপাতত setup-ready placeholder; এগুলো কোনো অপারেশন চালায় না।
8. Settings-এ চারটি Built-in Theme selector যোগ করা হয়েছে: Light Purple 3D, Midnight Neon, Electric Blue এবং Soft Cyan Circuit। নির্বাচন SharedPreferences-এ সংরক্ষিত হয়।
9. App version 1.28 / versionCode 24 করা হয়েছে।

## কার্যকারিতা ও নিরাপত্তা
- Device auto-detection এবং USB connection flow-তে পরিবর্তন করা হয়নি।
- Existing Fastboot/ADB command handlers এবং safety confirmations পুনর্ব্যবহার করা হয়েছে।
- নতুন ROM & Root placeholder থেকে কোনো অযাচাইকৃত Root/Xposed/Kernel command execute হয় না।
- Flashing queue, SHA-256 verification, model guard, vbmeta safety notice এবং chipset loader restrictions অপরিবর্তিত রাখা হয়েছে।

## যাচাইয়ের অবস্থা
- ZIP archive integrity এবং Android resource reference names পরীক্ষা করা হয়েছে।
- Kotlin source syntax scan-এ parser-level `expecting`/syntax error পাওয়া যায়নি।
- এই পরিবেশে Gradle/Android SDK উপলভ্য না থাকায় `assembleDebug`, `lintDebug` বা Android device runtime test চালানো সম্ভব হয়নি। তাই Android compile সফল হয়েছে বলে দাবি করা হচ্ছে না।

## পরবর্তী ধাপ
ব্যবহারকারী পরে নির্দেশ দিলে Xposed Modules, ROM Manager, Kernel Manager, Manage ROM ও Uninstall Root-এর জন্য ডিভাইস/Android version অনুযায়ী compatibility, permission, safety confirmation এবং বাস্তব operation আলাদাভাবে যুক্ত করতে হবে।
