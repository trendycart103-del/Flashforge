**ঐতিহাসিক রিপোর্ট:** এই রিপোর্টের বর্তমান-অবস্থা অংশগুলো v1.12 দ্বারা superseded। বর্তমান Logical Partition, Resume, Restore ও Database অবস্থা `UPDATE_REPORT_BN_v1.12.md` এবং README-তে দেখুন।

---

# FlashForge Android — Update Report (v1.7)

## Changes in this package
- Added persistent app-language preference with exactly two choices: Bangla (`bn`) and English (`en`).
- Added language selection dialog to Settings. The preference is saved in the existing SharedPreferences store and defaults to Bangla.
- Settings page language-selector labels and dialog labels are localized for the selected language.
- Incremented app versionCode to 7 and versionName to 1.7.

## Remaining work (not falsely marked complete)
- Whole-app translation: other screens still contain hard-coded English strings and need localization pass.
- Additional audit and implementation of firmware/device/backup modules remain as described in the technical audit.
- Android build, emulator, and USB hardware tests were not run: this environment has no Android SDK/Gradle wrapper available.

## Safety scope
This update does not add protection bypasses or unrestricted low-level flashing. Unsupported/authorization-dependent recovery paths remain clearly limited.
