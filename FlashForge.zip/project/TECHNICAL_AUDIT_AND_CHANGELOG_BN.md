# FlashForge — বাংলা টেকনিক্যাল অডিট ও পরিবর্তন বিবরণ

## ১. এই সংস্করণে কী করা হয়েছে

এই আপডেটটি সরবরাহ করা `FlashForge_Safety_Gate_Enforced.zip`-এর ওপর করা হয়েছে। নতুন অ্যাপ বানানো হয়নি। মূল `com.flashforge` namespace/application ID, Kotlin ও Jetpack Compose architecture, মূল navigation, theme/resources, device database এবং বিদ্যমান পেজগুলো রেখে সংশোধন করা হয়েছে।

সবচেয়ে গুরুত্বপূর্ণ পরিবর্তন হলো: **কোনো Image Flash path-এ আলাদা করে Safety Analyzer এড়িয়ে USB-তে `flash:` command পাঠানো যাবে না।**

## ২. আগের অডিটে পাওয়া সমস্যাগুলোর সমাধান

| আগের অডিটে পাওয়া সমস্যা | এই সংস্করণে করা সমাধান | অবস্থা |
|---|---|---|
| Logical partition CREATE/RESIZE/DELETE command destructive guard এড়িয়ে যেতে পারত | UI control রাখা হয়েছে কিন্তু disable করা হয়েছে; `Fastboot.cmd()` transport layer-এও command authorization callback ছাড়া destructive command গ্রহণ করে না | সংশোধিত / ফিচার নিরাপদে বন্ধ |
| Wipe-এ `erase:userdata` ব্যর্থ হলেও `erase:metadata` চলত | প্রথম erase ব্যর্থ হলে exception দিয়ে থামে; metadata erase আর পাঠানো হয় না | সংশোধিত |
| USB transfer মাঝপথে থামলে Fastboot protocol DATA state-এ থেকে যেতে পারত | transfer/read/write/hash/response failure-এ protocol state uncertain করা হয়; Fastboot session invalid করে `RECONNECT USB` প্রয়োজন হয় | সংশোধিত |
| Fastboot `FAIL` response-এর পর UI ভুলভাবে Success দেখাতে পারত | command-এর `r.ok` বাধ্যতামূলক; FAIL হলে operation failed হিসেবে journal/log হয় | সংশোধিত |
| Stream `read()` শূন্য ফেরালে hash/transfer loop আটকে যাওয়ার ঝুঁকি | SHA-256, Fastboot transfer, ZIP extraction, download এবং ADB block read-এ zero-byte read আলাদা error | সংশোধিত |
| USB disconnect বা process death-এর পর শেষ ধাপ জানা যেত না | persistent operation journal ও সর্বশেষ ১০০টি operation history যোগ; app restart-এ RUNNING operation-কে INTERRUPTED হিসেবে রেকর্ড করে | উন্নত; পূর্ণ resume নয় |
| ZIP-এর কিছু Image extract হওয়ার পর archive corruption হলে partial file queue-তে থাকতে পারত | staging directory-তে পুরো ZIP extract/CRC read শেষ না হওয়া পর্যন্ত queue-তে কিছু যোগ হয় না; failure-এ staged/committed file cleanup | সংশোধিত |
| Backup আংশিক ফাইল রেখে যেতে পারত বা metadata ছাড়া ফাইল থাকতে পারত | `.partial` ফাইল, partition size ও storage check, SHA-256, metadata temp file; ব্যর্থ হলে অসম্পূর্ণ backup cleanup | সংশোধিত |
| Backup আগের ফাইল overwrite করতে পারত | timestamped filename এবং existing-file collision হলে overwrite না করে fail | সংশোধিত |
| Persistent operation history ছিল না | operation type, product ID, filename, partition, SHA-256, result, error ও last confirmed step সংরক্ষণ; log export-এ যুক্ত | উন্নত |
| Slow USB speed threshold গণনা হলেও warning দেখাত না | 2 MiB/s-এর নিচে টানা ৩টি sample হলে cable warning | সংশোধিত |
| Fastboot session invalid হলে একই USB device-এ সহজে reconnect করা যেত না | একই device ID থাকলেও `fb == null` হলে scan পুনরায় connect চেষ্টা করে; Device page-এ `RECONNECT USB` button | সংশোধিত |
| Slot change response যাচাই করা হতো না | command FAIL হলে থামে; OKAY-এর পর `current-slot` আবার পড়ে target slot-এর সঙ্গে মিলিয়ে দেখে | সংশোধিত |
| file metadata/URI সমস্যা picker callback-এ crash ঘটাতে পারত | URI metadata, permission, descriptor size এবং file readability error catch করে log; invalid file queue-তে যোগ হয় না | সংশোধিত |
| Firmware filename থেকে partition অনুমান করা হতো | filename থেকে partition আর অনুমান করা হয় না; প্রতিটি queue item-এ explicit target partition field | সংশোধিত |
| Recovery/Boot standalone path-এ publisher checksum দেওয়ার UI ছিল না | standalone Recovery এবং patched Boot image-এর জন্য আলাদা checksum input ও Verify action | সংশোধিত |
| non-critical warning নীরবে pass হতে পারত | Safety Analyzer-এ warning acknowledgement বাধ্যতামূলক; ফলাফল WARNING-ই থাকে, critical failure acknowledge করে bypass করা যায় না | সংশোধিত |
| Bootloader lock ও vbmeta UI স্বাভাবিক flash হিসেবে দেখাত | দুই অপশনই UI-তে disabled এবং limitation ব্যাখ্যা; automatic vbmeta patch বন্ধ | সংশোধিত / ফিচার নিরাপদে বন্ধ |
| ADB sideload normal Android ADB ও Recovery Sideload আলাদা করত না; package integrity দুর্বল ছিল | ADB recovery/sideload banner বাধ্যতামূলক; normal `device` state BLOCKED; trusted publisher SHA-256; private cache staging; transfer digest check; interface/connection cleanup | উন্নত; hardware validation বাকি |

## ৩. Image Flash Safety Gate-এর বর্তমান প্রবাহ

বর্তমান কোডে সব Image Flash path একটিমাত্র application-level function-এ যায়:

`MainVM.executeVerifiedFlash()` → `Fastboot.flash()` → mandatory authorization callback → `verifyFlashGate()`

এই path ব্যবহার করে:

- Flash Queue
- Recovery Image Flash
- Patched Boot Image Flash

`Fastboot.cmd()`-এ raw `flash:` command সরাসরি BLOCKED। Raw `download:` এবং unreviewed Fastboot command-ও command whitelist/authorization ছাড়া গ্রহণ করা হয় না। `Fastboot.command()` private; transport layer-এ আলাদা public raw flash path নেই।

### প্রতিটি Flash-এর আগে যা যাচাই হয়

1. Fastboot mode এবং ready USB connection
2. live `getvar:product` পুনরায় পড়ে expected product ID-এর সঙ্গে মিল
3. user-নিশ্চিত expected product ID ফাঁকা নয়
4. file URI/readability/size
5. আগে দেওয়া publisher SHA-256
6. একই ফাইলের SHA-256 Flash-এর ঠিক আগে পুনরায় গণনা
7. USB transfer চলাকালীন SHA-256 পুনরায় গণনা ও digest comparison
8. Controller phone battery অন্তত ৪০%; target phone battery বলে কোনো অজানা মান দেখানো হয় না
9. slot-count/current-slot পুনরায় যাচাই
10. A/B partition হলে `has-slot` যাচাই এবং `_a`/`_b` suffix স্পষ্ট থাকা
11. `is-logical` যাচাই; logical partition হলে Fastbootd mode বাধ্যতামূলক
12. bootloader-এর `partition-size` query
13. Android sparse image হলে expanded footprint হিসাব করে partition capacity-র সঙ্গে তুলনা
14. bootloader `download` ও `flash` response প্রকৃতপক্ষে সফল কি না

কোনো critical তথ্য পাওয়া না গেলে Flash BLOCKED। Publisher checksum-এর উৎস অ্যাপ নিজে authenticate করতে পারে না এবং সব ডিভাইসের hardware variant/build metadata Fastboot থেকে পাওয়া যায় না—এগুলো স্পষ্ট WARNING হিসেবে দেখানো হয়। প্রথম Image write-এর আগে Safety Analyzer পেজে ব্যবহারকারীকে এই warning-গুলো আলাদাভাবে acknowledge করতে হয়। Acknowledgement-এর পরও ফলাফল `WARNING`-ই থাকে; এটি `PASS` হয়ে যায় না। Critical failure acknowledgement দিয়ে এড়ানো যায় না। `PASS` হলেও অজানা vendor/hardware risk-এর বিরুদ্ধে শতভাগ নিশ্চয়তা নয়।

## ৪. Destructive Fastboot Command সুরক্ষা

- `erase:`-এর জন্য explicit in-app confirmation, live product check, controller battery check এবং bootloader partition-size query প্রয়োজন।
- `flashing unlock` ও legacy `oem unlock`-এর জন্য explicit confirmation, live product check এবং battery check প্রয়োজন।
- `set_active:`-এর জন্য confirmation, A/B slot-count, valid target slot এবং command-এর পর `current-slot` re-check হয়।
- Wipe-এ userdata erase ব্যর্থ হলে metadata erase পাঠানো হয় না।
- Logical partition create/resize/delete এবং super partition modification এই build-এ disabled; কারণ group geometry/metadata constraints পুরোপুরি যাচাই করা হয় না।
- Bootloader lock disabled; modified বা incompatible image থাকলে relock boot failure ঘটাতে পারে এবং এই app stock compatibility প্রমাণ করতে পারে না।
- Automatic vbmeta patch/flash disabled; Android Verified Boot দুর্বল করা হয় না।
- raw/unknown Fastboot command default deny।

## ৫. USB failure, interruption ও app restart

- Fastboot USB bulk transfer exception, timeout, malformed response, partial transfer, file read failure, hash mismatch এবং backup output failure protocol state uncertain করে।
- uncertain session-এ পরবর্তী command প্রত্যাখ্যান হয়; session বন্ধ করে UI-তে `RECONNECT USB` প্রয়োজন হয়।
- USB detach হলে active Fastboot connection বন্ধ হয়; unrelated USB device detach event হলে current device অকারণে disconnect করা হয় না।
- Flash transfer ব্যর্থ হলে পরের queue image চালানো হয় না এবং destructive operation auto-retry হয় না।
- journal-এ DOWNLOAD accepted, data transfer in progress, checksum matched/FLASH command about to be issued এবং bootloader OKAY-এর মতো শেষ নিশ্চিত ধাপ রাখা হয়।
- app process restart-এ RUNNING operation INTERRUPTED হয়; app আগের Flash স্বয়ংক্রিয়ভাবে আবার চালায় না।
- partition write-এর safe resume এই app দাবি করে না।
- Flash সফল হওয়ার পর কোনো automatic reboot, `finish()` বা `System.exit()` যোগ করা হয়নি। reboot কেবল ব্যবহারকারীর আলাদা button action।

## ৬. Firmware ও Backup

### Firmware/ZIP/Download

- ZIP extraction staging folder-এ হয়; সর্বোচ্চ ৫১২ entry, এক entry ১ GiB এবং মোট ৪ GiB সীমা; path ব্যবহার না করে নিরাপদ basename; duplicate image filename reject; zero-byte read reject; archive সম্পূর্ণ পড়া না হলে queue update নয়।
- HTTPS download-এ redirect HTTPS-ই থাকতে হয়; redirect limit ৫; server-কে positive Content-Length দিতে হয় এবং exact size match বাধ্যতামূলক; অস্থায়ী `.download` ফাইল; existing firmware file overwrite নয়; ৪ GiB stream limit। Content-Length না থাকলে download BLOCKED।
- filename থেকে partition আর অনুমান হয় না। user-কে queue item-এ partition লিখতে হয়।

### Backup

- Bootloader `fetch` support না করলে backup blocked/failed।
- `partition-size` ও `fetch`-এর size মিলতে হবে; storage free space check হয়।
- temporary file থেকে finalize, SHA-256 ও JSON metadata; existing backup overwrite নয়।
- Backup Restore এখনো implement করা হয়নি।

## ৭. ADB Sideload

- normal Fastboot বা normal Android ADB `device` state-এ sideload নয়; ADB USB interface-এর পাশাপাশি recovery/sideload banner state বাধ্যতামূলক।
- package আগে private app cache-এ stream করে copy করা হয়; size ও publisher SHA-256 মিললে তবেই protocol শুরু হয়।
- ADB transport-এ local SHA-256 pre-read এবং transfer-এর requested blocks-এর SHA-256 তুলনা হয়; block order/duplicate request অস্বাভাবিক হলে transfer stop।
- Publisher SHA-256 user-কে trusted source থেকে দিতে হয়; app source authenticity নিজে প্রমাণ করে না। Recovery-এর transport completion-ও installation success-এর নিশ্চয়তা নয়।
- ADB AUTH/key authorization এখনো implemented নয় এবং physical recovery test হয়নি। Recovery banner যাচাই হয়, কিন্তু Recovery ADB transport থেকে target product ID/hardware variant নির্ভরযোগ্যভাবে query করা এখনো implemented নয়; তাই sideload package compatibility আলাদাভাবে OEM নির্দেশনা দিয়ে নিশ্চিত করতে হবে।

## ৮. Crash/Resource review

- Large file processing streaming buffer-এ; পুরো firmware memory-তে load করা হয় না।
- Content URI metadata/permission/open errors catch করা হয়।
- `InputStream` zero-byte read infinite loop এড়ানো হয়েছে।
- ZIP extraction path traversal/duplicate basename/oversize/partial commit guard করা হয়েছে।
- Fastboot/ADB USB interface release ও connection close cleanup যোগ হয়েছে।
- Fastboot command failure-এর পর operation Success হিসেবে চিহ্নিত হয় না।
- operation coroutine `viewModelScope` ও `withContext(Dispatchers.IO)` ব্যবহার করে; cancellation journal-এ INTERRUPTED হয়।
- Floating Bubble/Intent/notification এবং USB cleanup-এর পূর্বের silent catch-গুলোতে diagnostic log যোগ হয়েছে।
- ViewModel cleanup-এ Fastboot connection close হয়।

## ৯. আগের অডিটের সব সমস্যা সমাধানের অবস্থা

**আগের অডিটে সরাসরি পাওয়া এবং কোডে সংশোধন করা সমস্যাগুলো:** logical partition command bypass, wipe second erase after failure, transfer protocol state uncertainty, Fastboot FAIL handling, zero-byte read, partial ZIP queue, backup partial file/overwrite, operation history, slow speed warning, reconnect path, slot change verification, file/URI error handling, filename-based partition inference, standalone image checksum UI, vbmeta/lock misleading UI।

**সীমাবদ্ধতা/অসম্পূর্ণ:**

- এই পরিবেশে Android SDK/Gradle নেই; প্রকৃত Android Gradle compilation বা APK তৈরি করা হয়নি।
- ZIP-এ Gradle Wrapper নেই।
- কোনো physical USB/Fastboot device-এ destructive বা non-destructive hardware test চালানো হয়নি।
- ADB sideload actual recovery compatibility test হয়নি; AUTH/key support নেই।
- Backup Restore নেই।
- Firmware download resume নেই।
- Firmware package build/region/CSC metadata parser পূর্ণ নয়।
- Qualcomm EDL Sahara/Firehose, MediaTek BROM/DA, Samsung Download Mode flashing এবং Unisoc FDL flashing বাস্তবায়িত নয়; detection মানেই support নয়।
- Logical partition modification, bootloader locking ও vbmeta automatic patch/flash disabled।
- Operation history সর্বশেষ ১০০টি operation রাখে।
- sparse image parser standard Android sparse header/chunk structure ও expanded size যাচাই করে; publisher SHA-256-ই content authenticity-এর ভিত্তি নয়। publisher checksum trusted source থেকে ব্যবহারকারীকে আনতে হবে।

## ১০. Validation report

| পরীক্ষা | ফলাফল |
|---|---|
| Original project file inventory/diff | সম্পন্ন |
| Original Kotlin/resource/database files preserved | archive comparison দিয়ে যাচাই |
| `unzip -t` ZIP integrity | PASS |
| Image Flash call-site search | একটিমাত্র USB `Fastboot.flash()` transport path পাওয়া গেছে |
| Raw `flash:` command block | source-level check PASS |
| Raw `download:` / unknown Fastboot command block | source-level check PASS |
| Wipe stop-on-first-failure | source-level check PASS |
| Queue blank partition / missing SHA gate | source-level check PASS |
| ZIP transactional extraction | source-level check PASS |
| Parser/syntax scan with standalone kotlinc | syntax/expecting/redeclaration diagnostics পাওয়া যায়নি; Android/AndroidX classpath অনুপস্থিত থাকায় এটি Android compile নয় |
| `./gradlew clean` | NOT RUN — মূল ZIP-এ Gradle Wrapper নেই |
| `./gradlew assembleDebug` | NOT RUN — wrapper/Gradle/Android SDK নেই |
| `./gradlew test` | NOT RUN — wrapper/Gradle/Android SDK নেই |
| `./gradlew lint` | NOT RUN — wrapper/Gradle/Android SDK নেই |
| Physical USB/Fastboot/Recovery tests | NOT RUN |
| Debug APK | তৈরি হয়নি |

**চূড়ান্ত সতর্কতা:** এই সংস্করণে source-level safety hardening ও crash-path handling করা হয়েছে। Android Studio build এবং authorized test device-এ hardware validation না হওয়া পর্যন্ত এটিকে production-tested বা crash-free বলা যাবে না।

## ১১. লোগো ইন্টিগ্রেশন (Flash Forge লোগো)

- নতুন vector লোগো: `res/drawable/ic_logo.xml` (কমলা টাইল, দুই ফোন, OTG ও USB ক্যাবল, Flash বাটন, Fastboot গিয়ার)।
- অ্যাডাপটিভ লঞ্চার আইকন: `ic_launcher_bg.xml`, `ic_launcher_fg.xml`, `ic_launcher_mono.xml` (Android 13 themed icon সহ)।
- নোটিফিকেশন আইকন `ic_notif.xml` ও নোটিফিকেশন অ্যাকসেন্ট রঙ লোগোর কমলা (`#E4501A`) করা হয়েছে।
- `Ui.kt`: `AppLogo()` এখন নতুন লোগো দেখায়; হেডারে `AppWordmark()` ("Flash" + কমলা "Forge")।
- Build fix: `AppSettings.setDefBackup/setDefRecovery/setDefPatched` নাম Kotlin property setter-এর সাথে JVM signature clash করছিল; নাম বদলে `updateDefBackup/updateDefRecovery/updateDefPatched` করা হয়েছে (`Settings.kt`, `SettingsPage.kt`)।

## ১২. UI সাজানো (শুধু লেআউট; কোনো লজিক/সেফটি পরিবর্তন নেই)

- `Panel` এখন ক্লিক করলে খোলে/বন্ধ হয় (`startOpen` প্যারামিটার, ডিফল্ট খোলা)। বন্ধ অবস্থায়ও কনটেন্ট কম্পোজড থাকে, তাই লেখা ফিল্ডের মান ও স্টেট হারায় না।
- `KV` সারি টেবিলের মতো ডিভাইডার-সহ।
- Flash, Custom ROM (৭টি ধাপ আলাদা প্যানেল), Root, Modes, Safety পেজের দ্বিতীয় স্তরের প্যানেল বন্ধ অবস্থায় শুরু হয়।
- Settings পেজে শুধু USB/OTG সহায়তা (OTG সেটিং খোলার বাটন), Display, Colors, Tabs, Bubble, Reset রাখা হয়েছে।
- Settings থেকে সরানো: Default partition names, USB cable alert limits, Log lines, Minimum battery। এগুলোর ডিফল্ট মান (`AppSettings`) অপরিবর্তিত ও কার্যকর; Partition নাম প্রতিটি পেজেই আলাদা ফিল্ডে বদলানো যায়।
- Device database প্যানেল Log পেজে সরানো হয়েছে (পেজের লেখায় আগে থেকেই "Log tab" বলা ছিল)।

## ১৩. লোগো ব্যাকগ্রাউন্ড অপসারণ

- লঞ্চার আইকনের ব্যাকগ্রাউন্ড স্বচ্ছ (`ic_launcher_bg.xml`); শুধু দুই ফোন ও ক্যাবল থাকে। গোল মাস্কেও কিছু না কাটার জন্য আইকন ছোট (scale 0.13) করা হয়েছে।
- অ্যাপের ভেতরের `ic_logo.xml` থেকেও কমলা টাইল বাদ; শুধু ফোন-ক্যাবল আর্ট।

## ১৪. Settings সরলীকরণ, ব্যাকগ্রাউন্ড ইমেজ ও বাবল

- Settings এখন শুধু: USB/OTG সহায়তা এবং Background Image (২টি ডিফল্ট ছবি + ফোন থেকে নিজের ছবি)। Colors, Display, Tabs, Bubble, Reset প্যানেল সরানো হয়েছে; এগুলোর ডিফল্ট মান কোডে আগের মতোই আছে। সব ট্যাব সবসময় দেখা যায়।
- ডিফল্ট ছবি: `res/drawable-nodpi/bg_default_1.jpg`, `bg_default_2.jpg`। নিজের ছবি `OpenDocument` দিয়ে বাছা হয়, URI সংরক্ষিত থাকে; ছবি পড়া না গেলে ডিফল্ট ১ দেখায় (`Background.kt`)।
- বাবল: অ্যাপ নতুন চালু হলে প্রয়োজনীয় Notification ও "Display over other apps" permission নিজে থেকে চাওয়া হয় (`MainActivity.kt`)। ফ্ল্যাশ/ব্যাকআপ চলাকালীন অ্যাপ ব্যাকগ্রাউন্ডে গেলে বাবল স্বয়ংক্রিয়ভাবে দেখায়; বাবল বা নোটিফিকেশনে ক্লিক করলে অ্যাপ খুলে Flash পেজে যায়।

## ১৫. কোড রিভিউ-পরবর্তী সংশোধন

| সমস্যা | সমাধান | ফাইল |
|---|---|---|
| USB permission "Deny" করলে dialog বারবার খুলত (infinite loop) | deny হলে ডিভাইস মনে রাখা হয়; re-plug বা RECONNECT বোতাম ছাড়া আর প্রশ্ন করে না; dialog খোলা অবস্থায় প্লাগ খুললে pending অবস্থা পরিষ্কার হয় | `MainVM.kt`, `MainActivity.kt`, `Ui.kt` |
| একাধিক USB ডিভাইস থাকলে প্রথমটিই বাছা হতো (হাব/কিবোর্ড হতে পারত) | চালু ডিভাইস অগ্রাধিকার, তারপর চেনা মোডের (Fastboot/ADB ইত্যাদি) ডিভাইস | `MainVM.kt` |
| ADB sideload শুধু ক্রমানুসারে block মানত; বাস্তব recovery ZIP-এর শেষ অংশ আগে পড়ে, তাই প্রায় সব sideload থামত | যেকোনো ক্রমে block গ্রহণ (ফাইলের সীমার ভেতরে, অনুরোধ সংখ্যার সীমা সহ); transfer শেষে staged ফাইল আবার হ্যাশ করে যাচাই | `AdbSideload.kt` |
| `Fastboot.fetch()` partition নাম নিজে যাচাই করত না | transport স্তরেই নাম যাচাই | `Fastboot.kt` |
| `backup()`-এ একই নামের `base` ভেরিয়েবল ঢাকা পড়ত | `basePart` নামে আলাদা করা হয়েছে | `MainVM.kt` |
| app restart-এ read-only কাজ (connect, refresh, hash ইত্যাদি) interrupted দেখালেও Safety Analyzer BLOCKED হয়ে যেত | শুধু লগ হয়; Flash/Erase/Unlock/Slot/Sideload ধরনের কাজে আগের মতোই BLOCKED | `MainVM.kt` |
| README-তে ধাপ নম্বর ৭ দুইবার ছিল | ঠিক করা হয়েছে | `README.md` |

**যাচাই:** এই পরিবেশে Android SDK, Gradle ও kotlinc নেই, তাই কম্পাইল বা টেস্ট চালানো যায়নি। শুধু ব্র্যাকেট ভারসাম্য ও UI/ViewModel/Settings-এর মধ্যে ফাংশন-নামের মিল স্ক্রিপ্ট দিয়ে যাচাই হয়েছে (কোনো অনুপস্থিত নাম নেই)। Android Studio-তে বিল্ড করে নিশ্চিত করতে হবে।

## ১৬. ট্যাব একত্রীকরণ: ROM & Root

- আগের তিনটি ট্যাব (UNLOCK, CUSTOM ROM, ROOT) এখন একটি ট্যাব **ROM & Root**-এ। মোট ট্যাব ১০ থেকে ৮টি।
- পেজের শুরুতে একটি টেবিলে ১১টি ধাপ ক্রমানুসারে দেখানো হয়: **UNLOCK** (১), **CUSTOM ROM** (২–৮), **ROOT** (৯–১১)। প্রতিটি সারিতে ধাপ নম্বর, বড় আইকন, নাম ও সংক্ষিপ্ত কাজ আছে।
- তারপর প্রতিটি ধাপের নিজস্ব প্যানেল; প্যানেলের শিরোনামে রঙিন ফ্রেমে বড় আইকন (UNLOCK সবুজ, CUSTOM ROM নীল, ROOT কমলা)।
- সব বোতাম, আইকন, লেখা, কনফার্মেশন ডায়ালগ ও Safety Gate অপরিবর্তিত। শুধু দুই জায়গার (ROM ও Root) আলাদা BACKUP একটিই ধাপ (৩) হয়েছে।
- নতুন "REQUIREMENTS AND STATUS" টেবিলে সংযোগ মোড, bootloader unlocked অবস্থা, Model guard ও warning acknowledgement দেখায় (আগের Requirements প্যানেলের সম্প্রসারণ)।
- কোড: `RomRootPage` (`Pages.kt`), `Panel`-এ নতুন `icon`/`accent` প্যারামিটার ও `IconTile`, `StepGroup` (`Ui.kt`), `Screen` enum থেকে UNLOCK ও ROOT বাদ (`Model.kt`)। কম্পাইল এখানে চালানো যায়নি।

## ১৭. MODES ট্যাব অপসারণ

- MODES পেজের "CURRENT MODE" (মোড, ভেন্ডর, চিপ) DEVICE পেজের "DETECTED DEVICE"-এ আগে থেকেই ছিল, তাই ট্যাবটি অপ্রয়োজনীয় ছিল। ট্যাব ৮ থেকে ৭টি।
- অচেনা/অসমর্থিত মোডের সতর্কবার্তা এখন "DETECTED DEVICE"-এর নিচে দেখায়।
- "HOW TO ENTER EACH MODE" গাইড DEVICE পেজের শেষে একটি প্যানেলে গেছে; ডিভাইস না থাকলে বা অচেনা হলে নিজে থেকে খোলা থাকে।
- EDL/MediaTek ঐচ্ছিক loader নির্বাচন FLASH পেজেই থাকছে (অপরিবর্তিত)। Fastboot/ADB ছাড়া অন্য মোডে সংযোগ হলে অ্যাপ এখন DEVICE পেজ খোলে।
- বদলানো ফাইল: `Pages.kt`, `Ui.kt`, `Model.kt`, `MainVM.kt`। কম্পাইল এখানে চালানো যায়নি।

## ১৮. ROM & Root পেজ ছোট ও গোছানো করা

- ধাপ নম্বর (১–১১) সব জায়গা থেকে বাদ। "ALL STEPS IN ORDER" তালিকাও বাদ।
- পেজের শুরুতে ছোট স্ট্যাটাস সারি (Mode, Bootloader, Model guard, Warnings read) এবং PC সফটওয়্যারের মতো তিনটি ট্যাব বোতাম: **UNLOCK / ROM / ROOT**। একসময় শুধু নির্বাচিত ট্যাব দেখায়, তাই পেজ অনেক ছোট।
- বোতামগুলো ছোট (compact) আকারে পাশাপাশি দুটি করে (যেমন VERIFY | FLASH, WIPE | REBOOT TO RECOVERY); ফাইল বাছাই বোতাম ও ফাইলের নাম একই লাইনে।
- দীর্ঘ নির্দেশনা সংক্ষেপ করা হয়েছে। কম দরকারি লেখা প্রতিটি ট্যাবের শেষে ভাঁজ-করা **GOOD TO KNOW** টেবিলে গেছে।
- বাদ গেছে শুধু দুটি অকেজো (সবসময় disabled) নিয়ন্ত্রণ: LOCK বোতাম ও vbmeta ফাইল বাছাই; দুটোই এখন টেবিলে লেখা আকারে আছে।
- কোড: `RomRootPage` (`Pages.kt`); `Ui.kt`-তে `SegTabs`, `StatusStrip`, `NoteTable`, এবং `Panel`/`Btn`/`ConfirmBtn`/`PickBtn`-এ নতুন ঐচ্ছিক `dense`/`compact` প্যারামিটার (অন্য পেজ অপরিবর্তিত)। কম্পাইল এখানে চালানো যায়নি।

## ১৯. মোড চক্র (Mode Wheel)

- নতুন গোল নিয়ন্ত্রণ: চারটি রঙিন অংশ **EDL MODE, VROOM MODE, DOWNLOAD MODE, FASTBOOT MODE** এবং মাঝখানে **RESTART**। DEVICE পেজে বড় আকারে, FLASH পেজের উপরে ছোট আকারে (একই কোড `ModeWheel.kt`)।
- FASTBOOT: Fastboot-এ `reboot-bootloader`, recovery ADB-তে `reboot:bootloader`। RESTART চাপলে মেনু: Reboot System ও Reboot to Recovery। EDL, VROOM, DOWNLOAD চাপলে আগে নিশ্চিতকরণ ডায়ালগ।
- EDL: Fastboot-এ `oem edl`, recovery ADB-তে `reboot:edl`। DOWNLOAD: শুধু recovery ADB-তে `reboot:download` (Samsung)। VROOM/BROM: recovery ADB-তে `reboot:brom`; সফটওয়্যার কমান্ড সব ফোনে নেই, তাই অনেক ফোনে হাতে-করা ধাপ লাগবে (DEVICE পেজের গাইড)। ফোন না মানলে লগে স্পষ্ট জানায়।
- পুরনো SYSTEM, BOOTLOADER, RECOVERY, FASTBOOTD দ্রুত বোতাম সরানো হয়েছে; REFRESH ও RECONNECT থাকছে। ROM ট্যাবের REBOOT বোতাম অপরিবর্তিত।
- নিরাপত্তা: `oem edl` অন্য reboot কমান্ডের মতো (লেখা নয়) ধরা হয়; বাকি সব `oem` কমান্ডে আগের destructive গেট বহাল।
- নতুন/বদলানো ফাইল: `ModeWheel.kt`, পাঁচটি সাদা আইকন `w_*.xml`, `MainVM.kt` (`enterMode`, `adbReboot`), `AdbSideload.kt` (`reboot`), `Fastboot.kt`, `Model.kt` (`WheelMode`), `Ui.kt`, `Pages.kt`। কম্পাইল ও হার্ডওয়্যার পরীক্ষা এখানে চালানো যায়নি।


## ১৬. ২০২৬-১১-১৯ পুনঃপর্যালোচনা ও রক্ষণাবেক্ষণ আপডেট

- `Settings.resetAll()`-এ custom background-এর `bgChoice` ও `bgUri`-ও reset করা হয়েছে; Reset করার পর পুরোনো custom wallpaper আর নির্বাচিত অবস্থায় থাকার কথা নয়।
- প্রতিটি brand-specific Flash screen-এর Analyzer-এর নিচে `LIVE OPERATION LOG` panel যোগ করা হয়েছে। এটি `MainVM.logs` থেকে সর্বশেষ ৮টি বাস্তব app event দেখায়; কৃত্রিম progress বা বানানো device response দেখায় না।
- Chipset engine fail-closed থাকার regression test যোগ করা হয়েছে: বর্তমানে নিবন্ধিত Qualcomm EDL, MediaTek BROM, Samsung Download ও Unisoc FDL engine-এর `writeEnabled` false-ই থাকতে হবে এবং mode mapping unique হতে হবে।
- GitHub Actions workflow-তে `testDebugUnitTest`, `lintDebug`, এবং `assembleDebug` চালানোর ধাপ যোগ করা হয়েছে; রিপোর্ট ও APK পাওয়া গেলে artifact হিসেবে আপলোড হবে।
- গুরুত্বপূর্ণ সীমা: brand-specific screen হলো UI profile; এগুলো নিজে থেকে OEM protocol implementation নয়। এই প্রজেক্টে guarded generic Fastboot image-write path ছাড়া EDL/Firehose, MediaTek DA/BROM, Samsung Download বা Unisoc FDL write protocol বাস্তবায়িত নয়।
- এই পরিবেশে Android SDK/Gradle installation নেই, তাই Android compile, unit test, lint বা APK build চালানো যায়নি। XML ও device database JSON-এর syntax parse check করা হয়েছে; ZIP integrity check-ও করা হয়েছে। GitHub Actions বা Android Studio build সফল না হওয়া পর্যন্ত APK/build verified বলা যাবে না।


## UI update — compact USB speed indicator and visibility rules (2026-11-19)
- Added a small, always-visible USB speed chip in the app header beside the connection indicator.
- While an actual transfer is running, it shows the measured payload throughput against the configured minimum threshold (MiB/s). When no real sample exists, it shows only the configured minimum threshold; it does not invent a negotiated USB 2.0/3.0 link rate or a benchmark value.
- The speed chip is an in-app header element, not a floating bubble and does not require SYSTEM_ALERT_WINDOW permission.
- Existing background Flash Progress Bubble is retained only for operation progress and critical warnings when the app is backgrounded.
- Core Device, Flash, Partition, ROM/Root, Safety and Settings tabs are protected from being hidden; only the secondary Log tab may be hidden. Existing lower-priority panels remain collapsible.
- Removed the automatic overlay-permission prompt at app launch. Users can grant it from the existing Floating Bubble settings section when they want background progress overlay.
- Bubble demo no longer displays fabricated MB/s values.
