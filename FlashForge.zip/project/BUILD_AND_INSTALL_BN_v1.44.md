# FlashForge v1.44 — Build ও Install নির্দেশনা

1. ZIP extract করে Android Studio-তে `project/` folder Open করুন।
2. Android SDK Platform 34 এবং JDK 17 উপলভ্য রাখুন। Gradle 8.7 দিয়ে Gradle Sync করুন।
3. Terminal থেকে project folder-এ চালান:

   ```bash
   gradle clean testDebugUnitTest lintDebug assembleDebug --stacktrace
   ```

4. Debug APK তৈরি হলে ফাইলটি পাবেন:

   `app/build/outputs/apk/debug/app-debug.apk`

5. ফোনে APK install করুন। About পেজে এই build পরিচয় দেখা উচিত:

   `1.44 (14) · FLASHFORGE_UIKIT_V2_144`

একই application ID ও compatible signing key থাকলে এটি আগের ইনস্টল করা সংস্করণের update হবে। Android যদি signing-certificate mismatch দেখায়, আগে app data/firmware logs-এর backup নিন; তারপর পুরোনো app uninstall করে নতুন APK install করুন। Uninstall করলে app-এর private local data মুছে যেতে পারে।

এই delivery-তে APK নয়, Android Studio source ZIP দেওয়া হয়েছে। বর্তমান কাজের পরিবেশে Android SDK/Gradle অনুপস্থিত থাকায় APK build ও device install test করা যায়নি।
