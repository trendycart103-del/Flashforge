# FlashForge v1.38 — Horizontal tab sizing refinement (BN)

- Removed the horizontal-scroll sizing behavior from the seven primary page tabs.
- Distributed all seven tabs evenly across the available row width using equal weights, eliminating the unused right-side gap visible in the supplied screenshot.
- Increased tab height to 62dp and icon sizes to 26–28dp; labels slightly enlarged while remaining single-line.
- Preserved tab order, destinations, selected-state styling, and click actions.
- No page action logic or radial-wheel behavior changed.

Validation: source-level patch and ZIP integrity checked. Android Gradle compilation was not run in this environment.
