# FlashForge v1.48 — Mode Guide & UI Update (Bangla)

- Device Page থেকে Model Guard-এর দৃশ্যমান ফর্ম সরানো হয়েছে; বিদ্যমান internal safety identity checks অপরিবর্তিত।
- Device Page-এ FASTBOOT, DOWNLOAD, EDL, BROM এবং UNISOC-এর চালু/বন্ধ অবস্থার নির্দেশনা সবসময় দৃশ্যমান করা হয়েছে।
- Flash Page থেকে Add Image, Flash Queue ও Phone Profile সরিয়ে ROM & ROOT পেজে Add Image/Queue controls রাখা হয়েছে।
- Flash Page-এ Fastboot Flash Options summary যোগ হয়েছে।
- ROM & ROOT radial controls এখন UNLOCK, ROM, ROOT, PARTITIONS; Unlock controls প্রথম tab-এ।
- Good to Know panels expanded/open by default করা হয়েছে।
- Header connection LED-কে তিন-রঙা signal-lamp housing-এ বড় করা হয়েছে; প্রকৃত Link state-ই রঙ নির্ধারণ করে।
- devices.json-এ মডেল প্রোফাইল 73-এ উন্নীত হয়েছে (পূর্ববর্তী ZIP-এ 34টি ছিল); প্রতিটি profile-এর জন্য modeCompatibility metadata যোগ হয়েছে। এগুলো সম্ভাব্যতা/সতর্কতা, verified hardware support নয়।
- Unknown device শনাক্ত হলে সামনে modal alert আসে; মোড বাটনে অনিশ্চিত/অসাপোর্টেড প্রবেশ চাইলে আলাদা mode-entry guide দেখায়।
- ADB থেকে কেবল Fastboot reboot path চেষ্টা করা হয়; standard Android ADB RSA AUTH এই build-এ নেই, তাই AUTH refusal হলে guide overlay দেখায়; generic EDL/Download/BROM reboot command আর নির্বিচারে পাঠানো হয় না।
- মূল কনটেন্ট পেজে আগের vertical scrolling রাখা হয়েছে; সব পেজকে scroll-free করলে বড় ফর্ম/কন্ট্রোল ছোট স্ক্রিনে কেটে যেতে পারে, তাই সেটি আলাদা responsive redesign ছাড়া জোর করে বন্ধ করা হয়নি।
- Android build/compile চালানো হয়নি।


## Database provenance
- Google/Pixel device codenames: Android Open Source Project device codename reference.
- Xiaomi/Redmi/POCO model variants: MobileModels_Fork and DroidWin cross-checks.
- Compatibility strings remain conservative hints, not a guarantee that a mode can be entered or flashed.

- Xiaomi/Redmi/POCO model-codename cross-check: Technastic and ZFirm public catalog.
