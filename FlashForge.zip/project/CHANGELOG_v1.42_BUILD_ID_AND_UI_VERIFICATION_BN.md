# FlashForge v1.42 — Build identity and UI verification

## Root cause addressed
- The v1.41 archive contained source changes but explicitly stated that Android Gradle compilation had not been run. It also did not include a verified APK.
- The installed screenshots show the older seven-sector Flash wheel, while the current `Pages.kt` source defines a four-sector wheel plus three compact selectors. The screenshots therefore do not prove that the installed APK was built from this source tree.
- The app package ID is unchanged, so installing an older or unrelated APK can make it appear that a source update had no effect.

## Changes
- Bumped Android version metadata to versionName `1.42` and versionCode `12`, so Android can distinguish this build from v1.41 and earlier builds.
- Enabled generated `BuildConfig` and added the explicit UI layout marker `RADIAL4_PLUS_3_V142`.
- Added the version, versionCode and UI layout marker to the About page. After installation, open ABOUT and verify `Build 1.42 (12) · RADIAL4_PLUS_3_V142`. If that marker is absent, the installed app is not this build.
- Preserved the v1.41 four-segment Flash wheel, three additional selectors, ROM wheel and all device/USB/ADB/Fastboot/flashing safety logic.

## Build and install verification
- Build from this extracted project root (the folder containing `settings.gradle.kts`): `gradle clean testDebugUnitTest lintDebug assembleDebug --stacktrace`.
- Install only the newly generated `app/build/outputs/apk/debug/app-debug.apk`. Do not install an APK from an older CI artifact or another project folder.
- Verify package `com.flashforge`, versionName `1.42`, versionCode `12`, then open ABOUT and check the UI marker.
- This environment has no Gradle executable, Gradle wrapper, Android SDK, or configured Android SDK path. Compilation and device installation could not be executed here; no successful APK build is claimed.

## Validation status
- Source-level build identity and UI routing inspected.
- ZIP integrity checked after packaging.
- Android Gradle compile, lint, emulator and physical-device tests remain pending in Android Studio or CI.
