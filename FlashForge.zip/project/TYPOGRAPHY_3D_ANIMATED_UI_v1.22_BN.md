# FlashForge v1.22 — 3D Interface Typography Upgrade

- Added a shared typography scale for display, headings, titles, body copy, and labels.
- Standardized the interface on Android Sans Serif with stronger weight hierarchy and improved line spacing.
- Refined section headings and the FlashForge wordmark with restrained depth shadows and steel/cyan-compatible contrast.
- Improved button, navigation, and dashboard tile label sizing and letter spacing.
- Kept user text-scale setting, localization, navigation actions, device operations, and existing workflows intact.
- Updated Android version metadata to versionCode 18 / versionName 1.22.

Validation: source review and ZIP integrity check. Gradle build was not run because a Gradle executable/wrapper and Android SDK are not available in this environment.
