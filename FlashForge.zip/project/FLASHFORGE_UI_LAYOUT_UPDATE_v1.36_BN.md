# FlashForge UI Layout Update v1.36 (বাংলা)

## সংশোধন
- Home-level circular navigation wheel সরিয়ে persistent horizontal tab bar করা হয়েছে।
- DEVICE, FLASH, ROM, LOG, SAFETY, SETTINGS এবং ABOUT এক সারির compact tabs; প্রয়োজন হলে horizontal swipe করে tab row দেখা যাবে।
- Selected tab-এ ধীর cyan-magenta border transition এবং press scale feedback রয়েছে।
- Radial action wheels কেবল সংশ্লিষ্ট page-এর action navigation-এর জন্য থাকবে; top-level page navigation আর wheel নয়।
- Tab icon-এ bundled 3D icon pack resource ব্যবহার করা হয়েছে।

## সীমাবদ্ধতা / যাচাই
- ZIP integrity পরীক্ষা করা হয়েছে।
- এই পরিবেশে Gradle/Android SDK build runner উপলব্ধ নয়; তাই Android compile ও device runtime test নিশ্চিত করা হয়নি।
- সব page-এর পুরোনো operation panels এখনো সম্পূর্ণ radial action-wheel controls-এ পুনর্গঠিত হয়নি। এই update-এ মূলত ভুল top-level wheel-কে tab bar করা হয়েছে।
