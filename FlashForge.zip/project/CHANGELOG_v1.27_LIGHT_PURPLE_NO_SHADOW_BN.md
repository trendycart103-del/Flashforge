# FlashForge v1.27 — 3D Light Purple (No Shadow)

- Removed text shadows and elevation/drop-shadow modifiers from the Compose interface.
- Replaced the dark/cyan gaming palette with a light lavender/purple palette.
- Preserved dimensional appearance using layered gradients, bright bevel borders, outlines, and press animations.
- Updated buttons, navigation tabs, icon tiles, mode wheel, and background to the same light-purple visual language.
- Preserved existing navigation and device/service logic.
- Build status: source changes packaged; Android Gradle build not run in this environment.
