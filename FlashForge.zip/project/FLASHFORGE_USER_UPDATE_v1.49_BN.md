# FlashForge User Instruction Update v1.49 — Bengali

## Applied UI changes
- Device page: removed the front-facing Mode Controls panel from the radial action stage.
- Device page: Mode Entry Guide is expanded and directly visible, no longer collapsed/hidden.
- Device page: Fastboot Flash Options panel now appears only after a USB device is connected and a mode is detected.
- Flash page: Firmware Sites panel is directly displayed rather than gated by the SITES section toggle.
- ROM & ROOT: removed the front-facing ROM & ROOT Tools panel from the radial action stage.
- ROM & ROOT: removed the separate Unlock/ROM/Root/Partitions tab strip; those actions are represented by the circular menu items.
- ROM & ROOT: removed the Add Image & Flash Queue UI panel as requested. Existing MainVM queue and verification/flash logic were not deleted.
- Header: redesigned the connection indicator as a 3D traffic/rail signal lamp, retaining the 40dp header footprint shared with Settings/About and its live MainVM USB status.
- Main page content no longer uses the app-wide verticalScroll wrapper.

## Protection / limitations
- No MainVM, connection-detection, safety-verification, firmware verification, or flashing engine code was intentionally changed.
- The Image Flash Queue interface is removed, but underlying queue/flash code remains in the project.
- Build verification could not be run because this archive does not contain `gradlew` and the environment has no installed Gradle executable.
