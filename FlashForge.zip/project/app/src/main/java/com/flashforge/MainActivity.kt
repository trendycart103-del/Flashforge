package com.flashforge

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbManager
import android.hardware.usb.UsbDevice
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val vm: MainVM by viewModels()

    private fun openRequestedScreen(i: Intent?) {
        if (i?.getStringExtra(EXTRA_SCREEN) == "FLASH") vm.screen = Screen.FLASH
    }

    @Suppress("DEPRECATION")
    private fun usbDeviceExtra(i: Intent): UsbDevice? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
        else i.getParcelableExtra(UsbManager.EXTRA_DEVICE) as? UsbDevice

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                UsbManager.ACTION_USB_DEVICE_DETACHED -> vm.onDetached(usbDeviceExtra(i))
                MainVM.ACTION -> vm.onPermissionResult(
                    usbDeviceExtra(i),
                    i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                )
                else -> vm.scan(true) // a fresh attach is an explicit user action
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val f = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
            addAction(MainVM.ACTION)
        }
        ContextCompat.registerReceiver(this, rx, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        setContent { AppUi(vm) }
        openRequestedScreen(intent)
        // Do not request system-overlay access on launch. It is only needed for the optional
        // background flash-progress overlay and can be granted explicitly in Settings.
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        openRequestedScreen(intent)
    }

    override fun onStart() {
        super.onStart()
        FlashStatus.appFg = true
    }

    override fun onStop() {
        FlashStatus.appFg = false
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        FlashStatus.appFg = true
        vm.refreshPerms()
        vm.scan()
    }

    override fun onDestroy() {
        unregisterReceiver(rx)
        super.onDestroy()
    }

    companion object {
        const val EXTRA_SCREEN = "open_screen"
    }
}
