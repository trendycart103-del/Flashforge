package com.flashforge

import android.net.Uri

enum class Mode(val label: String) {
    NONE("NO DEVICE"),
    FASTBOOT("FASTBOOT"),
    ADB("ADB / RECOVERY"),
    SAMSUNG_DOWNLOAD("SAMSUNG DOWNLOAD"),
    QUALCOMM_EDL("QUALCOMM EDL 9008"),
    MEDIATEK_BROM("MEDIATEK BROM / PRELOADER"),
    UNISOC("UNISOC FDL"),
    UNKNOWN("UNKNOWN")
}

/** Targets of the mode wheel (EDL, BROM, DOWNLOAD, FASTBOOT) and of its restart menu (SYSTEM, RECOVERY). */
enum class WheelMode { EDL, BROM, DOWNLOAD, FASTBOOT, SYSTEM, RECOVERY }

enum class Link(val label: String) {
    RED("NOT CONNECTED"),
    YELLOW("CONNECTING / UNSTABLE"),
    GREEN("CONNECTED")
}

enum class Screen(val title: String, val icon: Int) {
    DEVICE("DEVICE", R.drawable.ff_phone),
    FLASH("FLASH", R.drawable.ff_chip_flash),
    ROM("ROM & Root", R.drawable.ff_android_layers),
    LOG("LOG", R.drawable.ff_terminal),
    SAFETY("SAFETY", R.drawable.ff_shield),
    SETTINGS("SETTINGS", R.drawable.ff_gear),
    ABOUT("ABOUT", R.drawable.ff_profile)
}

data class QItem(val part: String, val uri: Uri, val name: String, val size: Long, val enabled: Boolean = true)
