package com.flashforge

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.layout.layout
import kotlin.math.roundToInt
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Soft light palette: navy text, orange section accents, pastel background. */
object C {
    val bg: Color get() = AppSettings.color("bg")
    val panel: Color get() = AppSettings.color("panel")
    val line: Color get() = AppSettings.color("text")
    val ink: Color get() = AppSettings.color("text")
    val blue: Color get() = AppSettings.color("blue")
    val orange: Color get() = AppSettings.color("orange")
    val amber: Color get() = AppSettings.color("amber")
    val green: Color get() = AppSettings.color("green")
    val red: Color get() = AppSettings.color("red")
    val yellow: Color get() = AppSettings.color("yellow")
    val yellowDark = Color(0xFF8A5A00)
    val text: Color get() = AppSettings.color("text")
    val dim: Color get() = AppSettings.color("dim")
    val off = Color(0xFFD9DEEA)
}

val Sans = FontFamily.Default

/** Lamp colour and readable text colour for each connection state. */
val Link.tint: Color get() = when (this) {
    Link.RED -> C.red
    Link.YELLOW -> C.yellow
    Link.GREEN -> C.green
}
val Link.ink: Color get() = when (this) {
    Link.RED -> C.red
    Link.YELLOW -> C.yellowDark
    Link.GREEN -> C.green
}
val Link.pill: String get() = when (this) {
    Link.RED -> "NOT CONNECTED"
    Link.YELLOW -> "Connecting"
    Link.GREEN -> "Connected"
}

// ---------------- shapes ----------------

val CardShape = RoundedCornerShape(32.dp)
val PanelShape = RoundedCornerShape(28.dp)
val FieldShape = RoundedCornerShape(18.dp)
val TabShape = RoundedCornerShape(50)
val NavShape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)

/** Pill button: fully rounded ends (same shape as the SYSTEM reboot button). */
val BtnShape = RoundedCornerShape(50)

// ---------------- background ----------------

fun Modifier.blueprint(): Modifier = this.background(C.bg)

// ---------------- text helpers ----------------

private val Acronyms = setOf("ROM", "ZIP", "ADB", "USB", "OEM", "SHA", "EDL", "OTG", "GSI", "FRP", "IMG", "AB", "AP", "BL", "CP", "CSC")

/** "REBOOT TO RECOVERY" -> "Reboot to recovery"; acronyms and one-letter words stay as they are. */
fun nice(t: String): String {
    val out = t.split(" ").joinToString(" ") { w ->
        val core = w.filter { it.isLetter() }
        if (core.length > 1 && core.all { it.isUpperCase() } && core !in Acronyms) w.lowercase() else w
    }
    return out.replaceFirstChar { it.uppercase() }
}

@Composable
fun T(s: String, c: Color = C.text, sz: Int = 12, bold: Boolean = false, mod: Modifier = Modifier) {
    Text(
        localized(s), color = c, fontFamily = Sans, fontSize = (sz + 2).sp, lineHeight = ((sz + 2) * 1.35f).sp,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium, modifier = mod
    )
}

private val GoodValues = setOf("yes", "unlocked", "granted", "allowed", "on")

@Composable
fun KV(k: String, v: String) {
    val vc = if (v.trim().lowercase() in GoodValues) C.green else C.text
    Row(
        Modifier.fillMaxWidth()
            .drawBehind { drawLine(C.ink.copy(alpha = 0.08f), Offset(0f, size.height), Offset(size.width, size.height), 1.dp.toPx()) }
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(k, color = C.dim, fontFamily = Sans, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(0.5f))
        Text(
            v, color = vc, fontFamily = Sans, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.End, modifier = Modifier.weight(0.5f)
        )
    }
}

/** Rounded white card with an orange dot title. The outline turns blue on touch or focus. */
@Composable
fun Panel(title: String, startOpen: Boolean = true, icon: Int = 0, accent: Color = C.orange, dense: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    var open by remember { mutableStateOf(startOpen) }
    val frac by animateFloatAsState(if (open) 1f else 0f, tween(260), label = "panelOpen")
    var focused by remember { mutableStateOf(false) }
    var pressed by remember { mutableStateOf(false) }
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val active = focused || pressed
    val appear by animateFloatAsState(if (shown) 1f else 0f, tween(450), label = "appear")
    val bw by animateDpAsState(if (active) 2.dp else 1.dp, tween(200), label = "bw")
    val bc by animateColorAsState(if (active) C.blue else C.ink.copy(alpha = 0.06f), tween(250), label = "bc")
    val glow by animateFloatAsState(if (active) 0.08f else 0f, tween(300), label = "glow")
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = if (dense) 4.dp else 7.dp)
            .graphicsLayer { alpha = appear; translationY = (1f - appear) * 48f }
            .background(C.panel.copy(alpha = 0.98f), PanelShape)
            .background(C.blue.copy(alpha = glow), PanelShape)
            .border(bw, bc, PanelShape)
            .onFocusChanged { focused = it.hasFocus }
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val e = awaitPointerEvent(PointerEventPass.Initial)
                        pressed = e.changes.any { it.pressed }
                    }
                }
            }
            .padding(horizontal = if (dense) 14.dp else 20.dp, vertical = if (dense) 8.dp else 14.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().clip(FieldShape).clickable { open = !open }.padding(vertical = if (dense) 2.dp else 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (icon != 0) IconTile(icon, accent, if (dense) 38.dp else 46.dp) else Box(Modifier.size(13.dp).background(C.orange, CircleShape))
            Spacer(Modifier.width(if (icon != 0) 12.dp else 10.dp))
            Text(
                title, color = C.amber, fontFamily = Sans, fontSize = if (dense) 14.sp else 15.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.weight(1f)
            )
            Text(if (open) "\u2212" else "+", color = C.amber, fontFamily = Sans, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        // The content stays composed while folded (so typed text and state are kept); it is only measured to zero height.
        Column(
            Modifier.clipToBounds().layout { m, c ->
                val p = m.measure(c)
                val h = (p.height * frac).roundToInt()
                layout(p.width, h) { p.placeRelative(0, 0) }
            }
        ) {
            Spacer(Modifier.height(if (dense) 6.dp else 10.dp))
            content()
        }
    }
}

/** Prominent icon: the picture sits on a tinted, outlined rounded square so it is easy to spot. */
@Composable
fun IconTile(icon: Int, accent: Color, box: androidx.compose.ui.unit.Dp = 46.dp) {
    val sh = RoundedCornerShape(14.dp)
    Box(
        Modifier.size(box).background(accent.copy(alpha = 0.12f), sh).border(2.dp, accent, sh),
        contentAlignment = Alignment.Center
    ) { Image(painterResource(icon), null, Modifier.size(box - 14.dp)) }
}

/** One numbered row of a step table. */
class TableStep(val no: Int, val icon: Int, val title: String, val what: String)

/** A table block: a coloured group band followed by numbered rows (number | icon | title and purpose). */
@Composable
fun StepGroup(name: String, groupIcon: Int, accent: Color, rows: List<TableStep>) {
    Row(
        Modifier.fillMaxWidth().padding(top = 10.dp).background(accent.copy(alpha = 0.14f), FieldShape)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(painterResource(groupIcon), null, Modifier.size(34.dp))
        Spacer(Modifier.width(10.dp))
        Text(name, color = C.text, fontFamily = Sans, fontSize = 15.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
    }
    rows.forEach { r ->
        Row(
            Modifier.fillMaxWidth()
                .drawBehind { drawLine(C.ink.copy(alpha = 0.08f), Offset(0f, size.height), Offset(size.width, size.height), 1.dp.toPx()) }
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "${r.no}", color = accent, fontFamily = Sans, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, modifier = Modifier.width(34.dp)
            )
            IconTile(r.icon, accent, 44.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(r.title, color = C.text, fontFamily = Sans, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(r.what, color = C.dim, fontFamily = Sans, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
fun Rw(content: @Composable RowScope.() -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), content = content)
}

/** PC-software style tab strip: icon + label, the chosen tab is filled with its colour. */
@Composable
fun SegTabs(labels: List<String>, icons: List<Int>, accents: List<Color>, sel: Int, onSel: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp)
            .background(C.panel.copy(alpha = 0.98f), FieldShape)
            .border(1.dp, C.ink.copy(alpha = 0.08f), FieldShape).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        labels.forEachIndexed { i, l ->
            val on = i == sel
            val a = accents[i]
            Row(
                Modifier.weight(1f).heightIn(min = 44.dp).clip(RoundedCornerShape(14.dp))
                    .background(if (on) a else a.copy(alpha = 0.08f))
                    .clickable { onSel(i) }.padding(horizontal = 6.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Box(
                    Modifier.size(26.dp).background(Color.White.copy(alpha = 0.92f), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) { Image(painterResource(icons[i]), null, Modifier.size(20.dp)) }
                Spacer(Modifier.width(6.dp))
                Text(
                    l, color = if (on) Color.White else C.text, fontFamily = Sans, fontSize = 13.sp,
                    fontWeight = FontWeight.Bold, maxLines = 1
                )
            }
        }
    }
}

/** Small status cells, two per row: label on top, value below. */
@Composable
fun StatusStrip(items: List<Pair<String, String>>) {
    items.chunked(2).forEach { pair ->
        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            pair.forEach { (k, v) ->
                val vc = if (v.trim().lowercase() in GoodValues) C.green else C.text
                Column(
                    Modifier.weight(1f)
                        .background(C.panel.copy(alpha = 0.98f), FieldShape)
                        .border(1.dp, C.ink.copy(alpha = 0.06f), FieldShape)
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(k, color = C.dim, fontFamily = Sans, fontSize = 11.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                    Text(v, color = vc, fontFamily = Sans, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
            if (pair.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

/** Compact two-column reference table: short label | explanation. */
@Composable
fun NoteTable(rows: List<Pair<String, String>>, accent: Color = C.amber) {
    Column(Modifier.fillMaxWidth().border(1.dp, C.ink.copy(alpha = 0.10f), FieldShape).clip(FieldShape)) {
        rows.forEachIndexed { i, (k, v) ->
            Row(
                Modifier.fillMaxWidth()
                    .background(if (i % 2 == 0) accent.copy(alpha = 0.07f) else Color.Transparent)
                    .padding(horizontal = 10.dp, vertical = 7.dp),
                verticalAlignment = Alignment.Top
            ) {
                Text(k, color = C.text, fontFamily = Sans, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.32f))
                Text(v, color = C.dim, fontFamily = Sans, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(0.68f))
            }
        }
    }
}

/** Picks the graphical icon that is drawn inside a button, from the button label. */
fun iconFor(t: String): Int {
    val u = t.uppercase()
    return when {
        u.startsWith("REFRESH") || u.startsWith("READ TABLE") -> R.drawable.b_refresh
        u.startsWith("SLOT") -> R.drawable.b_slot
        u.startsWith("REBOOT TO RECOVERY") || u == "RECOVERY" -> R.drawable.b_recovery
        u == "SYSTEM" || u.startsWith("REBOOT SYSTEM") -> R.drawable.b_power
        u == "BOOTLOADER" -> R.drawable.b_boot
        u == "FASTBOOTD" -> R.drawable.b_term
        u.startsWith("ADD IMAGE") -> R.drawable.b_image
        u.startsWith("UNPACK") -> R.drawable.b_zip
        u.startsWith("FLASH") -> R.drawable.b_bolt
        u.startsWith("SAVE") -> R.drawable.b_save
        u.startsWith("DOWNLOAD") || u.startsWith("UPDATE") -> R.drawable.b_download
        u.startsWith("ERASE") || u.startsWith("DELETE") || u.startsWith("WIPE") -> R.drawable.b_trash
        u.startsWith("BACKUP") -> R.drawable.b_backup
        u.startsWith("CREATE") -> R.drawable.b_plus
        u.startsWith("RESIZE") -> R.drawable.b_resize
        u.startsWith("UNLOCK") -> R.drawable.b_unlock
        u.startsWith("LOCK") -> R.drawable.b_lock
        u.startsWith("CHOOSE") -> R.drawable.b_folder
        u.startsWith("SIDELOAD") -> R.drawable.b_upload
        u.startsWith("EXPORT") -> R.drawable.b_export
        u.startsWith("CLEAR") -> R.drawable.b_clear
        u.startsWith("GRANT") || u.startsWith("BUBBLE") || u.startsWith("TEST") -> R.drawable.b_bubble
        u.startsWith("ALLOW") -> R.drawable.b_bell
        else -> 0
    }
}

/** Small rounded-square icon button (used in the flash queue). */
@Composable
fun IconBtn(res: Int, on: () -> Unit) {
    val sh = BtnShape
    Box(
        Modifier
            .padding(horizontal = 3.dp)
            .size(38.dp)
            .clip(sh)
            .background(C.panel)
            .border(1.dp, C.ink.copy(alpha = 0.12f), sh)
            .clickable(onClick = on),
        contentAlignment = Alignment.Center
    ) { Image(painterResource(res), null, Modifier.size(22.dp)) }
}

/** Gradient pairs (start, end) in the style of the reference screenshot. */
private val BtnGradients = listOf(
    Color(0xFFFF5252) to Color(0xFFFFB300),  // coral to amber
    Color(0xFF00B0FF) to Color(0xFF5B5BFF),  // sky to indigo
    Color(0xFF00C98D) to Color(0xFF0E9AA7),  // green to teal
    Color(0xFF8E5BFF) to Color(0xFFE040C8),  // violet to magenta
    Color(0xFF1E88E5) to Color(0xFF26A69A),  // blue to teal
    Color(0xFFFF7043) to Color(0xFFEC407A)   // orange to pink
)
private val DangerGradient = Color(0xFFFF3D57) to Color(0xFFFF8A3D)

private fun gradFor(t: String, danger: Boolean): Pair<Color, Color> {
    if (danger) return DangerGradient
    val u = t.uppercase()
    return when {
        u.startsWith("FLASH") -> BtnGradients[0]
        u.startsWith("REFRESH") || u.startsWith("READ") -> BtnGradients[1]
        u.startsWith("UNLOCK") || u.startsWith("LOCK") -> BtnGradients[2]
        u.startsWith("BACKUP") || u.startsWith("SAVE") -> BtnGradients[3]
        u.startsWith("DOWNLOAD") || u.startsWith("UPDATE") -> BtnGradients[4]
        else -> BtnGradients[(t.hashCode() and 0x7fffffff) % BtnGradients.size]
    }
}

@Composable
fun Btn(t: String, enabled: Boolean = true, danger: Boolean = false, mod: Modifier = Modifier, icon: Int = iconFor(t), compact: Boolean = false, on: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pr by src.collectIsPressedAsState()
    val sc by animateFloatAsState(
        if (pr) 0.94f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "btnScale"
    )
    val (g1, g2) = gradFor(t, danger)
    val brush = if (enabled) Brush.linearGradient(listOf(g1, g2)) else Brush.linearGradient(listOf(C.off, C.off))
    Button(
        onClick = on, enabled = enabled,
        modifier = mod
            .padding(vertical = 4.dp)
            .fillMaxWidth()
            .heightIn(min = if (compact) 44.dp else 56.dp)
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .background(brush, BtnShape),
        shape = BtnShape,
        interactionSource = src,
        elevation = null,
        contentPadding = PaddingValues(horizontal = if (compact) 10.dp else 20.dp, vertical = if (compact) 4.dp else 8.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent, contentColor = Color.White,
            disabledContainerColor = Color.Transparent, disabledContentColor = C.dim
        )
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            if (icon != 0) {
                Box(
                    Modifier.size(if (compact) 26.dp else 32.dp).background(Color.White.copy(alpha = 0.92f), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(painterResource(icon), null, Modifier.size(if (compact) 18.dp else 22.dp), alpha = if (enabled) 1f else 0.45f)
                }
                Spacer(Modifier.width(7.dp))
            }
            Text(
                nice(t), fontFamily = Sans, fontSize = if (compact) 13.sp else 15.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 2, textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun ConfirmBtn(t: String, msg: String, enabled: Boolean = true, danger: Boolean = true, mod: Modifier = Modifier, compact: Boolean = false, go: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Btn(t, enabled, danger, mod, compact = compact) { open = true }
    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            confirmButton = { TextButton(onClick = { open = false; go() }) { Text("CONFIRM", color = C.red, fontFamily = Sans, fontWeight = FontWeight.Bold) } },
            dismissButton = { TextButton(onClick = { open = false }) { Text("CANCEL", color = C.dim, fontFamily = Sans, fontWeight = FontWeight.SemiBold) } },
            title = { Text(nice(t), fontFamily = Sans, fontWeight = FontWeight.Bold) },
            text = { Text(msg, fontFamily = Sans, fontSize = 15.sp, fontWeight = FontWeight.Medium) },
            shape = PanelShape,
            containerColor = C.panel, titleContentColor = C.amber, textContentColor = C.text
        )
    }
}

@Composable
fun Field(v: String, onv: (String) -> Unit, label: String) {
    OutlinedTextField(
        value = v, onValueChange = onv, singleLine = true, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        shape = FieldShape,
        label = { Text(label, fontFamily = Sans, fontSize = 13.sp, fontWeight = FontWeight.Medium) },
        textStyle = TextStyle(fontFamily = Sans, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = C.text),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = C.text, unfocusedTextColor = C.text,
            focusedContainerColor = C.panel.copy(alpha = 0.85f),
            unfocusedContainerColor = C.panel.copy(alpha = 0.55f),
            focusedBorderColor = C.blue, unfocusedBorderColor = C.ink.copy(alpha = 0.22f),
            focusedLabelColor = C.blue, unfocusedLabelColor = C.dim, cursorColor = C.blue
        )
    )
}

@Composable
fun PickBtn(label: String, mod: Modifier = Modifier, compact: Boolean = false, on: (Uri) -> Unit) {
    val l = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) on(u) }
    Btn(label, mod = mod, compact = compact) { l.launch(arrayOf("*/*")) }
}

// ---------------- header card ----------------

/** Approved FlashForge two-phone OTG/flashing artwork used as the in-app logo. */
@Composable
fun AppLogo(size: androidx.compose.ui.unit.Dp = 56.dp) {
    Image(
        painter = painterResource(R.drawable.flashforge_logo),
        contentDescription = "FlashForge app logo",
        modifier = Modifier.size(size).clip(FieldShape),
        contentScale = androidx.compose.ui.layout.ContentScale.Fit
    )
}

/** Two solid, sharp-toothed pinions with small central bores, continuously meshing in opposite directions. */
@Composable
fun AnimatedGearMark(size: androidx.compose.ui.unit.Dp = 56.dp) {
    val motion = rememberInfiniteTransition(label = "headerPinions")
    val largeRotation by motion.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(4500, easing = LinearEasing)), label = "largePinion"
    )
    val smallRotation by motion.animateFloat(
        initialValue = 360f, targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing)), label = "smallPinion"
    )

    Canvas(Modifier.size(size).semantics { contentDescription = "Two continuously rotating interlocking pinion gears" }) {
        val unit = this.size.minDimension
        val largeRadius = unit * 0.335f
        val smallRadius = unit * 0.285f
        // Centers are deliberately closer so the pointed teeth visibly engage.
        val largeCenter = Offset(this.size.width * 0.365f, this.size.height * 0.365f)
        val smallCenter = Offset(this.size.width * 0.685f, this.size.height * 0.685f)

        fun pinionPath(center: Offset, radius: Float, teeth: Int): Path {
            val path = Path()
            // Each tooth has a narrow, pointed crest and a deep root like a machined pinion.
            val pointsPerTooth = 6
            val count = teeth * pointsPerTooth
            for (i in 0 until count) {
                val toothPhase = i % pointsPerTooth
                val radial = when (toothPhase) {
                    0, 5 -> 0.765f
                    1, 4 -> 0.805f
                    2, 3 -> 1.0f
                    else -> 0.765f
                }
                val angle = (i.toFloat() / count * (2.0 * Math.PI) - Math.PI / 2.0).toFloat()
                val x = center.x + kotlin.math.cos(angle) * radius * radial
                val y = center.y + kotlin.math.sin(angle) * radius * radial
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            return path
        }

        // Large blue pinion: solid metal face, not a hollow ring.
        rotate(largeRotation, largeCenter) {
            drawPath(pinionPath(largeCenter, largeRadius, 10), Color(0xFF2478D0))
            drawCircle(Color(0xFF3E91E8), largeRadius * 0.70f, largeCenter)
            drawCircle(Color(0xFF172A45), largeRadius * 0.105f, largeCenter)
        }

        // Smaller orange pinion rotates in the opposite direction.
        rotate(smallRotation, smallCenter) {
            drawPath(pinionPath(smallCenter, smallRadius, 9), Color(0xFFFF982E))
            drawCircle(Color(0xFFFFB65F), smallRadius * 0.70f, smallCenter)
            drawCircle(Color(0xFF172A45), smallRadius * 0.105f, smallCenter)
        }
    }
}

/** Two-tone wordmark: "Flash" in text colour, "Forge" in the logo orange. */
@Composable
fun AppWordmark(fontSize: androidx.compose.ui.unit.TextUnit = 22.sp) {
    Text(
        buildAnnotatedString {
            withStyle(SpanStyle(color = C.text)) { append("Flash") }
            withStyle(SpanStyle(color = Color(0xFFE4501A))) { append("Forge") }
        },
        fontFamily = Sans, fontSize = fontSize, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false
    )
}

/** Plain corner status: no capsule/card; the lamp colour follows the real USB link state. */
@Composable
fun LinkPill(vm: MainVM) {
    val l = vm.link
    val inf = rememberInfiniteTransition(label = "link")
    val blink by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(650, easing = LinearEasing), RepeatMode.Reverse), label = "blink")
    val main by animateColorAsState(l.tint, tween(300), label = "linkColor")
    val dotAlpha = if (l == Link.YELLOW && blink < 0.5f) 0.2f else 1f
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).background(main.copy(alpha = dotAlpha), CircleShape))
        Spacer(Modifier.width(5.dp))
        Text(l.pill, color = l.ink, fontFamily = Sans, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

/** Shows measured transfer throughput only. No transfer means 0.0; never fabricate/randomise a speed. */
@Composable
fun UsbSpeedIndicator(vm: MainVM) {
    val value = if (vm.busy) vm.transferSpeed.coerceAtLeast(0.0) else 0.0
    val label = String.format(java.util.Locale.US, "SPEED LIMIT  %.1f MiB/s", value)
    val speedColor = when {
        !vm.busy || value <= 0.0 -> C.dim
        value < AppSettings.slowMbs -> C.red
        else -> C.green
    }
    Text(label, color = speedColor, fontFamily = Sans, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false)
}

@Composable
fun Header(vm: MainVM) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AnimatedGearMark()
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                AppWordmark()
                if (vm.mode != Mode.NONE) {
                    Text(vm.vendor + " | " + vm.usbId, color = C.dim, fontFamily = Sans, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                }
            }
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                LinkPill(vm)
                UsbSpeedIndicator(vm)
            }
        }
        if (vm.mode != Mode.NONE) {
            val status = buildList {
                add(vm.mode.label)
                vm.product.takeIf { it.isNotBlank() }?.let { add(it) }
                if (vm.slot != "?") add("slot " + vm.slot)
                if (vm.unlocked != "?") add("unlocked " + vm.unlocked)
            }.joinToString("  ·  ")
            Text(status, color = C.text, fontFamily = Sans, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(vm.linkNote + "  " + vm.linkPct.toString() + "%", color = C.dim, fontFamily = Sans, fontSize = 11.sp, fontWeight = FontWeight.Medium, maxLines = 1)
        }
    }
}


// ---------------- always-visible quick actions ----------------

/** Look of one quick action. Each action gets its own style so they are easy to tell apart, all in the app's palette. */
enum class TileStyle { HERO, OUTLINE, SOLID, DARK, SOFT, SPLIT }

@Composable
fun ActionTile(
    label: String, icon: Int, accent: Color, style: TileStyle, enabled: Boolean,
    mod: Modifier = Modifier, big: Boolean = false, on: () -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val pr by src.collectIsPressedAsState()
    val sc by animateFloatAsState(
        if (pr) 0.93f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "tileScale"
    )
    val sh = BtnShape
    val off = !enabled
    val fill: Brush = when {
        off -> Brush.linearGradient(listOf(C.off, C.off))
        style == TileStyle.HERO -> Brush.linearGradient(listOf(accent, Color(0xFF5B5BFF)))
        style == TileStyle.SOLID -> Brush.linearGradient(listOf(accent, accent))
        style == TileStyle.DARK -> Brush.linearGradient(listOf(C.ink, C.ink.copy(alpha = 0.82f)))
        style == TileStyle.SOFT -> Brush.linearGradient(listOf(accent.copy(alpha = 0.16f), accent.copy(alpha = 0.16f)))
        style == TileStyle.SPLIT -> Brush.verticalGradient(listOf(accent.copy(alpha = 0.22f), C.panel))
        else -> Brush.linearGradient(listOf(C.panel, C.panel))
    }
    val solidLike = !off && (style == TileStyle.HERO || style == TileStyle.SOLID || style == TileStyle.DARK)
    val ink = when {
        off -> C.dim
        solidLike -> Color.White
        else -> accent
    }
    val border = when {
        off -> null
        style == TileStyle.OUTLINE -> BorderStroke(1.5.dp, accent)
        style == TileStyle.SPLIT -> BorderStroke(1.dp, accent.copy(alpha = 0.5f))
        else -> null
    }
    val base = mod.graphicsLayer { scaleX = sc; scaleY = sc }
        .heightIn(min = if (big) 54.dp else 42.dp)
        .clip(sh).background(fill, sh)
        .let { if (border != null) it.border(border, sh) else it }
        .clickable(enabled = enabled, interactionSource = src, indication = null, onClick = on)
    if (big) {
        Row(base.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Box(Modifier.size(34.dp).background(Color.White.copy(alpha = if (off) 0.5f else 0.92f), RoundedCornerShape(50)), contentAlignment = Alignment.Center) {
                Image(painterResource(icon), null, Modifier.size(24.dp), alpha = if (off) 0.45f else 1f)
            }
            Spacer(Modifier.width(8.dp))
            Text(label, color = ink, fontFamily = Sans, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    } else {
        Column(base.padding(vertical = 4.dp, horizontal = 2.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Box(
                Modifier.size(28.dp).background(Color.White.copy(alpha = if (off) 0.5f else 0.95f), RoundedCornerShape(50)),
                contentAlignment = Alignment.Center
            ) { Image(painterResource(icon), null, Modifier.size(20.dp), alpha = if (off) 0.45f else 1f) }
            Spacer(Modifier.height(2.dp))
            Text(label, color = ink, fontFamily = Sans, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun QuickRow(content: @Composable RowScope.() -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        content()
    }
}

// ---------------- premium bottom navigation ----------------

private val NavItemWidth = 86.dp

private fun navAccent(s: Screen): Color = when (s) {
    Screen.DEVICE -> Color(0xFF168CBE)
    Screen.FLASH -> Color(0xFFFF8A24)
    Screen.ROM -> Color(0xFF7357D9)
    Screen.LOG -> Color(0xFF299B83)
    Screen.SAFETY -> Color(0xFFDB526A)
    Screen.SETTINGS -> Color(0xFF4777D5)
    Screen.ABOUT -> Color(0xFFB17A2E)
}

@Composable
fun TabItem(s: Screen, sel: Boolean, modifier: Modifier = Modifier.width(NavItemWidth), onClick: () -> Unit) {
    val accent = navAccent(s)
    val sc by animateFloatAsState(
        if (sel) 1.10f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "tabScale"
    )
    val tint by animateColorAsState(if (sel) accent else C.dim, tween(220), label = "tabTint")
    val tileAlpha by animateFloatAsState(if (sel) 1f else 0f, tween(220), label = "tabTile")
    Column(
        modifier.padding(horizontal = 3.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(42.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier.size(38.dp).graphicsLayer { alpha = tileAlpha }
                    .background(Brush.linearGradient(listOf(accent.copy(alpha = 0.22f), accent.copy(alpha = 0.08f))), CircleShape)
                    .border(1.dp, accent.copy(alpha = 0.25f), CircleShape)
            )
            Image(
                painterResource(s.icon), null,
                Modifier.size(if (sel) 27.dp else 25.dp).graphicsLayer { scaleX = sc; scaleY = sc; alpha = if (sel) 1f else 0.78f }
            )
        }
        Spacer(Modifier.height(2.dp))
        Text(
            localized(nice(s.title)), color = tint, fontFamily = Sans, fontSize = 10.sp, lineHeight = 12.sp,
            fontWeight = if (sel) FontWeight.ExtraBold else FontWeight.SemiBold, maxLines = 1, softWrap = false,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().wrapContentWidth(Alignment.CenterHorizontally)
        )
        Spacer(Modifier.height(3.dp))
        Box(Modifier.width(if (sel) 17.dp else 5.dp).height(3.dp)
            .clip(CircleShape).background(if (sel) accent else C.dim.copy(alpha = 0.18f)))
    }
}

@Composable
fun TabBar(vm: MainVM) {
    val sv = rememberScrollState()
    val density = LocalDensity.current
    val screenW = LocalConfiguration.current.screenWidthDp
    val tabs = Screen.values().filter { AppSettings.tabVisible(it) }
    val fits = tabs.size * NavItemWidth.value + 12f <= screenW
    LaunchedEffect(vm.screen, tabs.size) {
        val itemPx = with(density) { NavItemWidth.toPx() }
        val viewPx = with(density) { screenW.dp.toPx() }
        val target = (tabs.indexOf(vm.screen).coerceAtLeast(0) * itemPx - (viewPx - itemPx) / 2f).toInt().coerceAtLeast(0)
        sv.animateScrollTo(target)
    }
    Row(
        Modifier.fillMaxWidth().shadow(14.dp, NavShape)
            .background(Brush.verticalGradient(listOf(C.panel.copy(alpha = 0.99f), C.panel.copy(alpha = 0.94f))), NavShape)
            .border(1.dp, C.blue.copy(alpha = 0.10f), NavShape)
            .horizontalScroll(sv).padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        tabs.forEach { s ->
            TabItem(s, vm.screen == s, Modifier.width(if (fits) ((screenW - 12f) / tabs.size).dp else NavItemWidth)) { vm.screen = s }
        }
    }
}

/** Compact footer keeps the latest status text; progress is shown only in the active task page and floating bubble. */
@Composable
fun Footer(vm: MainVM) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 6.dp)) {
        T(vm.logs.lastOrNull() ?: "Ready", C.dim, 11, true)
    }
}

@Composable
fun AppUi(vm: MainVM) {
    val d = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(d.density, d.fontScale * AppSettings.textScale)) {
        AppUiBody(vm)
    }
}

@Composable
private fun AppUiBody(vm: MainVM) {
    MaterialTheme(
        colorScheme = lightColorScheme(primary = C.blue, background = C.bg, surface = C.panel, onSurface = C.text, onBackground = C.text)
    ) {
        Box(Modifier.fillMaxSize().background(C.bg)) {
        AppBackground()
        Column(Modifier.fillMaxSize()) {
            Header(vm)
            Box(Modifier.weight(1f).fillMaxWidth()) {
                AnimatedContent(
                    targetState = vm.screen,
                    transitionSpec = {
                        val forward = targetState.ordinal >= initialState.ordinal
                        val enterOffset: (Int) -> Int = { width -> if (forward) width / 5 else -width / 5 }
                        val exitOffset: (Int) -> Int = { width -> if (forward) -width / 7 else width / 7 }
                        (fadeIn(tween(300)) + slideInHorizontally(tween(360), enterOffset) + scaleIn(initialScale = 0.965f, animationSpec = spring(dampingRatio = 0.82f, stiffness = 420f))) togetherWith
                            (fadeOut(tween(170)) + slideOutHorizontally(tween(260), exitOffset) + scaleOut(targetScale = 0.985f, animationSpec = tween(220)))
                    },
                    label = "screen"
                ) { s ->
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp)) {
                        when (s) {
                            Screen.DEVICE -> DevicePage(vm)
                            Screen.FLASH -> FlashPage(vm)
                            Screen.ROM -> RomRootPage(vm)
                            Screen.LOG -> LogPage(vm)
                            Screen.SAFETY -> SafetyPage(vm)
                            Screen.SETTINGS -> SettingsPage(vm)
                            Screen.ABOUT -> AboutPage()
                        }
                    }
                }
            }
            Footer(vm)
            TabBar(vm)
        }
        }
        if (vm.flashScreenOpen) FlashingScreen(vm)
        vm.cableWarn?.let { why ->
            AlertDialog(
                onDismissRequest = { },
                icon = { Image(painterResource(R.drawable.ic_cable), null, Modifier.size(52.dp)) },
                title = { Text("CHANGE THE DATA CABLE", fontFamily = Sans, fontWeight = FontWeight.Bold, fontSize = 17.sp) },
                text = {
                    Column {
                        Text(why, fontFamily = Sans, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Use a short, good quality DATA cable (not a charge-only cable) and plug it straight into the phone or a good OTG adapter, without a hub. The task keeps running; if it fails, swap the cable and run it again.",
                            fontFamily = Sans, fontSize = 13.sp, fontWeight = FontWeight.Medium
                        )
                    }
                },
                confirmButton = { TextButton(onClick = { vm.cableChange() }) { Text("I WILL CHANGE IT", color = C.blue, fontFamily = Sans, fontWeight = FontWeight.Bold) } },
                dismissButton = { TextButton(onClick = { vm.cableContinue() }) { Text("CONTINUE ANYWAY", color = C.dim, fontFamily = Sans, fontWeight = FontWeight.SemiBold) } },
                shape = PanelShape,
                containerColor = C.panel, titleContentColor = C.red, textContentColor = C.text
            )
        }
    }
}
