package com.flashforge

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.sqrt

/** The five touch zones of the wheel. */
private enum class Zone(val top: Color, val bottom: Color, val start: Float) {
    EDL(Color(0xFF3DDC1F), Color(0xFF12A100), 180f),
    BROM(Color(0xFFFFC21A), Color(0xFFFF6A00), 270f),
    FASTBOOT(Color(0xFFFF4A3D), Color(0xFFC40000), 0f),
    DOWNLOAD(Color(0xFFB04BFF), Color(0xFF6A0DD6), 90f),
    RESTART(Color(0xFF2F7BFF), Color(0xFF0A3FD0), 0f)
}

private const val INNER = 0.42f

private fun zoneAt(o: Offset, w: Float): Zone? {
    val c = w / 2f
    val dx = o.x - c
    val dy = o.y - c
    val r = sqrt(dx * dx + dy * dy)
    if (r > c) return null
    if (r < c * INNER) return Zone.RESTART
    return if (dy < 0) (if (dx < 0) Zone.EDL else Zone.BROM) else (if (dx < 0) Zone.DOWNLOAD else Zone.FASTBOOT)
}

private val LabelShadow = Shadow(Color(0x66000000), Offset(0f, 2f), 4f)

/**
 * Four coloured quarters (EDL, BROM, DOWNLOAD, FASTBOOT) around a RESTART button.
 * Every zone sends a real command; nothing here is decoration.
 */
@Composable
fun ModeWheel(vm: MainVM, diameter: Dp = 300.dp) {
    val ready = (vm.mode == Mode.FASTBOOT || vm.mode == Mode.ADB) && !vm.busy
    var pressed by remember { mutableStateOf<Zone?>(null) }
    var confirm by remember { mutableStateOf<Zone?>(null) }
    var menu by remember { mutableStateOf(false) }

    val d = diameter.value
    val labelSp = (d * 0.05f).sp
    val iconDp = (d * 0.115f).dp
    val ox = (d * 0.247f).dp
    val oy = (d * 0.24f).dp

    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(diameter).alpha(if (ready) 1f else 0.5f)
                .pointerInput(ready) {
                    val wPx = this.size.width.toFloat()
                    detectTapGestures(
                        onPress = { o ->
                            pressed = zoneAt(o, wPx)
                            tryAwaitRelease()
                            pressed = null
                        },
                        onTap = { o ->
                            val z = zoneAt(o, wPx) ?: return@detectTapGestures
                            if (!ready) {
                                vm.log("Connect the phone in Fastboot or recovery ADB mode first.")
                            } else when (z) {
                                Zone.RESTART -> menu = true
                                Zone.FASTBOOT -> vm.enterMode(WheelMode.FASTBOOT)
                                else -> confirm = z
                            }
                        }
                    )
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val w = this.size.minDimension
                val c = Offset(w / 2f, w / 2f)
                val ro = w / 2f - 1.dp.toPx()
                val ri = w / 2f * INNER
                val gap = 4.dp.toPx()
                fun sector(a0: Float): Path {
                    val dOut = Math.toDegrees((gap / ro).toDouble()).toFloat()
                    val dIn = Math.toDegrees((gap / (ri + gap)).toDouble()).toFloat()
                    val rin = ri + gap
                    val p = Path()
                    p.arcTo(Rect(c.x - ro, c.y - ro, c.x + ro, c.y + ro), a0 + dOut, 90f - 2 * dOut, true)
                    p.arcTo(Rect(c.x - rin, c.y - rin, c.x + rin, c.y + rin), a0 + 90f - dIn, -(90f - 2 * dIn), false)
                    p.close()
                    return p
                }
                for (z in listOf(Zone.EDL, Zone.BROM, Zone.FASTBOOT, Zone.DOWNLOAD)) {
                    val lift = if (pressed == z) 0.28f else 0f
                    val path = sector(z.start)
                    drawPath(path, Brush.linearGradient(listOf(lerp(z.top, Color.White, lift), lerp(z.bottom, Color.White, lift)), Offset(0f, 0f), Offset(w, w)))
                    drawPath(path, Color.White.copy(alpha = 0.35f), style = Stroke(1.2.dp.toPx()))
                }
                val lift = if (pressed == Zone.RESTART) 0.28f else 0f
                val rc = ri - gap / 2f
                drawCircle(Brush.verticalGradient(listOf(lerp(Zone.RESTART.top, Color.White, lift), lerp(Zone.RESTART.bottom, Color.White, lift)), c.y - rc, c.y + rc), rc, c)
                drawCircle(Color.White.copy(alpha = 0.45f), rc, c, style = Stroke(1.5.dp.toPx()))
            }

            @Composable
            fun Label(icon: Int, l1: String, l2: String, dx: Dp, dy: Dp) {
                Column(
                    Modifier.align(Alignment.Center).offset(x = dx, y = dy),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(painterResource(icon), null, Modifier.size(iconDp))
                    Text(
                        l1 + "\n" + l2, color = Color.White, fontSize = labelSp, lineHeight = labelSp * 1.05f,
                        fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center, style = TextStyle(shadow = LabelShadow)
                    )
                }
            }
            Label(R.drawable.w_android, "EDL", "MODE", -ox, -oy)
            Label(R.drawable.w_chip, "VROOM", "MODE", ox, -oy)
            Label(R.drawable.w_download, "DOWNLOAD", "MODE", -ox, oy)
            Label(R.drawable.w_bolt, "FASTBOOT", "MODE", ox, oy)
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                Image(painterResource(R.drawable.w_restart), null, Modifier.size(iconDp * 1.25f))
                Text(
                    "RESTART", color = Color.White, fontSize = labelSp * 0.95f,
                    fontWeight = FontWeight.ExtraBold, style = TextStyle(shadow = LabelShadow)
                )
            }
        }
        if (!ready) T("Connect a phone in Fastboot or recovery ADB mode to use these buttons.", C.dim, 11, mod = Modifier.padding(top = 4.dp))
    }

    // RESTART opens a small menu with the actions the wheel has no zone for.
    if (menu) {
        AlertDialog(
            onDismissRequest = { menu = false },
            confirmButton = { TextButton(onClick = { menu = false }) { Text("CANCEL", color = C.dim, fontFamily = Sans, fontWeight = FontWeight.SemiBold) } },
            title = { Text("RESTART", fontFamily = Sans, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Btn("REBOOT SYSTEM", ready) { menu = false; vm.enterMode(WheelMode.SYSTEM) }
                    Btn("REBOOT TO RECOVERY", ready) { menu = false; vm.enterMode(WheelMode.RECOVERY) }
                }
            },
            shape = PanelShape, containerColor = C.panel, titleContentColor = C.amber, textContentColor = C.text
        )
    }

    // The three special modes ask first, because a wrong tap leaves the phone on a black screen.
    confirm?.let { z ->
        val (title, msg, target) = when (z) {
            Zone.EDL -> Triple("EDL MODE", "Reboot the phone into EDL (Qualcomm 9008)? The screen goes black. Many phones do not accept this command; if so, the app reports it.", WheelMode.EDL)
            Zone.BROM -> Triple("VROOM MODE", "Try to reboot the phone into BROM (MediaTek)? Few phones accept a software command. If it does not work, use the key steps in HOW TO ENTER EACH MODE.", WheelMode.BROM)
            else -> Triple("DOWNLOAD MODE", "Reboot the phone into Samsung Download mode? This works only on Samsung phones in recovery ADB mode.", WheelMode.DOWNLOAD)
        }
        AlertDialog(
            onDismissRequest = { confirm = null },
            confirmButton = { TextButton(onClick = { confirm = null; vm.enterMode(target) }) { Text("CONFIRM", color = C.blue, fontFamily = Sans, fontWeight = FontWeight.Bold) } },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("CANCEL", color = C.dim, fontFamily = Sans, fontWeight = FontWeight.SemiBold) } },
            title = { Text(title, fontFamily = Sans, fontWeight = FontWeight.Bold) },
            text = { Text(msg, fontFamily = Sans, fontSize = 15.sp, fontWeight = FontWeight.Medium) },
            shape = PanelShape, containerColor = C.panel, titleContentColor = C.amber, textContentColor = C.text
        )
    }
}
