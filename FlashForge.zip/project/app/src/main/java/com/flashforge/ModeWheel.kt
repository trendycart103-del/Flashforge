package com.flashforge

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.*

/** Five-sector glossy action wheel. Each sector maps to an existing, guarded device command. */
private enum class Zone(
    val title: String, val mode: WheelMode, val icon: Int,
    val top: Color, val bottom: Color, val centerAngle: Float
) {
    EDL("EDL", WheelMode.EDL, R.drawable.ff_master_icon_02, Color(0xFFD9A4FF), Color(0xFF6821D8), -90f),
    BROM("BROM", WheelMode.BROM, R.drawable.ff_master_icon_11, Color(0xFF73F3FF), Color(0xFF0755D8), 0f),
    DOWNLOAD("DOWNLOAD", WheelMode.DOWNLOAD, R.drawable.ff_master_icon_12, Color(0xFF9BEAFF), Color(0xFF1645C8), 90f),
    FASTBOOT("FASTBOOT", WheelMode.FASTBOOT, R.drawable.ff_master_icon_23, Color(0xFFC6A2FF), Color(0xFF4820C9), 180f)
}

private const val INNER = 0.265f
private fun angleNorm(a: Float) = (a % 360f + 360f) % 360f
private fun zoneAt(o: Offset, w: Float): Zone? {
    val c = w / 2f
    val dx = o.x - c; val dy = o.y - c
    val r = hypot(dx.toDouble(), dy.toDouble()).toFloat()
    if (r > c || r < c * INNER) return null
    val a = angleNorm(Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat())
    return Zone.values().firstOrNull { z ->
        val delta = angleNorm(a - angleNorm(z.centerAngle + 360f))
        delta < 45f || delta > 315f
    }
}

@Composable
fun ModeWheel(vm: MainVM, diameter: Dp = 300.dp) {
    val ready = (vm.mode == Mode.FASTBOOT || vm.mode == Mode.ADB) && !vm.busy
    var pressed by remember { mutableStateOf<Zone?>(null) }
    var confirm by remember { mutableStateOf<Zone?>(null) }
    var confirmRestart by remember { mutableStateOf(false) }
    val d = diameter.value
    val iconDp = (d * 0.145f).dp
    val labelSp = (d * 0.043f).sp
    val outer = d * 0.34f

    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(diameter).alpha(if (ready) 1f else 0.62f)
            .pointerInput(ready) {
                val wPx = size.width.toFloat()
                detectTapGestures(onPress = { p -> pressed = zoneAt(p, wPx); tryAwaitRelease(); pressed = null }, onTap = { p ->
                    val center = wPx / 2f
                    val radius = hypot((p.x-center).toDouble(), (p.y-center).toDouble()).toFloat()
                    if (!ready) vm.log("Connect the phone in Fastboot or recovery ADB mode first.")
                    else if (radius < center * INNER) confirmRestart = true
                    else zoneAt(p, wPx)?.let { confirm = it }
                })
            }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val w = size.minDimension; val c = Offset(w / 2f, w / 2f)
                val ro = w / 2f - 2.dp.toPx(); val ri = w / 2f * INNER; val gap = 4.dp.toPx()
                val rect = Rect(c.x-ro,c.y-ro,c.x+ro,c.y+ro)
                Zone.values().forEach { z ->
                    val start = z.centerAngle - 43f
                    val p = Path().apply {
                        val a0 = Math.toRadians(start.toDouble()); val a1 = Math.toRadians((start+86f).toDouble())
                        moveTo(c.x+cos(a0).toFloat()*(ri+gap), c.y+sin(a0).toFloat()*(ri+gap))
                        lineTo(c.x+cos(a0).toFloat()*(ro-gap), c.y+sin(a0).toFloat()*(ro-gap))
                        arcTo(rect,start,86f,false)
                        lineTo(c.x+cos(a1).toFloat()*(ri+gap), c.y+sin(a1).toFloat()*(ri+gap))
                        arcTo(Rect(c.x-ri-gap,c.y-ri-gap,c.x+ri+gap,c.y+ri+gap),start+86f,-86f,false)
                        close()
                    }
                    val lift = if (pressed == z) 0.18f else 0f
                    drawPath(p, Color.Black.copy(alpha=.76f), style=Stroke(13.dp.toPx()))
                    drawPath(p, Brush.linearGradient(listOf(lerp(Color(0xFF8C45C8),Color.White,lift), z.bottom, Color(0xFF07172E)),Offset(0f,0f),Offset(w,w)))
                    drawPath(p, Color(0xFF35DFFF).copy(alpha=.9f), style=Stroke(2.8.dp.toPx()))
                    drawPath(p, Color(0xFFFF5DDB).copy(alpha=.58f), style=Stroke(1.1.dp.toPx()))
                    drawPath(p, Color.White.copy(alpha=.38f), style=Stroke(5.dp.toPx()))
                }
                drawCircle(Color.Black.copy(alpha=.8f),ro+2.dp.toPx(),c,style=Stroke(9.dp.toPx()))
                drawCircle(Color(0xFFB45CFF).copy(alpha=.32f),ro+5.dp.toPx(),c,style=Stroke(12.dp.toPx()))
                drawCircle(Brush.verticalGradient(listOf(Color(0xFF24203F),Color(0xFF100D25),Color(0xFF050812))),ri,c)
                drawCircle(Color(0xFF39DFFF),ri,c,style=Stroke(3.dp.toPx()))
                drawCircle(Color(0xFFFF5DDB).copy(alpha=.7f),ri+3.dp.toPx(),c,style=Stroke(1.dp.toPx()))
                drawCircle(Color(0xFF39DFFF),ro,c,style=Stroke(2.8.dp.toPx()))
            }
            Zone.values().forEach { z ->
                val rad = Math.toRadians(z.centerAngle.toDouble())
                val x = (outer * cos(rad)).dp
                val y = (outer * sin(rad)).dp
                Column(Modifier.align(Alignment.Center).offset(x=x,y=y), horizontalAlignment=Alignment.CenterHorizontally) {
                    Image(painterResource(z.icon), null, Modifier.size(iconDp))
                    Text(z.title, color=Color.White, fontSize=labelSp, lineHeight=labelSp*1.05f,
                        fontWeight=FontWeight.ExtraBold, textAlign=TextAlign.Center, letterSpacing=.1.sp)
                }
            }
            Column(Modifier.align(Alignment.Center).size((d * INNER * 1.75f).dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Image(painterResource(R.drawable.ff_master_icon_13), null, Modifier.size(iconDp * .82f))
                Text("RESTART", color = Color.White, fontSize = (labelSp.value * .78f).sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
            }
        }
        if (!ready) T("Connect a phone in Fastboot or recovery ADB mode to use these actions.", C.dim, 11, mod=Modifier.padding(top=6.dp))
    }
    if (confirmRestart) AlertDialog(
        onDismissRequest = { confirmRestart = false },
        confirmButton = { TextButton(onClick = { confirmRestart = false; vm.enterMode(WheelMode.SYSTEM) }) { Text("RESTART", color = Color(0xFF43DFFF), fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = { confirmRestart = false }) { Text("CANCEL", color = C.dim) } },
        title = { Text("RESTART SYSTEM", fontWeight = FontWeight.Bold) },
        text = { Text("Restart the connected phone into Android system?") },
        shape = PanelShape, containerColor = C.panel, titleContentColor = Color(0xFF43DFFF), textContentColor = C.text
    )
    confirm?.let { z ->
        val (title,msg) = when(z) {
            Zone.EDL -> "EDL MODE" to "Reboot the phone into Qualcomm EDL? The screen goes black; this command is not supported by every model."
            Zone.BROM -> "BROM MODE" to "Try to reboot into MediaTek BROM. If unsupported, use the device-specific key combination."
            Zone.DOWNLOAD -> "DOWNLOAD MODE" to "Try Samsung Download mode. This works only on supported Samsung devices in recovery ADB."
            Zone.FASTBOOT -> "FASTBOOT MODE" to "Reboot the connected phone into bootloader / Fastboot mode?"
        }
        AlertDialog(onDismissRequest={confirm=null},
            confirmButton={ TextButton(onClick={confirm=null; vm.enterMode(z.mode)}) { Text("CONFIRM",color=Color(0xFF43DFFF),fontWeight=FontWeight.Bold) } },
            dismissButton={ TextButton(onClick={confirm=null}) { Text("CANCEL",color=C.dim) } },
            title={Text(title,fontWeight=FontWeight.Bold)}, text={Text(msg)}, shape=PanelShape,
            containerColor=C.panel,titleContentColor=Color(0xFF43DFFF),textContentColor=C.text)
    }
}
