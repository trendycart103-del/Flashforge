package com.flashforge

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Decodes a picture chosen from the phone, scaled down so that its longest side is at most [maxSide] pixels. Returns null on any problem. */
fun loadBackgroundBitmap(ctx: Context, uriText: String, maxSide: Int = 1600): ImageBitmap? {
    if (uriText.isBlank()) return null
    return try {
        val uri = Uri.parse(uriText)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }?.asImageBitmap()
    } catch (e: Exception) {
        android.util.Log.w("FlashForge", "Background image could not be loaded", e)
        null
    }
}

@Composable
fun BgThumb(choice: Int, bitmap: ImageBitmap?, modifier: Modifier) {
    when {
        choice == 2 && bitmap != null -> Image(bitmap, null, modifier, contentScale = ContentScale.Crop)
        choice == 3 -> Image(painterResource(R.drawable.bg_default_3), null, modifier, contentScale = ContentScale.Crop)
        choice == 4 -> Image(painterResource(R.drawable.bg_default_4), null, modifier, contentScale = ContentScale.Crop)
        choice == 5 -> Image(painterResource(R.drawable.bg_default_5), null, modifier, contentScale = ContentScale.Crop)
        choice == 6 -> Image(painterResource(R.drawable.bg_default_6), null, modifier, contentScale = ContentScale.Crop)
        choice == 7 -> Image(painterResource(R.drawable.bg_default_7), null, modifier, contentScale = ContentScale.Crop)
        choice == 8 -> Image(painterResource(R.drawable.bg_default_8), null, modifier, contentScale = ContentScale.Crop)
        choice == 9 -> Image(painterResource(R.drawable.bg_default_9), null, modifier, contentScale = ContentScale.Crop)
        else -> Image(painterResource(R.drawable.bg_default_10), null, modifier, contentScale = ContentScale.Crop)
    }
}

/** Full-screen high-contrast background. Wallpapers are intentionally not rendered behind app content. */
@Composable
fun AppBackground() {
    val ctx = LocalContext.current
    val choice = AppSettings.bgChoice
    val uri = AppSettings.bgUri
    val custom by produceState<ImageBitmap?>(null, choice, uri) {
        value = if (choice == 2) withContext(Dispatchers.IO) { loadBackgroundBitmap(ctx, uri) } else null
    }
    // The main app background is intentionally image-free: textured wallpapers reduced
    // contrast and made text/cards hard to read on small screens.
    androidx.compose.foundation.layout.Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFFF3F6FC), Color(0xFFE8EEF8), Color(0xFFF7F9FC)))
        )
    )
}
