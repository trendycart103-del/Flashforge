package com.flashforge

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.collectAsState
import androidx.compose.animation.core.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Decodes a picture chosen from the phone, scaled down so that its longest side is at most [maxSide] pixels. Returns null on any problem. */
fun loadBackgroundBitmap(ctx: Context, uriText: String, maxSide: Int = 1600): ImageBitmap? {
    if (uriText.isBlank()) return null
    return try {
        val uri = Uri.parse(uriText)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }?.asImageBitmap()
    } catch (e: Exception) {
        android.util.Log.w("FlashForge", "Background image could not be loaded", e)
        null
    }
}

@Composable
fun BgThumb(choice: Int, bitmap: ImageBitmap?, modifier: Modifier) {
    when {
        choice == 2 && bitmap != null -> Image(bitmap, null, modifier, contentScale = ContentScale.Crop)
        choice == 3 -> Image(painterResource(R.drawable.bg_default_3), null, modifier, contentScale = ContentScale.Crop)
        choice == 4 -> Image(painterResource(R.drawable.bg_default_4), null, modifier, contentScale = ContentScale.Crop)
        choice == 5 -> Image(painterResource(R.drawable.bg_default_5), null, modifier, contentScale = ContentScale.Crop)
        choice == 6 -> Image(painterResource(R.drawable.bg_default_6), null, modifier, contentScale = ContentScale.Crop)
        choice == 7 -> Image(painterResource(R.drawable.bg_default_7), null, modifier, contentScale = ContentScale.Crop)
        choice == 8 -> Image(painterResource(R.drawable.bg_default_8), null, modifier, contentScale = ContentScale.Crop)
        choice == 9 -> Image(painterResource(R.drawable.bg_default_9), null, modifier, contentScale = ContentScale.Crop)
        else -> Image(painterResource(R.drawable.bg_default_10), null, modifier, contentScale = ContentScale.Crop)
    }
}

/** Black gaming wallpaper with restrained slow-motion white light streaks and particles. */
@Composable
fun AppBackground() {
    val ctx = LocalContext.current
    val choice = AppSettings.bgChoice
    val uri = AppSettings.bgUri
    val custom by produceState<ImageBitmap?>(null, choice, uri) {
        value = if (choice == 2) withContext(Dispatchers.IO) { loadBackgroundBitmap(ctx, uri) } else null
    }
    if (choice == 2 && custom != null) {
        Image(custom!!, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .28f)))
        return
    }
    val transition = rememberInfiniteTransition(label = "blackGamingWallpaper")
    val travel by transition.animateFloat(0f, 1f, animationSpec = infiniteRepeatable(
        animation = tween(24000, easing = LinearEasing), repeatMode = RepeatMode.Restart), label = "lightTravel")
    val pulse by transition.animateFloat(.16f, .34f, animationSpec = infiniteRepeatable(
        animation = tween(7000, easing = FastOutSlowInEasing), repeatMode = RepeatMode.Reverse), label = "lightPulse")
    Box(Modifier.fillMaxSize().background(Color(0xFF030305))) {
        Canvas(Modifier.fillMaxSize()) {
            // Edge-only circuit traces keep the center quiet for text and controls.
            val edge = Color(0xFFB8B8D8).copy(alpha = .075f)
            val violet = Color(0xFF9A78FF).copy(alpha = .09f)
            for (i in 0..5) {
                val y = size.height * (.08f + i * .15f)
                drawLine(edge, Offset(0f, y), Offset(size.width * .13f, y), 1.dp.toPx())
                drawLine(edge, Offset(size.width, y), Offset(size.width * .86f, y), 1.dp.toPx())
                drawCircle(edge, 2.dp.toPx(), Offset(size.width * .13f, y))
                drawCircle(edge, 2.dp.toPx(), Offset(size.width * .86f, y))
            }
            // Soft, slow light trails sweep along the edges, never across the main content area.
            val x1 = size.width * (.02f + .18f * travel)
            val x2 = size.width * (.98f - .18f * travel)
            drawLine(Color.White.copy(alpha = pulse), Offset(x1, size.height * .13f), Offset(x1 + size.width * .11f, size.height * .08f), 1.8.dp.toPx())
            drawLine(Color.White.copy(alpha = pulse * .7f), Offset(x2, size.height * .87f), Offset(x2 - size.width * .12f, size.height * .91f), 1.5.dp.toPx())
            drawLine(violet, Offset(size.width * .02f, size.height * .25f), Offset(size.width * .11f, size.height * .29f), 1.2.dp.toPx())
            drawLine(violet, Offset(size.width * .98f, size.height * .65f), Offset(size.width * .89f, size.height * .61f), 1.2.dp.toPx())
            // Sparse drifting points. Their positions cycle slowly and remain low contrast.
            for (i in 0..17) {
                val phase = (travel + i * .071f) % 1f
                val x = size.width * ((i * .173f + phase * .11f) % 1f)
                val y = size.height * ((i * .239f + phase * .17f) % 1f)
                val a = (.05f + .08f * (1f - phase))
                drawCircle(Color.White.copy(alpha = a), (1.0f + (i % 3) * .35f).dp.toPx(), Offset(x, y))
            }
        }
        // Very subtle corner shading supports readability and the black gaming aesthetic.
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha=.05f), Color.Black.copy(alpha=.18f), Color.Black.copy(alpha=.08f)))))
    }
}
