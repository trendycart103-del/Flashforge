package com.flashforge

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Decodes a picture chosen from the phone, scaled down so that its longest side is at most [maxSide] pixels. Returns null on any problem. */
fun loadBackgroundBitmap(ctx: Context, uriText: String, maxSide: Int = 1600): ImageBitmap? {
    if (uriText.isBlank()) return null
    return try {
        val uri = Uri.parse(uriText)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }?.asImageBitmap()
    } catch (e: Exception) {
        android.util.Log.w("FlashForge", "Background image could not be loaded", e)
        null
    }
}

@Composable
fun BgThumb(choice: Int, bitmap: ImageBitmap?, modifier: Modifier) {
    when {
        choice == 2 && bitmap != null -> Image(bitmap, null, modifier, contentScale = ContentScale.Crop)
        choice == 3 -> Image(painterResource(R.drawable.bg_default_3), null, modifier, contentScale = ContentScale.Crop)
        choice == 4 -> Image(painterResource(R.drawable.bg_default_4), null, modifier, contentScale = ContentScale.Crop)
        choice == 5 -> Image(painterResource(R.drawable.bg_default_5), null, modifier, contentScale = ContentScale.Crop)
        choice == 6 -> Image(painterResource(R.drawable.bg_default_6), null, modifier, contentScale = ContentScale.Crop)
        choice == 7 -> Image(painterResource(R.drawable.bg_default_7), null, modifier, contentScale = ContentScale.Crop)
        choice == 8 -> Image(painterResource(R.drawable.bg_default_8), null, modifier, contentScale = ContentScale.Crop)
        choice == 9 -> Image(painterResource(R.drawable.bg_default_9), null, modifier, contentScale = ContentScale.Crop)
        else -> Image(painterResource(R.drawable.bg_default_10), null, modifier, contentScale = ContentScale.Crop)
    }
}

/** Full-screen high-contrast background. Wallpapers are intentionally not rendered behind app content. */
@Composable
fun AppBackground() {
    val ctx = LocalContext.current
    val choice = AppSettings.bgChoice
    val uri = AppSettings.bgUri
    val custom by produceState<ImageBitmap?>(null, choice, uri) {
        value = if (choice == 2) withContext(Dispatchers.IO) { loadBackgroundBitmap(ctx, uri) } else null
    }
    // Deep navy neon circuit backdrop. Decorative only; all app logic and user settings stay untouched.
    Box(Modifier.fillMaxSize().background(
        Brush.verticalGradient(listOf(Color(0xFF050A27), Color(0xFF0A1242), Color(0xFF080B2C)))
    )) {
        Canvas(Modifier.fillMaxSize()) {
            val steel = Color(0xFF8D55FF).copy(alpha = 0.22f)
            val cyan = Color(0xFF20DFFF).copy(alpha = 0.18f)
            fun gear(cx: Float, cy: Float, r: Float, teeth: Int) {
                drawCircle(steel, r, Offset(cx, cy), style = Stroke(width = r * 0.075f))
                drawCircle(cyan, r * 0.70f, Offset(cx, cy), style = Stroke(width = r * 0.045f))
                drawCircle(steel, r * 0.25f, Offset(cx, cy), style = Stroke(width = r * 0.07f))
                for (i in 0 until teeth) {
                    val a = (Math.PI * 2.0 * i / teeth).toFloat()
                    val inner = r * 0.91f; val outer = r * 1.10f
                    val x1 = cx + kotlin.math.cos(a) * inner
                    val y1 = cy + kotlin.math.sin(a) * inner
                    val x2 = cx + kotlin.math.cos(a) * outer
                    val y2 = cy + kotlin.math.sin(a) * outer
                    drawLine(steel, Offset(x1, y1), Offset(x2, y2), strokeWidth = r * 0.11f)
                }
                for (i in 0 until 6) {
                    val a = (Math.PI * 2.0 * i / 6.0).toFloat()
                    drawLine(steel.copy(alpha = 0.65f), Offset(cx + kotlin.math.cos(a) * r * 0.30f, cy + kotlin.math.sin(a) * r * 0.30f), Offset(cx + kotlin.math.cos(a) * r * 0.65f, cy + kotlin.math.sin(a) * r * 0.65f), strokeWidth = r * 0.045f)
                }
            }
            gear(size.width * 0.90f, size.height * 0.20f, size.minDimension * 0.19f, 14)
            gear(size.width * 0.82f, size.height * 0.78f, size.minDimension * 0.13f, 12)
            gear(size.width * 0.08f, size.height * 0.88f, size.minDimension * 0.10f, 12)
            // restrained circuit traces at the edges, away from the main reading area
            for (i in 0..5) {
                val y = size.height * (0.12f + i * 0.14f)
                drawLine(cyan, Offset(0f, y), Offset(size.width * 0.16f, y), strokeWidth = 1.2f)
                drawCircle(cyan, 3f, Offset(size.width * 0.16f, y))
            }
        }
        Box(Modifier.fillMaxSize().background(
            Brush.horizontalGradient(listOf(Color(0xFF32106E).copy(alpha = 0.18f), Color.Transparent, Color(0xFF063D75).copy(alpha = 0.18f)))
        ))
    }
}
