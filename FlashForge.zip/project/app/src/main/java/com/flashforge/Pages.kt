package com.flashforge

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.ui.draw.alpha
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

private fun nm(u: Uri?): String = u?.lastPathSegment?.substringAfterLast('/') ?: "no file chosen"

@Composable
fun DevicePage(vm: MainVM) {
    Panel("DETECTED DEVICE") {
        KV("Vendor", vm.vendor.ifBlank { "-" })
        KV("USB ID", vm.usbId.ifBlank { "-" })
        KV("Mode", vm.mode.label)
        KV("Product ID", vm.product.ifBlank { "-" })
        KV("Model", vm.modelName.ifBlank { "-" })
        KV("Chip", vm.chip.ifBlank { "-" })
        KV("Bootloader unlocked", vm.unlocked)
        KV("Fastbootd", if (vm.userspace) "yes" else "no")
        if (vm.modelNote.isNotBlank()) T(vm.modelNote, C.amber, 12, mod = Modifier.padding(top = 6.dp))
        when (vm.mode) {
            Mode.SAMSUNG_DOWNLOAD, Mode.QUALCOMM_EDL, Mode.MEDIATEK_BROM, Mode.UNISOC ->
                T("Device recognised. The read/write protocol for this mode is not part of this build yet; the chip and mode shown here are what the protocol module will use.", C.amber, 12, mod = Modifier.padding(top = 6.dp))
            Mode.UNKNOWN -> T("Unknown USB device. Put the phone into a known mode using the guide below.", C.red, 12, mod = Modifier.padding(top = 6.dp))
            else -> { }
        }
    }
    QuickActions(vm, Modifier.padding(vertical = 4.dp))
    ModeWheel(vm, 300.dp)
    Panel("MODEL GUARD") {
        Field(vm.expected, { vm.changeExpected(it) }, "Expected product ID (blocks flash if different)")
        T("Leave empty to disable. Current device reports: ${vm.product.ifBlank { "-" }}", C.dim, 11)
    }
    Panel("HOW TO ENTER EACH MODE", vm.mode == Mode.UNKNOWN || vm.mode == Mode.NONE, R.drawable.ic_modes, C.blue) {
        listOf(
            Mode.FASTBOOT to "Power off. Hold Volume Down + Power (Pixel, Motorola, OnePlus, Xiaomi) until the fastboot screen shows, then plug in the cable. From a running phone: adb reboot bootloader.",
            Mode.ADB to "Recovery: Apply update, then Apply update from ADB. Use the ROM & Root tab to sideload.",
            Mode.SAMSUNG_DOWNLOAD to "Power off. Hold Volume Up + Volume Down, plug in the cable, press Volume Up to accept the Download screen.",
            Mode.QUALCOMM_EDL to "From a running phone: adb reboot edl. Otherwise a vendor key combination or test point. Needs the model's firehose programmer file.",
            Mode.MEDIATEK_BROM to "Power off. Hold Volume Up (some models Volume Down) while plugging in the cable. Needs the model's download agent file.",
            Mode.UNISOC to "Power off. Hold the boot key (usually Volume Down) while plugging in the cable. Needs the FDL files."
        ).forEach { (m, text) ->
            Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                T(m.label, if (vm.mode == m) C.green else C.amber, 12, true)
                T(text, C.dim, 11)
            }
        }
    }
}

@Composable
fun BubblePanel(vm: MainVM) {
    val ctx = LocalContext.current
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.refreshPerms() }
    Panel("FLOATING BUBBLE", false) {
        KV("Overlay permission", if (vm.overlayOk) "granted" else "not granted")
        KV("Notifications", if (vm.notifOk) "allowed" else "not allowed")
        KV("Bubble", if (vm.bubbleOn) "ON" else "OFF")
        T("While a flash, backup, sideload or download runs, a bubble floats over every app with the progress and cable warnings. Tap it to come back here, drag it to move it.", C.dim, 11, mod = Modifier.padding(top = 4.dp))
        Spacer(Modifier.height(8.dp))
        if (!vm.overlayOk) {
            Rw {
                Btn("GRANT OVERLAY PERMISSION", mod = Modifier.weight(1f)) {
                    ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
                }
            }
        }
        if (!vm.notifOk && Build.VERSION.SDK_INT >= 33) {
            Rw { Btn("ALLOW NOTIFICATIONS", mod = Modifier.weight(1f)) { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) } }
        }
        Rw {
            Btn(if (vm.bubbleOn) "BUBBLE: ON" else "BUBBLE: OFF", mod = Modifier.weight(1f)) { vm.toggleBubble() }
            Btn("TEST BUBBLE", !vm.busy, mod = Modifier.weight(1f)) { vm.testBubble() }
        }
    }
}

@Composable
fun FlashPage(vm: MainVM) {
    var part by remember { mutableStateOf("") }
    var pname by remember { mutableStateOf(vm.product) }
    var url by remember { mutableStateOf("") }
    val on = vm.mode == Mode.FASTBOOT && !vm.busy
    ModeWheel(vm, 230.dp)
    Panel("ADD IMAGE") {
        Field(part, { part = it }, "Explicit target partition (required; never inferred from filename)")
        Rw {
            PickBtn("ADD IMAGE", Modifier.weight(1f)) { vm.addFile(it, part) }
            PickBtn("UNPACK ZIP", Modifier.weight(1f)) { vm.unzipToQueue(it) }
        }
    }
    FlashToolBanner(vm)
    Panel("FLASH QUEUE (${vm.queue.size})") {
        if (vm.queue.isEmpty()) T("Queue is empty. Add images in the order they must be flashed.", C.dim, 11)
        val toolBrand = flashBrandOf(vm)
        val partRegex = Regex("[A-Za-z0-9_]{1,48}")
        vm.queue.forEachIndexed { i, q ->
            Column(Modifier.fillMaxWidth().alpha(if (q.enabled) 1f else 0.45f)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    SlotToggle(q.enabled, !vm.busy, toolBrand) { vm.toggleQueueItem(i) }
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        T("${i + 1}. ${q.name}", C.text, 12)
                        T("${q.size / 1024} KB" + if (q.enabled) "" else "  - SKIPPED", C.dim, 11)
                    }
                    IconBtn(R.drawable.b_up) { vm.move(i) }
                    IconBtn(R.drawable.b_trash) { vm.verifiedFirmware.remove(q.uri.toString() + "|" + q.size); vm.queue.removeAt(i) }
                }
                var queuePartition by remember(q.uri.toString()) { mutableStateOf(q.part) }
                Field(queuePartition, { queuePartition = it; vm.setQueuePartition(i, it) }, "Explicit target partition for ${q.name} (required)")
                var expectedHash by remember(q.uri.toString()) { mutableStateOf("") }
                Field(expectedHash, { expectedHash = it }, "Trusted SHA-256 for ${q.name}")
                val itemVerified = vm.verifiedFirmware[q.uri.toString() + "|" + q.size] != null
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Btn("VERIFY SHA-256", !vm.busy && expectedHash.isNotBlank()) { vm.hash(q, expectedHash) }
                    T(if (itemVerified) "VERIFIED" else "NOT VERIFIED", if (itemVerified) C.green else C.amber, 10, true, Modifier.padding(start = 8.dp))
                }
                val itemReady = q.part.matches(partRegex) && itemVerified
                Rw {
                    ConfirmBtn(
                        "FLASH ONLY THIS", "Flash only '${q.name}' to '${q.part}'? All other queue files are left out of this run.",
                        enabled = on && itemReady && vm.safetyWarningsAcknowledged, danger = true, mod = Modifier.weight(1f)
                    ) { vm.flashQueue(i) }
                }
            }
        }
        val selected = vm.queue.filter { it.enabled }
        val queueReady = selected.isNotEmpty() && selected.all { item ->
            item.part.matches(partRegex) && vm.verifiedFirmware[item.uri.toString() + "|" + item.size] != null
        }
        ConfirmBtn(
            "FLASH SELECTED (${selected.size})", "Flash ${selected.size} selected image(s) in the listed order? Skipped files are not flashed. Every selected image must have an explicit partition and a matching publisher SHA-256.",
            enabled = on && queueReady && vm.safetyWarningsAcknowledged
        ) { vm.flashQueue() }
    }
    Panel("PHONE PROFILE", false) {
        Field(pname, { pname = it }, "Profile name")
        Btn("SAVE QUEUE AS PROFILE", pname.isNotBlank()) { vm.saveQueue(pname) }
        vm.profileNames().forEach { n -> TextButton(onClick = { vm.loadQueue(n) }) { T("load: $n", C.amber, 12) } }
    }
    val ctx = LocalContext.current
    val brandLinks = vm.brandLinks()
    var manualModelCode by remember { mutableStateOf("") }
    var manualRegion by remember { mutableStateOf("") }
    val detectedBrand = vm.brandName().ifBlank { "Unknown" }
    // Never include IMEI/serial values in search URLs. Use only public model identifiers.
    val modelTokens = buildList {
        if (vm.modelName.isNotBlank() && vm.modelName != "Not in database") add(vm.modelName)
        if (vm.product.isNotBlank()) add(vm.product)
        listOf("sku", "variant", "model", "device", "hardware-revision", "hw-revision").forEach { key ->
            vm.vars[key]?.takeIf { it.isNotBlank() && it != "unknown" }?.let(::add)
        }
    }.distinct()
    val officialSources = FirmwareSourceResolver.forBrand(detectedBrand, (modelTokens + manualModelCode).joinToString(" "), manualRegion)
    Panel("AUTO FIRMWARE SEARCH", false) {
        KV("Detected brand", detectedBrand)
        Field(manualModelCode, { manualModelCode = it }, "Exact model number (optional, e.g. SM-A145F / 23053RN02A)")
        Field(manualRegion, { manualRegion = it }, "Region / CSC (optional, e.g. INS / XSG / MIXM)")
        KV("Search identifiers", modelTokens.joinToString(" / ").ifBlank { "Model code unavailable" })
        if (modelTokens.isEmpty()) T("Exact model identifiers were not reported by this connection. Do not choose firmware using the brand name alone.", C.amber, 11)
        officialSources.forEach { source ->
            T("✓ ${source.title} · OFFICIAL", C.blue, 12, true, Modifier.fillMaxWidth().clickable {
                try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(source.url))) } catch (e: Exception) { android.util.Log.e("FlashForge", "Could not open firmware source ${source.url}", e) }
            }.padding(vertical = 7.dp))
        }
        T("These links open manufacturer-owned portals or searches scoped to the manufacturer's domain; they are not guaranteed direct firmware files. Confirm exact model number, region/CSC, bootloader revision and package type before downloading. Independent mirrors are not presented as official.", C.dim, 11)
    }
    val edlLoaderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.setOptionalLoader("edl", uri)
    }
    val mtkLoaderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.setOptionalLoader("mtk", uri)
    }
    val edlLoader = vm.optionalLoader("edl")
    val mtkLoader = vm.optionalLoader("mtk")
    Panel("CHIPSET FLASH ENGINE STATUS", false) {
        ChipsetFlashEngines.engines.forEach { engine ->
            T(engine.title, C.text, 12, true)
            T("Transport: ${engine.transport}", C.dim, 10)
            T("Requirements: ${engine.requirements}", C.dim, 10)
            T("Status: Detection supported; write engine remains locked until the exact authorized loader/protocol is implemented and validated.", C.amber, 10)
            when (engine.mode) {
                Mode.QUALCOMM_EDL -> {
                    T("Optional loader: ${edlLoader?.lastPathSegment ?: "Not selected"}", C.dim, 10)
                    Rw {
                        Btn("SELECT OPTIONAL EDL PROGRAMMER", !vm.busy, mod = Modifier.weight(1f)) {
                            edlLoaderPicker.launch(arrayOf("*/*"))
                        }
                        if (edlLoader != null) Btn("CLEAR", !vm.busy) { vm.setOptionalLoader("edl", null) }
                    }
                    T("Optional only. Choose a signed programmer supplied for this exact model by its manufacturer or authorized service source. Selection does not run or flash it.", C.amber, 10)
                }
                Mode.MEDIATEK_BROM -> {
                    T("Optional Download Agent: ${mtkLoader?.lastPathSegment ?: "Not selected"}", C.dim, 10)
                    Rw {
                        Btn("SELECT OPTIONAL MTK DA", !vm.busy, mod = Modifier.weight(1f)) {
                            mtkLoaderPicker.launch(arrayOf("*/*"))
                        }
                        if (mtkLoader != null) Btn("CLEAR", !vm.busy) { vm.setOptionalLoader("mtk", null) }
                    }
                    T("Optional only. Use an OEM-authorized DA matched to the exact model and security state. SLA/DAA/Secure Boot requirements are not bypassed. Selection does not run or flash it.", C.amber, 10)
                }
                else -> Unit
            }
        }
        T("No generic programmer, authentication bypass, or cross-model loader is used. Optional files are stored as references only; the current build does not execute chipset loaders or claim those protocols are flash-ready.", C.dim, 10)
    }
    Panel("FIRMWARE SITES: ${vm.brandName().ifBlank { "-" }.uppercase()}", false) {
        if (brandLinks.isEmpty()) T("Connect a phone to see the firmware sites of its brand.", C.dim, 11)
        brandLinks.forEach { (n, u) ->
            T(n, C.blue, 12, true, Modifier.fillMaxWidth().clickable {
                try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (e: Exception) { android.util.Log.e("FlashForge", "Could not open firmware link $u", e) }
            }.padding(vertical = 7.dp))
        }
        if (brandLinks.isNotEmpty()) T("Tap opens the site in your browser. After downloading, use ADD IMAGE or UNPACK ZIP above to pick the file.", C.dim, 11)
    }
    val links = vm.fwLinks()
    Panel("FIRMWARE FOR ${vm.modelName.ifBlank { "THIS PHONE" }.uppercase()}", false) {
        if (vm.product.isBlank()) T("Connect a phone in fastboot mode to see its firmware list.", C.dim, 11)
        else if (links.isEmpty()) T("No firmware link for '${vm.product}' in the database yet. Update the database in the Log tab or paste a URL below.", C.dim, 11)
        links.forEach { (n, u) ->
            Row(Modifier.fillMaxWidth().clickable(enabled = !vm.busy) { vm.download(u) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconBtn(R.drawable.b_download) { if (!vm.busy) vm.download(u) }
                Spacer(Modifier.padding(start = 8.dp))
                T(n, C.text, 12, mod = Modifier.weight(1f))
            }
        }
    }
    var filesTick by remember { mutableStateOf(0) }
    val files = remember(vm.busy, vm.queue.size, filesTick) { vm.fwFiles() }
    Panel("DOWNLOADED FILES (${files.size})", false) {
        T(vm.fwDir().absolutePath, C.dim, 10)
        if (files.isEmpty()) T("Nothing downloaded yet.", C.dim, 11)
        files.forEach { f ->
            Row(Modifier.fillMaxWidth().clickable(enabled = !vm.busy) { vm.useFwFile(f) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T(f.name, C.text, 12)
                    T("${f.length() / 1024 / 1024} MB  - tap to add to queue", C.dim, 11)
                }
                IconBtn(R.drawable.b_trash) { f.delete(); vm.queue.removeAll { it.name == f.name }; filesTick++ }
            }
        }
    }
    Panel("FIRMWARE DOWNLOAD", false) {
        Field(url, { url = it }, "Firmware URL (.img or .zip)")
        Btn("DOWNLOAD TO QUEUE", !vm.busy && url.isNotBlank()) { vm.download(url) }
    }
}

@Composable
fun PartPage(vm: MainVM) {
    var p by remember { mutableStateOf("") }
    var n by remember { mutableStateOf("") }
    var sz by remember { mutableStateOf("") }
    val on = vm.mode == Mode.FASTBOOT && !vm.busy
    Panel("PARTITION TABLE (${vm.parts.size})") {
        if (vm.parts.isEmpty()) T("Tap REFRESH at the top to read the table.", C.dim, 11)
        vm.parts.forEach { l ->
            T(l, C.text, 12, mod = Modifier.fillMaxWidth().clickable { p = l.substringBefore(':').trim() }.padding(vertical = 5.dp))
        }
    }
    Panel("SELECTED PARTITION") {
        Field(p, { p = it }, "Partition name")
        Rw {
            ConfirmBtn("ERASE", "Erase partition '$p'? This cannot be undone.", on && p.isNotBlank(), true, Modifier.weight(1f)) { vm.confirmedFbCmd("erase:$p") }
            Btn("BACKUP", on && p.isNotBlank(), false, Modifier.weight(1f)) { vm.backup(p) }
        }
        T("Backup uses fastboot fetch, which needs bootloader support. Files go to the app's files/backups folder.", C.dim, 11)
    }
    Panel("LOGICAL PARTITIONS (FASTBOOTD)", false) {
        Field(n, { n = it }, "Name, for example product_a")
        Field(sz, { sz = it }, "Size in bytes")
        Rw {
            Btn("CREATE", false, false, Modifier.weight(1f)) { }
            Btn("RESIZE", false, false, Modifier.weight(1f)) { }
        }
        ConfirmBtn("DELETE", "Logical partition modification is disabled in this build because metadata geometry and group limits cannot be verified.", false) { }
        T("Logical partition CREATE / RESIZE / DELETE are intentionally blocked until device-specific super metadata and group constraints can be verified. Existing controls are retained but disabled.", C.amber, 11)
        if (!vm.userspace) T("Fastbootd mode is required for logical partition diagnostics.", C.dim, 11)
    }
}

@Composable
private fun SlotButtons(vm: MainVM, enabled: Boolean, compact: Boolean = false) {
    Rw {
        for (s in listOf("a", "b")) {
            if (vm.slot == s) {
                Box(
                    Modifier.weight(1f).padding(vertical = 4.dp).heightIn(min = if (compact) 44.dp else 56.dp)
                        .background(C.amber.copy(alpha = 0.12f), FieldShape)
                        .border(2.dp, C.amber, FieldShape).padding(if (compact) 8.dp else 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    T("SLOT ${s.uppercase()}  ACTIVE", C.amber, 12, true)
                }
            } else {
                ConfirmBtn(
                    "SLOT ${s.uppercase()}",
                    "Make slot ${s.uppercase()} active? If that slot holds no valid system the phone will not boot.",
                    enabled = enabled && vm.isAB, danger = false, mod = Modifier.weight(1f), compact = compact
                ) { vm.changeSlot(s) }
            }
        }
    }
    if (!vm.isAB && vm.mode == Mode.FASTBOOT) T("This phone has no A/B slots.", C.dim, 11)
}

@Composable
private fun Sub(title: String) {
    Spacer(Modifier.height(10.dp))
    T(title, C.blue, 12, true)
    Spacer(Modifier.height(4.dp))
}

/** One compact line: choose-file button on the left, the chosen file name on the right. */
@Composable
private fun FilePick(label: String, uri: Uri?, on: (Uri) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        PickBtn(label, Modifier.weight(1f), compact = true, on = on)
        T(nm(uri), C.dim, 11, mod = Modifier.weight(1f))
    }
}

@Composable
private fun Verdict(ok: Boolean) {
    T(if (ok) "PUBLISHER CHECKSUM VERIFIED" else "IMAGE NOT VERIFIED", if (ok) C.green else C.amber, 10, true)
}

@Composable
fun RomRootPage(vm: MainVM) {
    var tab by remember { mutableStateOf(0) }
    var recPart by remember { mutableStateOf(AppSettings.defRecovery) }
    var rec by remember { mutableStateOf<Uri?>(null) }
    var recHash by remember { mutableStateOf("") }
    var rom by remember { mutableStateOf<Uri?>(null) }
    var romHash by remember { mutableStateOf("") }
    var extra by remember { mutableStateOf<Uri?>(null) }
    var extraHash by remember { mutableStateOf("") }
    var bp by remember { mutableStateOf(AppSettings.defBackup) }
    var boot by remember { mutableStateOf<Uri?>(null) }
    var bootHash by remember { mutableStateOf("") }
    var bootPart by remember { mutableStateOf(AppSettings.defPatched) }
    val fb = vm.mode == Mode.FASTBOOT && !vm.busy
    val adb = vm.mode == Mode.ADB && !vm.busy
    val hex64 = Regex("[0-9a-fA-F]{64}")
    val gUnlock = C.green
    val gRom = C.blue
    val gRoot = C.orange
    val hashLabel = "Publisher SHA-256 checksum (64 hex characters)"

    StatusStrip(listOf(
        "Mode" to vm.mode.label,
        "Bootloader" to vm.unlocked,
        "Model guard" to (if (vm.expected.isNotBlank()) "yes" else "no"),
        "Warnings read" to (if (vm.safetyWarningsAcknowledged) "yes" else "no")
    ))
    SegTabs(
        listOf("UNLOCK", "ROM", "ROOT"),
        listOf(R.drawable.ic_lock, R.drawable.ic_rom, R.drawable.ic_root),
        listOf(gUnlock, gRom, gRoot), tab
    ) { tab = it }

    when (tab) {
        // ---------------- UNLOCK ----------------
        0 -> {
            Panel("UNLOCK BOOTLOADER", true, R.drawable.b_unlock, gUnlock, true) {
                T("Erases all data on the phone.", C.red, 12, true)
                Rw {
                    ConfirmBtn("UNLOCK (flashing unlock)", "Unlock the bootloader and erase all data on the connected phone?", fb, mod = Modifier.weight(1f), compact = true) { vm.confirmedFbCmd("flashing unlock") }
                    ConfirmBtn("UNLOCK (legacy oem unlock)", "Send the legacy 'oem unlock' command and erase all data?", fb, mod = Modifier.weight(1f), compact = true) { vm.confirmedFbCmd("oem unlock") }
                }
            }
            Panel("GOOD TO KNOW", false, R.drawable.b_shield, gUnlock, true) {
                NoteTable(listOf(
                    "Before" to "Turn on OEM unlocking in Developer options. Confirm on the phone's screen when asked.",
                    "May refuse" to "Xiaomi, Huawei and carrier models often block this command.",
                    "Relock" to "Disabled. The app cannot prove every flashed partition is stock-compatible, so never lock after modified firmware."
                ), gUnlock)
            }
        }

        // ---------------- CUSTOM ROM ----------------
        1 -> {
            Panel("SLOT AND BACKUP", true, R.drawable.b_slot, gRom, true) {
                SlotButtons(vm, fb, true)
                Field(bp, { bp = it }, "Partition to back up")
                Btn("BACKUP", fb && bp.isNotBlank(), compact = true) { vm.backup(bp) }
            }
            Panel("RECOVERY IMAGE", true, R.drawable.b_image, gRom, true) {
                Field(recPart, { recPart = it }, "Target partition")
                FilePick("CHOOSE RECOVERY IMAGE", rec) { rec = it; recHash = "" }
                Field(recHash, { recHash = it }, hashLabel)
                Rw {
                    Btn("VERIFY RECOVERY IMAGE", !vm.busy && rec != null && recHash.isNotBlank(), mod = Modifier.weight(1f), compact = true) { vm.verifyStandaloneImage(rec!!, recHash) }
                    ConfirmBtn("FLASH RECOVERY", "Flash this verified image to '$recPart'?", fb && rec != null && vm.isImageVerified(rec) && vm.safetyWarningsAcknowledged, mod = Modifier.weight(1f), compact = true) { vm.flashOne(recPart, rec!!) }
                }
                Verdict(vm.isImageVerified(rec))
            }
            Panel("WIPE AND BOOT RECOVERY", true, R.drawable.b_recovery, gRom, true) {
                Rw {
                    ConfirmBtn("WIPE USERDATA (optional)", "Erase userdata and metadata on the connected phone?", fb, mod = Modifier.weight(1f), compact = true) { vm.wipe() }
                    Btn("REBOOT TO RECOVERY", fb, mod = Modifier.weight(1f), compact = true) { vm.fbCmd("reboot-recovery") }
                }
            }
            Panel("ROM ZIP (SIDELOAD)", true, R.drawable.b_upload, gRom, true) {
                T("Experimental. The phone must show the recovery's ADB sideload screen.", C.amber, 11)
                FilePick("CHOOSE ROM ZIP", rom) { rom = it; romHash = "" }
                Field(romHash, { romHash = it }, hashLabel)
                Btn("SIDELOAD ROM", adb && rom != null && romHash.matches(hex64), compact = true) { vm.sideload(rom!!, romHash) }
            }
            Panel("EXTRA ZIP (GAPPS, ADD-ONS)", false, R.drawable.b_zip, gRom, true) {
                T("Experimental. Start 'Apply update from ADB' again before each ZIP.", C.amber, 11)
                FilePick("CHOOSE EXTRA ZIP", extra) { extra = it; extraHash = "" }
                Field(extraHash, { extraHash = it }, hashLabel)
                Btn("SIDELOAD EXTRA", adb && extra != null && extraHash.matches(hex64), compact = true) { vm.sideload(extra!!, extraHash) }
            }
            Panel("GOOD TO KNOW", false, R.drawable.b_shield, gRom, true) {
                NoteTable(listOf(
                    "Order" to "Slot, backup, recovery, wipe, boot recovery, ROM ZIP, extra ZIP.",
                    "Needs" to "Unlocked bootloader, data cable, charged phones, and the publisher SHA-256 of every file.",
                    "A/B phones" to "The recovery may live in boot or vendor_boot. Set the partition name in Recovery image.",
                    "On the phone" to "Choose Apply update, then Apply update from ADB. The app switches to ADB mode when it sees the recovery.",
                    "Extra ZIPs" to "Each package is checksum-verified on its own. Finish with Reboot system now on the phone.",
                    "Sideload" to "Not hardware-tested. Check package compatibility using the OEM's instructions.",
                    "Backup" to "Also back up boot (or init_boot) before rooting."
                ), gRom)
            }
        }

        // ---------------- ROOT ----------------
        else -> {
            Panel("PATCHED BOOT IMAGE", true, R.drawable.b_bolt, gRoot, true) {
                T("Patch the stock boot (or init_boot) image with Magisk first.", C.amber, 11)
                Field(bootPart, { bootPart = it }, "Target partition (boot or init_boot)")
                FilePick("CHOOSE PATCHED IMAGE", boot) { boot = it; bootHash = "" }
                Field(bootHash, { bootHash = it }, hashLabel)
                Rw {
                    Btn("VERIFY PATCHED IMAGE", !vm.busy && boot != null && bootHash.isNotBlank(), mod = Modifier.weight(1f), compact = true) { vm.verifyStandaloneImage(boot!!, bootHash) }
                    ConfirmBtn("FLASH PATCHED IMAGE", "Flash this verified image to '$bootPart'?", fb && boot != null && vm.isImageVerified(boot) && vm.safetyWarningsAcknowledged, mod = Modifier.weight(1f), compact = true) { vm.flashOne(bootPart, boot!!) }
                }
                Verdict(vm.isImageVerified(boot))
            }
            Panel("REBOOT AND CHECK", true, R.drawable.b_power, gRoot, true) {
                Btn("REBOOT SYSTEM", fb, compact = true) { vm.fbCmd("reboot") }
            }
            Panel("GOOD TO KNOW", false, R.drawable.b_shield, gRoot, true) {
                NoteTable(listOf(
                    "Needs" to "Unlocked bootloader (see the status at the top).",
                    "Confirm root" to "After the reboot, open the Magisk app on the phone.",
                    "Vbmeta" to "Not flashed by this app. Verified Boot is never switched off silently.",
                    "Backup" to "Back up boot (or init_boot) first, on the ROM tab."
                ), gRoot)
            }
        }
    }
}

@Composable
fun LogPage(vm: MainVM) {
    Panel("DEVICE DATABASE (${vm.dbInfo})", false) {
        Field(vm.dbUrl, { vm.dbUrl = it }, "Raw GitHub URL of devices.json")
        Btn("UPDATE DATABASE", !vm.busy) { vm.updateDb(vm.dbUrl) }
    }
    Panel("USB LOG (${vm.logs.size})") {
        Rw {
            Btn("EXPORT", mod = Modifier.weight(1f)) { vm.exportLog() }
            Btn("CLEAR", mod = Modifier.weight(1f)) { vm.logs.clear() }
        }
        Spacer(Modifier.height(6.dp))
        vm.logs.toList().asReversed().forEach { T(it, C.text, 11, mod = Modifier.padding(vertical = 2.dp)) }
    }
}

@Composable
fun SafetyPage(vm: MainVM) {
    val battery = vm.safetyBatteryPercent()
    val storage = vm.fwDir().usableSpace
    val identityOk = vm.mode == Mode.FASTBOOT && vm.link == Link.GREEN && vm.product.isNotBlank() && vm.expected.isNotBlank() && vm.expected.equals(vm.product, true)
    val queueOk = vm.queue.isNotEmpty() && vm.queue.all { item ->
        item.part.matches(Regex("[A-Za-z0-9_]{1,48}")) && vm.verifiedFirmware[item.uri.toString() + "|" + item.size] != null
    }
    val effectiveStatus = if (!identityOk || battery == null || battery < AppSettings.minBattery) "BLOCKED" else vm.analyzerStatus
    val statusColor = when (effectiveStatus) {
        "PASS" -> C.green
        "BLOCKED" -> C.red
        else -> C.amber
    }
    Panel("PRE-FLASH SAFETY ANALYZER") {
        T(effectiveStatus, statusColor, 18, true)
        T(vm.analyzerMessage, C.dim, 11)
        T("This analyzer is also invoked automatically inside every image-flash transport path. Opening this page is not a substitute for the mandatory gate.", C.amber, 11)
    }
    Panel("DEVICE IDENTITY", false) {
        KV("Connection", if (vm.link == Link.GREEN) "Stable" else vm.linkNote)
        KV("Mode", vm.mode.label)
        KV("Detected product ID", vm.product.ifBlank { "Unavailable" })
        KV("Expected product ID", vm.expected.ifBlank { "Not confirmed" })
        KV("Model / codename", vm.modelName.ifBlank { "Unavailable" })
        KV("Active slot", vm.slot)
        KV("A/B partitions", if (vm.isAB) "Yes" else if (vm.mode == Mode.FASTBOOT) "No / unknown" else "Unavailable")
        KV("Fastbootd", if (vm.userspace) "Yes" else if (vm.mode == Mode.FASTBOOT) "No / unknown" else "Unavailable")
        Btn("USE DETECTED PRODUCT ID (CONFIRM)", vm.mode == Mode.FASTBOOT && vm.product.isNotBlank() && !vm.busy) { vm.adoptDetectedProduct() }
    }
    Panel("FIRMWARE AND PARTITION", false) {
        KV("Flash queue", if (vm.queue.isEmpty()) "No queued images" else "${vm.queue.size} image(s)")
        KV("Queue SHA-256", if (queueOk) "Verified for queued items" else if (vm.queue.isEmpty()) "Standalone image paths verify separately" else "Missing / not verified")
        vm.queue.forEach { item ->
            T("${item.name} → ${item.part.ifBlank { "PARTITION NOT SELECTED" }} (${item.size} bytes)", C.text, 11)
            T(if (vm.verifiedFirmware[item.uri.toString() + "|" + item.size] != null) "Publisher checksum matched; file is re-hashed before transfer" else "BLOCKED: publisher checksum verification required", if (vm.verifiedFirmware[item.uri.toString() + "|" + item.size] != null) C.green else C.red, 10)
        }
        T("Every image needs an explicit partition. Slot, logical/physical type and actual partition capacity are queried again from the bootloader immediately before transfer.", C.amber, 11)
    }
    Panel("CONTROLLER PHONE HEALTH", false) {
        KV("Controller phone battery", battery?.let { "$it%" } ?: "Unavailable")
        KV("Minimum threshold", "${AppSettings.minBattery}% (never below ${AppSettings.MIN_BATTERY_FLOOR}%)")
        KV("Firmware storage free", "${storage / (1024 * 1024)} MB")
        T("This battery value belongs to the FlashForge controller phone, not the connected target phone. Target battery is not assumed.", C.dim, 10)
        if (battery == null || battery < AppSettings.minBattery) T("BLOCKED: controller battery is unavailable or below ${AppSettings.minBattery}%.", C.red, 11, true)
    }
    Panel("WARNINGS — REVIEW BEFORE FLASHING") {
        vm.analyzerWarnings.forEach { T("• $it", C.amber, 11, mod = Modifier.padding(vertical = 3.dp)) }
        T(if (vm.safetyWarningsAcknowledged) "Warnings acknowledged for this connected-device session. They remain visible and the result remains WARNING." else "Warnings are not treated as PASS. Explicit acknowledgement is required before the first image write in this session.", C.dim, 11)
        Rw {
            Btn(if (vm.safetyWarningsAcknowledged) "WARNINGS ACKNOWLEDGED" else "ACKNOWLEDGE WARNINGS", !vm.busy, mod = Modifier.weight(1f)) { vm.acknowledgeSafetyWarnings() }
            Btn("CLEAR ACK", !vm.busy, mod = Modifier.weight(1f)) { vm.clearSafetyWarningAcknowledgement() }
        }
    }
    Panel("LAST ANALYZER CHECKS", false) {
        if (vm.analyzerChecks.isEmpty()) T("No image preflight has run in this session yet. The first flash attempt will run it automatically.", C.dim, 11)
        vm.analyzerChecks.forEach { T(it, if (it.startsWith("PASS")) C.green else if (it.startsWith("BLOCKED")) C.red else C.amber, 10, mod = Modifier.padding(vertical = 2.dp)) }
    }
    Panel("USB AND RECOVERY", false) {
        KV("USB state", vm.link.label)
        T("If USB disconnects or a transfer fails: do not retry automatically. Reconnect and identify the device again, inspect its current screen/mode and the operation log, then follow the OEM recovery procedure. Interrupted partition writes are not resumed by this app.", C.dim, 11)
    }
    Panel("SAFETY DECISION") {
        T(when (effectiveStatus) {
            "PASS" -> "PASS — implemented pre-flash checks passed"
            "BLOCKED" -> "BLOCKED — DO NOT FLASH"
            else -> "WARNING — REVIEW AND ACKNOWLEDGE; WARNINGS REMAIN"
        }, statusColor, 14, true)
        T("A PASS is not a guarantee against unknown hardware, firmware, or vendor-specific risks. A WARNING never becomes a silent PASS.", C.dim, 11)
        Btn("OPEN FLASH QUEUE", true) { vm.screen = Screen.FLASH }
    }
}
