package com.flashforge

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val ForgeNavy = Color(0xFF100B2B)
private val ForgePanel = Color(0xFF150B5C)
private val ForgeViolet = Color(0xFF8B63FF)
private val ForgeCyan = Color(0xFF7FDCFF)

@Composable
fun GamingHeader(vm: MainVM, onSettings: () -> Unit, onAbout: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(54.dp).shadow(12.dp, RoundedCornerShape(16.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF59D3FF), Color(0xFF5B3DFF), Color(0xFFB04DFF))), RoundedCornerShape(16.dp))
                .border(1.dp, Color.White.copy(alpha = .65f), RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) { Image(painterResource(R.drawable.ic_logo), null, Modifier.size(39.dp)) }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("FlashForge", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, letterSpacing = (-.5).sp)
            Text(
                if (vm.mode == Mode.NONE) "ANDROID FLASH TOOLKIT" else "${vm.mode.label}  •  ${vm.link.label}",
                color = Color(0xFFDFE6FF), fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1
            )
        }
        ConnectionLed(vm)
        Spacer(Modifier.width(6.dp))
        RoundHeaderButton(R.drawable.ic_gear, "Settings", onSettings)
        Spacer(Modifier.width(5.dp))
        Box(
            Modifier.size(40.dp).background(Brush.radialGradient(listOf(Color(0xFF8A6BFF), Color(0xFF3A22B5))), CircleShape)
                .border(1.5.dp, Color(0xFFA99BFF), CircleShape).clickable(onClick = onAbout),
            contentAlignment = Alignment.Center
        ) { Text("i", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold) }
    }
}

@Composable
private fun ConnectionLed(vm: MainVM) {
    // Reuses the live USB link state from MainVM; this is a visual indicator, not a second detector.
    val tint = when (vm.link) {
        Link.RED -> Color(0xFFFF294F)
        Link.YELLOW -> Color(0xFFFFD43B)
        Link.GREEN -> Color(0xFF27F58A)
    }
    val transition = rememberInfiniteTransition(label = "connection-led")
    val pulse by transition.animateFloat(
        initialValue = .68f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), repeatMode = RepeatMode.Reverse),
        label = "led-pulse"
    )
    // Same 40dp header footprint as Settings/About; the actual lamp is deliberately compact.
    // The color is driven only by MainVM's real USB connection state (never a simulated status).
    Box(Modifier.size(40.dp), contentAlignment = Alignment.Center) {
        Box(
            Modifier.size(23.dp)
                .shadow(4.dp, CircleShape)
                .background(Brush.radialGradient(listOf(Color(0xFF6D668E), Color(0xFF29223E), Color(0xFF100B22))), CircleShape)
                .border(1.dp, Brush.linearGradient(listOf(Color(0xFFD8D1F5), Color(0xFF625987), Color(0xFF241C43))), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier.size(9.dp)
                    .shadow(4.dp, CircleShape)
                    .background(Brush.radialGradient(listOf(Color.White.copy(alpha = .92f), tint.copy(alpha = pulse), tint.copy(alpha = .78f))), CircleShape)
                    .border(.7.dp, Color.White.copy(alpha = .85f), CircleShape)
            )
        }
    }
}

@Composable
private fun RoundHeaderButton(icon: Int, description: String, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).background(Brush.radialGradient(listOf(Color(0xFF8A6BFF), Color(0xFF3A22B5))), CircleShape)
            .border(1.5.dp, Color(0xFFA99BFF), CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Image(painterResource(icon), description, Modifier.size(23.dp)) }
}

@Composable
fun GamingTabs(screen: Screen, onSelect: (Screen) -> Unit) {
    val tabs = listOf(
        Triple(Screen.DEVICE, "DEVICE", R.drawable.ic_phone),
        Triple(Screen.FLASH, "FLASH", R.drawable.ic_chip_electric),
        Triple(Screen.ROM, "ROM & ROOT", R.drawable.ic_lock),
        Triple(Screen.LOG, "LOG", R.drawable.ic_export),
        Triple(Screen.SAFETY, "SAFETY", R.drawable.ic_shield)
    )
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp).background(
            Brush.verticalGradient(listOf(Color(0xFF1C1170), Color(0xFF120A4F))), RoundedCornerShape(20.dp)
        ).border(2.dp, Color(0xFF7D6CFF), RoundedCornerShape(20.dp)).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        tabs.forEach { (target, label, icon) ->
            val active = screen == target
            Column(
                Modifier.weight(1f).height(50.dp)
                    .background(
                        if (active) Brush.verticalGradient(listOf(Color(0xFFB26BFF), Color(0xFF6A38E8), Color(0xFF4A28C4)))
                        else Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent)), RoundedCornerShape(15.dp)
                    )
                    .then(if (active) Modifier.border(1.2.dp, Color(0xFFE0D0FF), RoundedCornerShape(15.dp)) else Modifier)
                    .clickable { onSelect(target) }.padding(horizontal = 2.dp, vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                Image(painterResource(icon), null, Modifier.size(21.dp))
                Text(label, color = Color.White, fontSize = 9.sp, lineHeight = 10.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, textAlign = TextAlign.Center)
            }
        }
    }
}

private fun wheelItems(screen: Screen): Pair<List<WheelItem>, WheelItem> = when (screen) {
    Screen.DEVICE -> listOf(
        WheelItem("EDL", R.drawable.ic_chip_electric), WheelItem("BROM", R.drawable.ic_chip_bolt),
        WheelItem("DOWNLOAD", R.drawable.ic_download_drive), WheelItem("FASTBOOT", R.drawable.ic_terminal)
    ) to WheelItem("RESTART", R.drawable.ic_sync)
    Screen.FLASH -> listOf(
        WheelItem("ADD IMAGE", R.drawable.ic_add_image), WheelItem("UNPACK ZIP", R.drawable.ic_zip),
        WheelItem("SAFETY CHECK", R.drawable.ic_shield), WheelItem("FLASH QUEUE", R.drawable.ic_stack)
    ) to WheelItem("FLASH FIRMWARE", R.drawable.ic_download_tray)
    Screen.ROM -> listOf(
        WheelItem("ROOT", R.drawable.ic_joystick), WheelItem("BACKUP", R.drawable.ic_save),
        WheelItem("RESTORE", R.drawable.ic_upload), WheelItem("RECOVERY", R.drawable.ic_rescue)
    ) to WheelItem("UNLOCK BL", R.drawable.ic_unlock)
    else -> listOf(
        WheelItem("SAVE LOG", R.drawable.ic_save), WheelItem("COPY", R.drawable.ic_export),
        WheelItem("FILTER", R.drawable.ic_verify), WheelItem("EXPORT", R.drawable.ic_upload_slab)
    ) to WheelItem("CLEAR", R.drawable.ic_trash)
}

@Composable
fun GamingActionStage(
    vm: MainVM,
    screen: Screen,
    onItem: (Int) -> Unit,
    onHub: () -> Unit,
    onPanelAction: () -> Unit
) {
    val (items, hub) = wheelItems(screen)
    BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 5.dp)) {
        val wheelSize = (maxWidth - 20.dp).coerceAtMost(400.dp)
        Box(Modifier.fillMaxWidth().height(wheelSize + 23.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth(.92f).height(wheelSize * .16f)
                    .offset(y = (-2).dp)
                    .background(Brush.radialGradient(listOf(Color(0x888F7BFF), Color(0x883B24B4), Color(0x00150A55))), CircleShape)
                    .border(2.dp, ForgeCyan.copy(alpha = .9f), CircleShape)
            )
            WheelMenu(items, hub, Modifier.size(wheelSize), onItem = onItem, onHub = onHub)
        }
        Spacer(Modifier.height(3.dp))
        val (title, body, button, tint) = when (screen) {
            Screen.DEVICE -> Quad("DEVICE STATUS", if (vm.device == null) "Connect a phone by USB to identify its boot mode and device information." else "${vm.vendor.ifBlank { "USB device" }} • ${vm.mode.label}\n${vm.product.ifBlank { vm.usbId }}", "DETAILS", Color(0xFF3DFF7A))
            Screen.FLASH -> Quad("FLASH INSTRUCTIONS", "Add an image, select its exact partition, verify the publisher SHA-256, then review the Safety Analyzer before flashing.", "FLASH NOW", Color(0xFF4FE0FF))
            Screen.ROM -> Quad("ROM & ROOT TOOLS", "Manage bootloader, backup, recovery, ROM sideload and patched boot operations. Destructive actions still require confirmation.", "OPEN UNLOCK", Color(0xFFC7A1FF))
            else -> Quad("USB EVENT LOG", "${vm.logs.size} event(s) recorded. Export or copy the current log; clearing requires confirmation.", "EXPORT LOG", Color(0xFF4FE0FF))
        }
        Row(
            Modifier.fillMaxWidth().height(150.dp)
                .background(Brush.verticalGradient(listOf(Color(0xFF150B5C), Color(0xFF0C0640))), RoundedCornerShape(20.dp))
                .border(2.dp, Color(0xFF8F86FF), RoundedCornerShape(20.dp)).padding(11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(42.dp).background(Brush.radialGradient(listOf(tint, tint.copy(alpha = .35f))), CircleShape), contentAlignment = Alignment.Center) {
                Text("✓", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = tint, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                Text(body, color = Color(0xFFE6E9FF), fontSize = 10.sp, lineHeight = 13.sp, maxLines = 4)
            }
            Spacer(Modifier.width(7.dp))
            Box(
                Modifier.background(
                    if (screen == Screen.ROM) Brush.verticalGradient(listOf(Color(0xFFB26BFF), Color(0xFF6A38E8), Color(0xFF4A28C4)))
                    else Brush.verticalGradient(listOf(Color(0xFF58A8FF), Color(0xFF2563FF), Color(0xFF1B3FD0))), RoundedCornerShape(50)
                ).border(1.5.dp, Color.White.copy(alpha = .75f), RoundedCornerShape(50)).clickable(onClick = onPanelAction).padding(horizontal = 10.dp, vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) { Text(button, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1) }
        }
    }
}

private data class Quad(val title: String, val body: String, val button: String, val tint: Color)

@Composable
fun GamingConfirmDialog(action: String?, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    if (action == null) return
    val (title, message) = when (action) {
        "restart" -> "RESTART SYSTEM" to "Restart the connected phone into Android system?"
        "mode_edl" -> "ENTER EDL MODE" to "Send the EDL reboot command to the connected device? EDL availability is model-specific."
        "mode_brom" -> "ENTER BROM MODE" to "Request MediaTek BROM mode from recovery ADB where supported?"
        "mode_download" -> "ENTER DOWNLOAD MODE" to "Request Samsung Download mode from recovery ADB where supported?"
        "mode_fastboot" -> "ENTER FASTBOOT" to "Reboot the connected phone into bootloader Fastboot mode?"
        "flash" -> "FLASH SELECTED QUEUE" to "Start the selected flash queue? The app will still enforce image verification, device identity, partition and Safety Analyzer checks."
        "clear" -> "CLEAR EVENT LOG" to "Permanently clear the event log stored in this app?"
        else -> "OPEN UNLOCK CONTROLS" to "Open the bootloader controls. Unlocking itself will still require the existing in-app confirmation."
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.ExtraBold) },
        text = { Text(message) },
        confirmButton = { TextButton(onClick = onConfirm) { Text("CONFIRM", color = Color(0xFF48DFFF), fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("CANCEL", color = Color.Gray) } },
        containerColor = ForgePanel, titleContentColor = Color.White, textContentColor = Color(0xFFE6E9FF),
        shape = RoundedCornerShape(22.dp)
    )
}
