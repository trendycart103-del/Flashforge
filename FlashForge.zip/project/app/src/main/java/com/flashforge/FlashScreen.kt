package com.flashforge

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** How the file area of the flash screen is laid out. Each layout follows the idea of that maker's own flash tool. */
enum class FlashLayout { TABLE, SLOTS, STEPS, STATUSBOX, RING, SPFT, CONSOLE, TIMELINE }

/** Shape and motion of the animated top icon. */
enum class IconKind { TILE, RING, FRAME, DIAMOND, HEX, BARS, BOLT, CHIP, TERMINAL, DOUBLE, DISC, PLAIN }

/** One flash screen design per phone company. Artwork and wording are original, in the spirit of each company's own tool. */
enum class FlashBrand(
    val chip: String,
    val tool: String,
    val layout: FlashLayout,
    val icon: IconKind,
    val dark: Boolean,
    val accent: Color,
    val accent2: Color,
    val bg1: Color,
    val bg2: Color,
    val waitWord: String,
    val runWord: String,
    val okWord: String,
    val failWord: String,
    val hint: String
) {
    XIAOMI("Xiaomi", "MIUI FLASH", FlashLayout.TABLE, IconKind.TILE, false,
        Color(0xFFFF6900), Color(0xFFFFB074), Color(0xFFFFF7F0), Color(0xFFFFE2CC),
        "ready", "flashing", "success", "failed", "Table view like MiFlash: one row and one bar per image."),
    SAMSUNG("Samsung", "ODIN FLASH", FlashLayout.SLOTS, IconKind.RING, true,
        Color(0xFF2F6BFF), Color(0xFF8FB4FF), Color(0xFF0B1226), Color(0xFF16254F),
        "Added!!", "Flashing...", "PASS!", "FAIL!", "Slot view like Odin: every file has its own slot."),
    GOOGLE("Google", "ANDROID FLASH TOOL", FlashLayout.STEPS, IconKind.FRAME, false,
        Color(0xFF1A73E8), Color(0xFF8AB4F8), Color(0xFFFFFFFF), Color(0xFFE8F0FE),
        "waiting", "in progress", "complete", "failed", "Step cards like Android Flash Tool."),
    ONEPLUS("OnePlus", "MSM DOWNLOAD", FlashLayout.STATUSBOX, IconKind.DIAMOND, true,
        Color(0xFFEB0028), Color(0xFFFF7A8A), Color(0xFF101010), Color(0xFF2A1014),
        "Waiting", "Downloading", "Download OK", "Download fail", "Big status box like the MSM download tool."),
    OPPO("OPPO", "OPPO FLASH", FlashLayout.RING, IconKind.HEX, true,
        Color(0xFF1BA97B), Color(0xFF8FE3C4), Color(0xFF06201A), Color(0xFF0E3A2E),
        "wait", "flashing", "finished", "error", "Big percentage ring while OPPO and Realme images write."),
    VIVO("Vivo", "VIVO FLASH", FlashLayout.TIMELINE, IconKind.BARS, false,
        Color(0xFF415FFF), Color(0xFF9AAAFF), Color(0xFFF3F5FF), Color(0xFFDDE3FF),
        "pending", "writing", "complete", "failed", "Timeline view: each image is a stop on the line."),
    INFINIX("Infinix", "INFINIX FLASH", FlashLayout.SPFT, IconKind.BOLT, true,
        Color(0xFF2DBE60), Color(0xFF9BE3B4), Color(0xFF0A1A10), Color(0xFF12301D),
        "Waiting", "Downloading", "Download OK", "Download fail", "Big bar and status circle like the MediaTek SP Flash Tool."),
    TECNO("Tecno", "TECNO FLASH", FlashLayout.SPFT, IconKind.CHIP, true,
        Color(0xFF0A6CFF), Color(0xFF7FB2FF), Color(0xFF081428), Color(0xFF0F2748),
        "Waiting", "Downloading", "Download OK", "Download fail", "Chip-style header with the MediaTek status circle."),
    WALTON("Walton", "WALTON SERVICE", FlashLayout.CONSOLE, IconKind.TERMINAL, true,
        Color(0xFF39D353), Color(0xFF9BE9A8), Color(0xFF03140A), Color(0xFF0B2A14),
        "queued", "writing", "done", "failed", "Service console view: green terminal lines."),
    MOTOROLA("Motorola", "RESCUE ASSISTANT", FlashLayout.STEPS, IconKind.DOUBLE, true,
        Color(0xFF00B4D8), Color(0xFF90E0EF), Color(0xFF06161C), Color(0xFF0C2B36),
        "waiting", "recovering", "recovered", "failed", "Wizard steps like Rescue and Smart Assistant."),
    SONY("Sony", "XPERIA FLASH", FlashLayout.SLOTS, IconKind.DISC, true,
        Color(0xFFE6E6E6), Color(0xFFFFFFFF), Color(0xFF000000), Color(0xFF1A1A1A),
        "ready", "flashing", "finished", "failed", "Monochrome slot list in the style of Xperia flash tools."),
    HUAWEI("Huawei", "HUAWEI RECOVERY", FlashLayout.TABLE, IconKind.DISC, false,
        Color(0xFFCF0A2C), Color(0xFFF2828F), Color(0xFFFFF5F6), Color(0xFFFFE0E4),
        "pending", "recovering", "recovered", "failed", "Recovery table in the style of Huawei service tools."),
    GENERIC("Other", "FASTBOOT FLASH", FlashLayout.CONSOLE, IconKind.PLAIN, true,
        Color(0xFFFFA726), Color(0xFFFFD28A), Color(0xFF12141A), Color(0xFF242836),
        "queued", "flashing", "done", "failed", "Fastboot console view for every other brand.");

    val ink: Color get() = if (dark) Color(0xFFEAF0FF) else Color(0xFF2B1A0E)
    val sub: Color get() = if (dark) Color(0xFF9AA8CC) else Color(0xFF8A6A52)
    val phone: Color get() = if (this == SONY) Color(0xFF111111) else Color.White
    val glassTop: Color get() = if (dark) Color.White.copy(alpha = 0.16f) else Color.White.copy(alpha = 0.80f)
    val glassBottom: Color get() = if (dark) Color.White.copy(alpha = 0.05f) else Color.White.copy(alpha = 0.45f)
    val glassEdge: Color get() = if (dark) Color.White.copy(alpha = 0.35f) else accent.copy(alpha = 0.45f)
}

/** Chooses the flash screen design: the user's pick if there is one, otherwise from the detected phone. */
fun flashBrandOf(vm: MainVM): FlashBrand {
    val picked = vm.brandOverride
    if (picked.isNotBlank()) {
        FlashBrand.values().firstOrNull { it.name == picked }?.let { return it }
    }
    val b = (vm.brandName() + " " + vm.vendor + " " + vm.modelName + " " + vm.product).lowercase()
    fun has(vararg k: String) = k.any { b.contains(it) }
    return when {
        vm.mode == Mode.SAMSUNG_DOWNLOAD || has("samsung") -> FlashBrand.SAMSUNG
        has("xiaomi", "redmi", "poco", "miui", "hyperos") -> FlashBrand.XIAOMI
        has("oneplus") -> FlashBrand.ONEPLUS
        has("oppo", "realme") -> FlashBrand.OPPO
        has("vivo", "iqoo") -> FlashBrand.VIVO
        has("infinix") -> FlashBrand.INFINIX
        has("tecno", "itel") -> FlashBrand.TECNO
        has("walton", "primo") -> FlashBrand.WALTON
        has("motorola", "moto") -> FlashBrand.MOTOROLA
        has("sony", "xperia") -> FlashBrand.SONY
        has("huawei", "honor") -> FlashBrand.HUAWEI
        has("google", "pixel") -> FlashBrand.GOOGLE
        else -> FlashBrand.GENERIC
    }
}

private enum class RowState { PENDING, RUNNING, DONE, FAILED, STOPPED }

private fun stateOf(i: Int, idx: Int, out: Int): RowState = when {
    out == 1 -> RowState.DONE
    i < idx -> RowState.DONE
    i == idx -> if (out == 2) RowState.FAILED else RowState.RUNNING
    out == 2 -> RowState.STOPPED
    else -> RowState.PENDING
}

private fun wordOf(b: FlashBrand, st: RowState): String = when (st) {
    RowState.PENDING -> b.waitWord
    RowState.RUNNING -> b.runWord
    RowState.DONE -> b.okWord
    RowState.FAILED -> b.failWord
    RowState.STOPPED -> "not flashed"
}

private fun colorOf(b: FlashBrand, st: RowState): Color = when (st) {
    RowState.DONE -> Color(0xFF1FA463)
    RowState.FAILED -> Color(0xFFE5334D)
    RowState.RUNNING -> b.accent
    else -> b.sub
}

/** Animated top icon: a phone being flashed, with a backdrop and motion that differ per company. */
@Composable
fun FlashHeroIcon(brand: FlashBrand, iconSize: Dp, running: Boolean, modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "hero")
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "heroT")
    val pulse by inf.animateFloat(0.6f, 1f, infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "heroPulse")
    val tt = if (running) t else 0f
    val pp = if (running) pulse else 1f
    Canvas(modifier.size(iconSize)) {
        val s = size.minDimension
        val c = Offset(size.width / 2f, size.height / 2f)
        val acc = brand.accent
        when (brand.icon) {
            IconKind.TILE -> {
                drawRoundRect(acc, Offset.Zero, Size(s, s), CornerRadius(s * 0.32f))
                drawRoundRect(Color.White.copy(alpha = 0.22f * pp), Offset(s * 0.06f, s * 0.06f), Size(s * 0.88f, s * 0.88f), CornerRadius(s * 0.27f))
            }
            IconKind.RING -> {
                drawCircle(brand.bg2, radius = s * 0.5f, center = c)
                val ring = Stroke(width = s * 0.06f, cap = StrokeCap.Round)
                val tl = Offset(s * 0.08f, s * 0.08f)
                val sz = Size(s * 0.84f, s * 0.84f)
                drawArc(acc, tt * 360f, 110f, false, tl, sz, style = ring)
                drawArc(brand.accent2, tt * 360f + 180f, 110f, false, tl, sz, style = ring)
            }
            IconKind.FRAME -> {
                drawRoundRect(acc, Offset.Zero, Size(s, s), CornerRadius(s * 0.12f))
                drawRoundRect(Color.White.copy(alpha = 0.55f * pp), Offset(s * 0.07f, s * 0.07f), Size(s * 0.86f, s * 0.86f), CornerRadius(s * 0.08f), style = Stroke(width = s * 0.03f))
            }
            IconKind.DIAMOND -> {
                val p = Path().apply {
                    moveTo(c.x, s * 0.01f); lineTo(s * 0.99f, c.y); lineTo(c.x, s * 0.99f); lineTo(s * 0.01f, c.y); close()
                }
                drawPath(p, acc)
            }
            IconKind.HEX -> {
                val p = Path()
                for (k in 0 until 6) {
                    val a = (PI / 3.0 * k - PI / 2.0)
                    val x = c.x + (s * 0.5f * cos(a)).toFloat()
                    val y = c.y + (s * 0.5f * sin(a)).toFloat()
                    if (k == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
                drawPath(p, acc)
            }
            IconKind.BARS -> {
                drawCircle(acc, radius = s * 0.5f, center = c)
                drawCircle(Color.White.copy(alpha = 0.35f * (1.2f - pp)), radius = s * 0.5f * pp, center = c, style = Stroke(width = s * 0.03f))
            }
            IconKind.BOLT -> {
                drawRoundRect(acc, Offset.Zero, Size(s, s), CornerRadius(s * 0.22f))
                val p = Path().apply {
                    moveTo(s * 0.80f, s * 0.06f); lineTo(s * 0.64f, s * 0.24f); lineTo(s * 0.74f, s * 0.24f)
                    lineTo(s * 0.62f, s * 0.42f); lineTo(s * 0.90f, s * 0.20f); lineTo(s * 0.78f, s * 0.20f); close()
                }
                drawPath(p, Color.White.copy(alpha = 0.8f * pp))
            }
            IconKind.CHIP -> {
                drawRoundRect(brand.bg2, Offset(s * 0.08f, s * 0.08f), Size(s * 0.84f, s * 0.84f), CornerRadius(s * 0.1f))
                drawRoundRect(acc, Offset(s * 0.08f, s * 0.08f), Size(s * 0.84f, s * 0.84f), CornerRadius(s * 0.1f), style = Stroke(width = s * 0.04f))
                for (k in 0 until 4) {
                    val f = s * (0.24f + k * 0.17f)
                    drawLine(acc, Offset(0f, f), Offset(s * 0.08f, f), s * 0.035f, StrokeCap.Round)
                    drawLine(acc, Offset(s * 0.92f, f), Offset(s, f), s * 0.035f, StrokeCap.Round)
                    drawLine(acc, Offset(f, 0f), Offset(f, s * 0.08f), s * 0.035f, StrokeCap.Round)
                    drawLine(acc, Offset(f, s * 0.92f), Offset(f, s), s * 0.035f, StrokeCap.Round)
                }
            }
            IconKind.TERMINAL -> {
                drawRoundRect(brand.bg1, Offset.Zero, Size(s, s), CornerRadius(s * 0.1f))
                drawRoundRect(acc, Offset.Zero, Size(s, s), CornerRadius(s * 0.1f), style = Stroke(width = s * 0.04f))
                val p = Path().apply { moveTo(s * 0.10f, s * 0.12f); lineTo(s * 0.20f, s * 0.19f); lineTo(s * 0.10f, s * 0.26f) }
                drawPath(p, brand.accent2.copy(alpha = pp), style = Stroke(width = s * 0.035f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            IconKind.DOUBLE -> {
                drawCircle(acc, radius = s * 0.5f, center = c)
                drawCircle(Color.White.copy(alpha = 0.5f * pp), radius = s * 0.43f, center = c, style = Stroke(width = s * 0.03f))
            }
            IconKind.DISC -> drawCircle(acc, radius = s * 0.5f, center = c)
            IconKind.PLAIN -> {
                drawRoundRect(brand.bg2, Offset.Zero, Size(s, s), CornerRadius(s * 0.2f))
                drawRoundRect(acc.copy(alpha = pp), Offset(s * 0.04f, s * 0.04f), Size(s * 0.92f, s * 0.92f), CornerRadius(s * 0.17f), style = Stroke(width = s * 0.04f))
            }
        }
        val pw = s * 0.34f
        val ph = s * 0.58f
        val px = c.x - pw / 2f
        val py = c.y - ph / 2f
        val ink = brand.phone
        drawRoundRect(ink, Offset(px, py), Size(pw, ph), CornerRadius(s * 0.07f), style = Stroke(width = s * 0.04f))
        drawLine(ink, Offset(c.x - pw * 0.16f, py + ph * 0.08f), Offset(c.x + pw * 0.16f, py + ph * 0.08f), s * 0.025f, StrokeCap.Round)
        for (k in 0 until 3) {
            val f = (tt + k / 3f) % 1f
            val y = py + ph * 0.80f - f * ph * 0.58f
            val a = sin(f * PI).toFloat().coerceIn(0f, 1f)
            val path = Path().apply {
                moveTo(c.x - pw * 0.24f, y + s * 0.03f)
                lineTo(c.x, y - s * 0.03f)
                lineTo(c.x + pw * 0.24f, y + s * 0.03f)
            }
            drawPath(path, ink.copy(alpha = if (running) a else 0.5f), style = Stroke(width = s * 0.04f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

/** Cross button that switches one queue file off (skip) and a check button that switches it on again. */
@Composable
fun SlotToggle(on: Boolean, enabled: Boolean, brand: FlashBrand, onClick: () -> Unit) {
    val red = Color(0xFFE5334D)
    val edge = if (on) red else brand.accent
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(38.dp).clip(CircleShape)
                .background(edge.copy(alpha = 0.14f), CircleShape)
                .border(1.5.dp, edge, CircleShape)
                .clickable(enabled = enabled) { onClick() },
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.size(14.dp)) {
                val w = size.width
                val h = size.height
                val sw = 2.6.dp.toPx()
                if (on) {
                    drawLine(edge, Offset(0f, 0f), Offset(w, h), sw, StrokeCap.Round)
                    drawLine(edge, Offset(w, 0f), Offset(0f, h), sw, StrokeCap.Round)
                } else {
                    val p = Path().apply { moveTo(0f, h * 0.55f); lineTo(w * 0.38f, h); lineTo(w, 0f) }
                    drawPath(p, edge, style = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
            }
        }
        T(if (on) "SKIP" else "USE", edge, 9, true)
    }
}

@Composable
private fun StyleChip(label: String, selected: Boolean, brand: FlashBrand, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.clip(shape)
            .background(if (selected) brand.accent else Color.Transparent, shape)
            .border(1.dp, brand.accent, shape)
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        T(label, if (selected) brand.phone else brand.ink, 11, true)
    }
}

/** Header of the Flash tab: active design, selected file count, and a picker for the company style. */
@Composable
fun FlashToolBanner(vm: MainVM) {
    val brand = flashBrandOf(vm)
    val shape = RoundedCornerShape(24.dp)
    val selected = vm.queue.count { it.enabled }
    Box(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(shape)
            .background(Brush.horizontalGradient(listOf(brand.bg2, brand.bg1)), shape)
            .border(1.dp, brand.accent.copy(alpha = 0.5f), shape)
            .padding(12.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                FlashHeroIcon(brand, 52.dp, false)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    T(brand.tool, brand.ink, 14, true)
                    T(brand.hint, brand.sub, 11)
                    T("$selected of ${vm.queue.size} file(s) selected", brand.accent, 11, true)
                }
            }
            Spacer(Modifier.height(8.dp))
            T(if (vm.brandOverride.isBlank()) "Style: automatic from the detected phone. Tap a company to force its style." else "Style: chosen by you. Tap AUTO to detect from the phone.", brand.sub, 10)
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                StyleChip("AUTO", vm.brandOverride.isBlank(), brand) { if (!vm.busy) vm.chooseBrand("") }
                FlashBrand.values().forEach { b ->
                    StyleChip(b.chip, vm.brandOverride == b.name, brand) { if (!vm.busy) vm.chooseBrand(b.name) }
                }
            }
        }
    }
}

@Composable
private fun GlassBox(brand: FlashBrand, radius: Dp, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(radius)
    Column(
        Modifier.fillMaxWidth().clip(shape)
            .background(Brush.linearGradient(listOf(brand.glassTop, brand.glassBottom)), shape)
            .border(1.dp, brand.glassEdge, shape)
            .padding(12.dp),
        content = content
    )
}

@Composable
private fun Mono(s: String, c: Color, sz: Int = 11) {
    Text(s, color = c, fontSize = sz.sp, fontFamily = FontFamily.Monospace)
}

/** Full-screen flashing view: the flash screens double as the analyzer while an image is written. */
@Composable
fun FlashingScreen(vm: MainVM) {
    val brand = remember { flashBrandOf(vm) }
    val running = vm.busy && vm.flashOutcome == 0
    val plan = vm.flashPlan.toList()
    val total = plan.size
    val idx = vm.flashIndex
    val out = vm.flashOutcome
    val cur: QItem? = if (idx in plan.indices) plan[idx] else plan.lastOrNull()

    val overallRaw = when {
        out == 1 -> 1f
        total == 0 -> 0f
        else -> ((idx + (if (running) vm.progress else 0f)) / total).coerceIn(0f, 1f)
    }
    val overall by animateFloatAsState(overallRaw, tween(350), label = "overall")

    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(brand.bg1, brand.bg2)))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                FlashHeroIcon(brand, 84.dp, running)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    T(brand.tool, brand.ink, 18, true)
                    val sub = when {
                        out == 1 -> brand.okWord
                        out == 2 -> brand.failWord
                        total > 0 -> "${brand.runWord} ${minOf(idx + 1, total)} / $total"
                        else -> "analyzing..."
                    }
                    T(sub, if (out == 2) Color(0xFFE5334D) else brand.accent, 14, true)
                    T(vm.modelName.ifBlank { vm.product.ifBlank { "target phone" } }, brand.sub, 11)
                }
            }
            Spacer(Modifier.height(12.dp))

            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
                GlassStage(brand, cur, idx, total, out, running)
                Spacer(Modifier.height(12.dp))
                FileArea(vm, brand, plan, idx, out, overall)
                SkippedRows(vm, brand, plan)
                Spacer(Modifier.height(12.dp))
                AnalyzerCard(vm, brand)
            }

            Spacer(Modifier.height(10.dp))
            if (running) T("Keep the cable connected. Do not close the app.", Color(0xFFFFB300), 11, true)
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)) {
                Box(Modifier.weight(1f)) { BrandBar(brand, overall, running, 16.dp) }
                Spacer(Modifier.width(10.dp))
                T("${(overall * 100).toInt()}%", brand.ink, 13, true)
            }
            if (!vm.busy) {
                Btn(if (out == 1) "DONE" else "CLOSE", true, false, Modifier.fillMaxWidth()) { vm.closeFlashScreen() }
            }
        }
    }
}

@Composable
private fun BrandBar(brand: FlashBrand, progress: Float, running: Boolean, barHeight: Dp) {
    val inf = rememberInfiniteTransition(label = "brandbar")
    val phase by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(700, easing = LinearEasing)), label = "barPhase")
    Canvas(Modifier.fillMaxWidth().height(barHeight)) {
        val w = size.width
        val h = size.height
        val r = CornerRadius(h / 2f, h / 2f)
        drawRoundRect(if (brand.dark) Color.White.copy(alpha = 0.14f) else Color(0x22000000), Offset.Zero, Size(w, h), r)
        val fillW = (progress * w).coerceIn(0f, w)
        if (fillW > 1f) {
            drawRoundRect(
                Brush.horizontalGradient(listOf(brand.accent2, brand.accent), startX = 0f, endX = maxOf(fillW, 1f)),
                Offset.Zero, Size(fillW, h), r
            )
            if (running) {
                val sw = h * 1.4f
                var i = -2
                while (i * sw < fillW + sw) {
                    val x = i * sw + phase * sw
                    val x1 = x.coerceIn(0f, fillW)
                    val x2 = (x + sw * 0.4f).coerceIn(0f, fillW)
                    if (x2 > x1) drawRect(Color.White.copy(alpha = 0.22f), Offset(x1, 0f), Size(x2 - x1, h))
                    i++
                }
                drawCircle(Color.White, radius = h * 0.3f, center = Offset(fillW.coerceAtLeast(h / 2f), h / 2f))
            }
        }
    }
}

/** Glass panel with animated bubbles and the file that is being flashed right now. */
@Composable
private fun GlassStage(brand: FlashBrand, cur: QItem?, idx: Int, total: Int, out: Int, running: Boolean) {
    val shape = RoundedCornerShape(30.dp)
    val inf = rememberInfiniteTransition(label = "glass")
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "glassT")
    val sweep by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "glassSweep")
    val bob by inf.animateFloat(-5f, 5f, infiniteRepeatable(tween(1100), RepeatMode.Reverse), label = "glassBob")
    val bubbles = remember {
        val rnd = java.util.Random(7L)
        List(14) { floatArrayOf(rnd.nextFloat(), 0.012f + rnd.nextFloat() * 0.035f, 0.5f + rnd.nextFloat() * 0.9f, rnd.nextFloat()) }
    }
    Box(
        Modifier.fillMaxWidth().height(170.dp).clip(shape)
            .background(Brush.linearGradient(listOf(brand.glassTop, brand.glassBottom)), shape)
            .border(1.2.dp, brand.glassEdge, shape)
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            if (running) {
                bubbles.forEach { b ->
                    val f = (t * b[2] + b[3]) % 1f
                    val r = b[1] * w
                    val y = h + r - f * (h + r * 2f)
                    val x = b[0] * w + sin(f * 2f * PI).toFloat() * w * 0.03f
                    val a = sin(f * PI).toFloat().coerceIn(0f, 1f)
                    drawCircle(brand.accent.copy(alpha = 0.10f + 0.22f * a), r, Offset(x, y))
                    drawCircle(Color.White.copy(alpha = 0.35f * a), r * 0.28f, Offset(x - r * 0.3f, y - r * 0.3f))
                }
                val band = w * 0.35f
                val x0 = -band + (w + band) * sweep
                drawRect(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, Color.White.copy(alpha = 0.16f), Color.Transparent),
                        startX = x0, endX = x0 + band
                    ),
                    Offset(x0, 0f), Size(band, h)
                )
            }
        }
        Column(
            Modifier.fillMaxSize().padding(16.dp).graphicsLayer { translationY = if (running) bob else 0f },
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            val head = when {
                out == 1 -> brand.okWord
                out == 2 -> brand.failWord
                else -> brand.runWord
            }
            T(head.uppercase(), if (out == 2) Color(0xFFE5334D) else brand.accent, 12, true)
            Spacer(Modifier.height(6.dp))
            AnimatedContent(targetState = cur?.name ?: "analyzing...", label = "stageFile") { name ->
                T(name, brand.ink, 16, true)
            }
            Spacer(Modifier.height(4.dp))
            if (cur != null) T("partition: ${cur.part.ifBlank { "-" }}  ·  ${cur.size / 1024} KB", brand.sub, 12)
            if (total > 0) T("file ${minOf(idx + 1, total)} of $total", brand.sub, 11)
        }
    }
}

/** The file list, drawn in the layout of the chosen company's tool. */
@Composable
private fun FileArea(vm: MainVM, brand: FlashBrand, plan: List<QItem>, idx: Int, out: Int, overall: Float) {
    if (plan.isEmpty()) {
        GlassBox(brand, 22.dp) { T("Waiting for the analyzer...", brand.sub, 11) }
        return
    }
    when (brand.layout) {
        FlashLayout.TABLE -> TableLayout(vm, brand, plan, idx, out)
        FlashLayout.SLOTS -> SlotsLayout(brand, plan, idx, out)
        FlashLayout.STEPS -> StepsLayout(brand, plan, idx, out)
        FlashLayout.STATUSBOX -> StatusBoxLayout(brand, plan, idx, out)
        FlashLayout.RING -> RingLayout(brand, plan, idx, out, overall)
        FlashLayout.SPFT -> SpftLayout(brand, plan, idx, out, overall)
        FlashLayout.CONSOLE -> ConsoleLayout(brand, plan, idx, out)
        FlashLayout.TIMELINE -> TimelineLayout(brand, plan, idx, out)
    }
}

@Composable
private fun TableLayout(vm: MainVM, brand: FlashBrand, plan: List<QItem>, idx: Int, out: Int) {
    GlassBox(brand, 22.dp) {
        Row {
            T("IMAGE", brand.accent, 11, true, Modifier.weight(1f))
            T("STATUS", brand.accent, 11, true)
        }
        Spacer(Modifier.height(4.dp))
        plan.forEachIndexed { i, q ->
            val st = stateOf(i, idx, out)
            val col = colorOf(brand, st)
            val frac = when (st) {
                RowState.DONE -> 1f
                RowState.RUNNING -> vm.progress.coerceIn(0f, 1f)
                else -> 0f
            }
            Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StateDot(st, col, brand)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        T(q.name, brand.ink, 12, st == RowState.RUNNING)
                        T("${q.part.uppercase()} · ${q.size / 1024} KB", brand.sub, 10)
                    }
                    T(wordOf(brand, st), col, 11, true)
                }
                Spacer(Modifier.height(4.dp))
                Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(50)).background(brand.sub.copy(alpha = 0.22f))) {
                    if (frac > 0f) Box(Modifier.fillMaxWidth(frac).height(5.dp).background(col))
                }
            }
        }
    }
}

@Composable
private fun SlotsLayout(brand: FlashBrand, plan: List<QItem>, idx: Int, out: Int) {
    GlassBox(brand, 22.dp) {
        T("SLOTS", brand.accent, 12, true)
        Spacer(Modifier.height(6.dp))
        plan.forEachIndexed { i, q ->
            val st = stateOf(i, idx, out)
            val col = colorOf(brand, st)
            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                StateDot(st, col, brand)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    T("[${q.part.uppercase()}] ${q.name}", brand.ink, 12, st == RowState.RUNNING)
                    T("${q.size / 1024} KB", brand.sub, 10)
                }
                T(wordOf(brand, st), col, 11, true)
            }
        }
    }
}

@Composable
private fun StepsLayout(brand: FlashBrand, plan: List<QItem>, idx: Int, out: Int) {
    Column(Modifier.fillMaxWidth()) {
        plan.forEachIndexed { i, q ->
            val st = stateOf(i, idx, out)
            val col = colorOf(brand, st)
            val shape = RoundedCornerShape(16.dp)
            Row(
                Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(shape)
                    .background(Brush.linearGradient(listOf(brand.glassTop, brand.glassBottom)), shape)
                    .border(if (st == RowState.RUNNING) 2.dp else 1.dp, if (st == RowState.RUNNING) brand.accent else brand.glassEdge, shape)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(28.dp).clip(CircleShape).background(col, CircleShape), contentAlignment = Alignment.Center) {
                    T("${i + 1}", Color.White, 12, true)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    T("Write ${q.name}", brand.ink, 12, true)
                    T("to ${q.part.uppercase()} · ${q.size / 1024} KB", brand.sub, 10)
                }
                T(wordOf(brand, st), col, 11, true)
            }
        }
    }
}

@Composable
private fun StatusBoxLayout(brand: FlashBrand, plan: List<QItem>, idx: Int, out: Int) {
    val head = when {
        out == 1 -> brand.okWord
        out == 2 -> brand.failWord
        else -> brand.runWord
    }
    val col = when (out) {
        1 -> Color(0xFF1FA463)
        2 -> Color(0xFFE5334D)
        else -> brand.accent
    }
    val box = RoundedCornerShape(8.dp)
    Box(
        Modifier.fillMaxWidth().clip(box).background(col.copy(alpha = 0.16f), box).border(2.dp, col, box).padding(vertical = 20.dp),
        contentAlignment = Alignment.Center
    ) { T(head.uppercase(), col, 22, true) }
    Spacer(Modifier.height(10.dp))
    GlassBox(brand, 10.dp) {
        Row {
            T("FILE", brand.accent, 11, true, Modifier.weight(1f))
            T("PARTITION", brand.accent, 11, true, Modifier.weight(0.6f))
            T("STATE", brand.accent, 11, true)
        }
        Spacer(Modifier.height(4.dp))
        plan.forEachIndexed { i, q ->
            val st = stateOf(i, idx, out)
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                T(q.name, brand.ink, 11, false, Modifier.weight(1f))
                T(q.part.uppercase(), brand.sub, 11, false, Modifier.weight(0.6f))
                T(wordOf(brand, st), colorOf(brand, st), 11, true)
            }
        }
    }
}

@Composable
private fun RingLayout(brand: FlashBrand, plan: List<QItem>, idx: Int, out: Int, overall: Float) {
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(150.dp)) {
            val sw = 14.dp.toPx()
            val tl = Offset(sw / 2f, sw / 2f)
            val sz = Size(size.width - sw, size.height - sw)
            drawArc(brand.sub.copy(alpha = 0.25f), 0f, 360f, false, tl, sz, style = Stroke(width = sw))
            drawArc(
                if (out == 2) Color(0xFFE5334D) else brand.accent, -90f, 360f * overall, false, tl, sz,
                style = Stroke(width = sw, cap = StrokeCap.Round)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            T("${(overall * 100).toInt()}%", brand.ink, 28, true)
            T(when (out) { 1 -> brand.okWord; 2 -> brand.failWord; else -> brand.runWord }, brand.accent, 12, true)
        }
    }
    Spacer(Modifier.height(10.dp))
    GlassBox(brand, 22.dp) {
        plan.forEachIndexed { i, q ->
            val st = stateOf(i, idx, out)
            T("•  ${q.name}  ·  ${wordOf(brand, st)}", colorOf(brand, st), 11, st == RowState.RUNNING, Modifier.padding(vertical = 2.dp))
        }
    }
}

@Composable
private fun SpftLayout(brand: FlashBrand, plan: List<QItem>, idx: Int, out: Int, overall: Float) {
    val circle = when (out) {
        1 -> Color(0xFF1FA463)
        2 -> Color(0xFFE5334D)
        else -> Color(0xFFFFC107)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(84.dp).clip(CircleShape).background(circle, CircleShape), contentAlignment = Alignment.Center) {
            T(when (out) { 1 -> brand.okWord; 2 -> brand.failWord; else -> "${(overall * 100).toInt()}%" }, Color(0xFF111111), 12, true)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            T(when (out) { 1 -> brand.okWord; 2 -> brand.failWord; else -> brand.runWord }, brand.ink, 14, true)
            Spacer(Modifier.height(6.dp))
            BrandBar(brand, overall, out == 0, 24.dp)
        }
    }
    Spacer(Modifier.height(10.dp))
    GlassBox(brand, 12.dp) {
        plan.forEachIndexed { i, q ->
            val st = stateOf(i, idx, out)
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                T(q.name, brand.ink, 11, false, Modifier.weight(1f))
                T(wordOf(brand, st), colorOf(brand, st), 11, true)
            }
        }
    }
}

@Composable
private fun ConsoleLayout(brand: FlashBrand, plan: List<QItem>, idx: Int, out: Int) {
    val inf = rememberInfiniteTransition(label = "cursor")
    val blink by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(500), RepeatMode.Reverse), label = "blink")
    GlassBox(brand, 10.dp) {
        Mono("$ flashforge write --queue ${plan.size}", brand.sub)
        plan.forEachIndexed { i, q ->
            val st = stateOf(i, idx, out)
            Mono("> ${q.name} -> ${q.part}  [${wordOf(brand, st)}]", colorOf(brand, st))
        }
        if (out == 0) Mono("_", brand.accent.copy(alpha = blink))
        if (out == 1) Mono("# all writes finished", Color(0xFF1FA463))
        if (out == 2) Mono("# stopped: write failed", Color(0xFFE5334D))
    }
}

@Composable
private fun TimelineLayout(brand: FlashBrand, plan: List<QItem>, idx: Int, out: Int) {
    GlassBox(brand, 22.dp) {
        plan.forEachIndexed { i, q ->
            val st = stateOf(i, idx, out)
            val col = colorOf(brand, st)
            Row(Modifier.fillMaxWidth()) {
                Column(Modifier.width(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    StateDot(st, col, brand)
                    if (i < plan.size - 1) {
                        Box(Modifier.width(2.dp).height(26.dp).background(if (st == RowState.DONE) col else brand.sub.copy(alpha = 0.35f)))
                    }
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    T(q.name, brand.ink, 12, st == RowState.RUNNING)
                    T("${q.part.uppercase()} · ${wordOf(brand, st)}", col, 10)
                }
            }
        }
    }
}

@Composable
private fun SkippedRows(vm: MainVM, brand: FlashBrand, plan: List<QItem>) {
    val skipped = vm.queue.filter { q -> plan.none { it.uri == q.uri && it.part == q.part && it.name == q.name } }
    if (plan.isEmpty() || skipped.isEmpty()) return
    Spacer(Modifier.height(8.dp))
    GlassBox(brand, 16.dp) {
        skipped.forEach { q ->
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                Canvas(Modifier.size(14.dp)) {
                    val w = size.width
                    val h = size.height
                    drawLine(brand.sub, Offset(w * 0.15f, h * 0.15f), Offset(w * 0.85f, h * 0.85f), 2.dp.toPx(), StrokeCap.Round)
                    drawLine(brand.sub, Offset(w * 0.85f, h * 0.15f), Offset(w * 0.15f, h * 0.85f), 2.dp.toPx(), StrokeCap.Round)
                }
                Spacer(Modifier.width(10.dp))
                T(q.name, brand.sub, 11, false, Modifier.weight(1f))
                T("SKIPPED", brand.sub, 11, true)
            }
        }
    }
}

@Composable
private fun StateDot(st: RowState, col: Color, brand: FlashBrand) {
    val inf = rememberInfiniteTransition(label = "dot")
    val pulse by inf.animateFloat(0.4f, 1f, infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "dotPulse")
    Canvas(Modifier.size(18.dp)) {
        val w = size.width
        val c = Offset(w / 2f, size.height / 2f)
        when (st) {
            RowState.PENDING, RowState.STOPPED ->
                drawCircle(brand.sub.copy(alpha = 0.6f), w * 0.34f, c, style = Stroke(width = 2.dp.toPx()))
            RowState.RUNNING -> {
                drawCircle(col.copy(alpha = 0.25f * pulse), w * 0.5f, c)
                drawCircle(col, w * 0.28f, c)
            }
            RowState.DONE -> {
                drawCircle(col, w * 0.46f, c)
                val p = Path().apply { moveTo(w * 0.28f, w * 0.52f); lineTo(w * 0.44f, w * 0.68f); lineTo(w * 0.74f, w * 0.34f) }
                drawPath(p, Color.White, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            RowState.FAILED -> {
                drawCircle(col, w * 0.46f, c)
                drawLine(Color.White, Offset(w * 0.32f, w * 0.32f), Offset(w * 0.68f, w * 0.68f), 2.dp.toPx(), StrokeCap.Round)
                drawLine(Color.White, Offset(w * 0.68f, w * 0.32f), Offset(w * 0.32f, w * 0.68f), 2.dp.toPx(), StrokeCap.Round)
            }
        }
    }
}

/** The safety analyzer result for the current write. Its look follows the layout of the chosen company's tool. */
@Composable
private fun AnalyzerCard(vm: MainVM, brand: FlashBrand) {
    val st = vm.analyzerStatus
    val stCol = when {
        st.contains("BLOCK", true) || st.contains("FAIL", true) -> Color(0xFFE5334D)
        st.contains("RUN", true) -> brand.accent
        st.contains("WARN", true) -> Color(0xFFFFB300)
        else -> Color(0xFF1FA463)
    }
    val checks = vm.analyzerChecks.toList().takeLast(6)
    fun lineColor(line: String): Color = when {
        line.startsWith("PASS") -> Color(0xFF1FA463)
        line.startsWith("BLOCK") -> Color(0xFFE5334D)
        line.startsWith("WARN") -> Color(0xFFFFB300)
        else -> brand.sub
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
    when (brand.layout) {
        FlashLayout.CONSOLE -> GlassBox(brand, 10.dp) {
            Mono("[analyzer] $st", stCol)
            Mono(vm.analyzerMessage, brand.ink, 10)
            checks.forEach { Mono("  " + it, lineColor(it), 10) }
        }
        FlashLayout.STEPS -> GlassBox(brand, 16.dp) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                T("Safety checks", brand.accent, 12, true, Modifier.weight(1f))
                T(st, stCol, 12, true)
            }
            Spacer(Modifier.height(4.dp))
            T(vm.analyzerMessage, brand.ink, 11)
            checks.forEach { line ->
                Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(lineColor(line), CircleShape))
                    Spacer(Modifier.width(8.dp))
                    T(line, brand.ink, 10)
                }
            }
        }
        FlashLayout.STATUSBOX, FlashLayout.SPFT -> {
            val shape = RoundedCornerShape(8.dp)
            Column(Modifier.fillMaxWidth().clip(shape).background(stCol.copy(alpha = 0.12f), shape).border(1.dp, stCol, shape).padding(10.dp)) {
                T("ANALYZER  ·  $st", stCol, 12, true)
                T(vm.analyzerMessage, brand.ink, 11)
                checks.forEach { T(it, lineColor(it), 10, mod = Modifier.padding(top = 2.dp)) }
            }
        }
        else -> GlassBox(brand, 22.dp) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                T("ANALYZER", brand.accent, 12, true, Modifier.weight(1f))
                T(st, stCol, 12, true)
            }
            Spacer(Modifier.height(4.dp))
            T(vm.analyzerMessage, brand.ink, 11)
            if (checks.isNotEmpty()) Spacer(Modifier.height(6.dp))
            checks.forEach { T(it, lineColor(it), 10, mod = Modifier.padding(vertical = 1.dp)) }
        }
    }
    LiveOperationLog(vm, brand)
    }
}

/** Shows real ViewModel log events; this is not simulated progress or a fabricated device response. */
@Composable
private fun LiveOperationLog(vm: MainVM, brand: FlashBrand) {
    val recent = vm.logs.takeLast(8)
    GlassBox(brand, 12.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            T("LIVE OPERATION LOG", brand.accent, 12, true, Modifier.weight(1f))
            T("${recent.size} events", brand.sub, 10)
        }
        if (recent.isEmpty()) {
            T("No operation events yet. Device and protocol messages will appear here when available.", brand.sub, 10)
        } else {
            recent.forEach { entry ->
                val color = when {
                    entry.contains("ERROR", true) || entry.contains("FAIL", true) || entry.contains("BLOCK", true) -> Color(0xFFE5334D)
                    entry.contains("WARN", true) || entry.contains("INTERRUPTED", true) -> Color(0xFFFFB300)
                    entry.contains("PASS", true) || entry.contains("SUCCESS", true) -> Color(0xFF1FA463)
                    else -> brand.ink
                }
                if (brand.layout == FlashLayout.CONSOLE) Mono(entry, color, 10)
                else T(entry, color, 10, mod = Modifier.padding(vertical = 1.dp))
            }
        }
    }
}
