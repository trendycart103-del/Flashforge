package com.flashforge

// Native Jetpack Compose implementation adapted and integrated for FlashForge.
import androidx.annotation.DrawableRes
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.compose.animation.core.*
import kotlin.math.*

data class WheelItem(val label: String, @DrawableRes val icon: Int)

private const val WHEEL_CENTER = 200f; private const val HUB = 60f; private const val OUT = 186f; private const val GAP = 8f
private val PurpleStops = arrayOf(0f to Color(0xFFE0B8FF), .3f to Color(0xFFA066FF), .7f to Color(0xFF7A40F0), 1f to Color(0xFF5A28D8))
private val BlueStops = arrayOf(0f to Color(0xFFBFF0FF), .35f to Color(0xFF5AA8FF), .7f to Color(0xFF3B6CFF), 1f to Color(0xFF2A40E0))
private val RimLight = arrayOf(0f to Color.White, .5f to Color(0xFF8FE3FF), 1f to Color(0xFF4FA8FF))
private val RimFill = arrayOf(0f to Color(0xFF5A3CE0), 1f to Color(0xFF1C1A90))

private class Sec(val i: Int, val r1: Float, val r2: Float, val a0: Float, val a1: Float, val gp: Float, val size: Float, val v: Int, val cx: Float, val cy: Float)

/** Same algorithm as the HTML: wheel size fixed, more items => more rings, smaller buttons. */
private fun layout(n: Int): List<Sec> {
    val k = when { n <= 8 -> 1; n <= 20 -> 2; n <= 36 -> 3; else -> 4 }
    val t = (OUT - HUB - GAP * 2) / k
    val w = List(k) { OUT - t * (it + .5f) }; val sum = w.sum()
    val cnt = w.map { max(3, (n * it / sum).roundToInt()) }.toMutableList()
    var d = n - cnt.sum(); var q = 0
    while (d != 0) { cnt[q % k] += d.sign; d -= d.sign; q++ }
    val out = ArrayList<Sec>(); var idx = 0
    for (ring in 0 until k) {
        val r2 = OUT - t * ring; val r1 = r2 - t; val m = cnt[ring]; val step = (2 * PI / m).toFloat(); val rm = (r1 + r2) / 2
        val gp = (28f / m).coerceIn(2.5f, 8f); val size = min(t, 2f * PI.toFloat() * rm / m) - 8f
        var j = 0
        while (j < m && idx < n) {
            val a = (-PI / 2).toFloat() + j * step
            out += Sec(idx, r1, r2, a - step / 2, a + step / 2, gp, size, (ring + j) % 2, WHEEL_CENTER + rm * cos(a), WHEEL_CENTER + rm * sin(a))
            j++; idx++
        }
    }
    return out
}

private fun deg(r: Float) = (r * 180f / PI).toFloat()
private fun secPath(r1: Float, r2: Float, a0: Float, a1: Float, gap: Float): Path {
    val g1 = gap / r1; val g2 = gap / r2
    val p = Path()
    p.arcTo(Rect(WHEEL_CENTER - r2, WHEEL_CENTER - r2, WHEEL_CENTER + r2, WHEEL_CENTER + r2), deg(a0 + g2), deg(a1 - g2) - deg(a0 + g2), true)
    p.arcTo(Rect(WHEEL_CENTER - r1, WHEEL_CENTER - r1, WHEEL_CENTER + r1, WHEEL_CENTER + r1), deg(a1 - g1), deg(a0 + g1) - deg(a1 - g1), false)
    p.close(); return p
}
private fun vBrush(stops: Array<Pair<Float, Color>>, b: Rect) = Brush.verticalGradient(colorStops = stops, startY = b.top, endY = b.bottom)

@Composable
fun WheelMenu(items: List<WheelItem>, hub: WheelItem, modifier: Modifier = Modifier, onItem: (Int) -> Unit, onHub: () -> Unit) {
    val secs = remember(items.size) { layout(items.size) }
    val phase by rememberInfiniteTransition(label = "run").animateFloat(0f, 1f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "p")
    BoxWithConstraints(modifier.aspectRatio(1f)) {
        val s = maxWidth.value / 400f // dp per design unit
        Canvas(Modifier.fillMaxSize().pointerInput(items.size) {
            detectTapGestures { o ->
                val k = size.width / 400f; val x = o.x / k - WHEEL_CENTER; val y = o.y / k - WHEEL_CENTER; val r = hypot(x, y)
                if (r < HUB) { onHub(); return@detectTapGestures }
                var ang = atan2(y, x); val hit = secs.firstOrNull { sc ->
                    var a = ang; while (a < sc.a0) a += (2 * PI).toFloat(); while (a > sc.a0 + 2 * PI) a -= (2 * PI).toFloat()
                    r in sc.r1..sc.r2 && a <= sc.a1 }
                if (hit != null) onItem(hit.i)
            }
        }) {
            withTransform({ scale(size.width / 400f, size.width / 400f, Offset.Zero) }) {
                drawCircle(Color.Black.copy(.5f), OUT + 10, Offset(WHEEL_CENTER, WHEEL_CENTER + 6))
                drawCircle(Color(0xFF1A1285), OUT + 9, Offset(WHEEL_CENTER, WHEEL_CENTER))
                drawCircle(vBrush(RimLight, Rect(WHEEL_CENTER - OUT, WHEEL_CENTER - OUT, WHEEL_CENTER + OUT, WHEEL_CENTER + OUT)), OUT + 9, Offset(WHEEL_CENTER, WHEEL_CENTER), style = Stroke(11f))
                for (sc in secs) {
                    val sh = secPath(sc.r1 + 9, sc.r2 - 9, sc.a0, sc.a1, sc.gp + 9); val b = sh.getBounds()
                    translate(0f, 6f) { drawPath(sh, Color.Black.copy(.5f)); drawPath(sh, Color.Black.copy(.5f), style = Stroke(18f, join = StrokeJoin.Round)) }
                    drawPath(sh, vBrush(RimFill, b)); drawPath(sh, vBrush(RimLight, b), style = Stroke(18f, join = StrokeJoin.Round))
                    val body = vBrush(if (sc.v == 0) PurpleStops else BlueStops, b)
                    drawPath(sh, body); drawPath(sh, body, style = Stroke(10f, join = StrokeJoin.Round))
                    clipPath(sh) {
                        val t = sc.r2 - sc.r1
                        drawOval(Brush.verticalGradient(listOf(Color.White.copy(.38f), Color.White.copy(.05f), Color.Transparent), sc.cy - t * .85f, sc.cy + t * .25f),
                            Offset(sc.cx - t * 1.25f, sc.cy - t * .85f), Size(t * 2.5f, t * 1.1f))
                    }
                    drawPath(sh, Color.White.copy(.6f), style = Stroke(1.2f, join = StrokeJoin.Round))
                    // running light (dash phase animated)
                    drawPath(sh, Color.White, style = Stroke(3.5f, cap = StrokeCap.Round, pathEffect = PathEffect.dashPathEffect(floatArrayOf(40f, 260f), phase * -300f)))
                    drawPath(sh, Color(0xFF7FE8FF).copy(alpha = .8f), style = Stroke(2.5f, cap = StrokeCap.Round, pathEffect = PathEffect.dashPathEffect(floatArrayOf(20f, 280f), phase * 420f)))
                }
                drawCircle(Color.Black.copy(.5f), HUB, Offset(WHEEL_CENTER, WHEEL_CENTER + 6))
                drawCircle(vBrush(RimLight, Rect(WHEEL_CENTER - HUB, WHEEL_CENTER - HUB, WHEEL_CENTER + HUB, WHEEL_CENTER + HUB)), HUB - 3, Offset(WHEEL_CENTER, WHEEL_CENTER), style = Stroke(8f))
                drawCircle(Brush.radialGradient(listOf(Color(0xFF7B5BFF), Color(0xFF2A1A9A), Color(0xFF160C66)), Offset(WHEEL_CENTER - 15, WHEEL_CENTER - 18), HUB), HUB - 7, Offset(WHEEL_CENTER, WHEEL_CENTER))
            }
        }
        // Labels and icon overlays are laid out in the same 400-unit design space.
        secs.forEach { WheelLabel(it.cx, it.cy, it.size, items[it.i], false, s) }
        WheelLabel(WHEEL_CENTER, WHEEL_CENTER, 100f, hub, true, s)
    }
}

@Composable
private fun WheelLabel(cx: Float, cy: Float, designSize: Float, item: WheelItem, big: Boolean, scale: Float) {
    val fontSize = (designSize / 25f).coerceIn(1.9f, 4.4f) * 4f * scale
    val iconHeight = (if (big) 10f else min(14f, designSize * .12f)) * 4f * scale
    Box(
        Modifier.size((designSize * scale).dp)
            .offset(((cx - designSize / 2) * scale).dp, ((cy - designSize / 2) * scale).dp),
        Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(item.icon), null, Modifier.height(iconHeight.dp), contentScale = ContentScale.Fit)
            Text(
                item.label.replaceFirst(' ', '\n'), color = Color.White, fontSize = fontSize.sp,
                fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, lineHeight = fontSize.sp,
                style = TextStyle(shadow = Shadow(Color(0xCC1D1190), Offset(0f, 3f), 4f))
            )
        }
    }
}
