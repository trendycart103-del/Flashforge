package com.flashforge

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private fun openOtgSettings(ctx: Context) {
    val tries = listOf(
        Intent("android.settings.USB_SETTINGS"),
        Intent().setClassName("com.android.settings", "com.android.settings.Settings\$ConnectedDeviceDashboardActivity"),
        Intent(Settings.ACTION_SETTINGS)
    )
    for (i in tries) try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return
    } catch (e: Exception) {
        android.util.Log.w("FlashForge", "Could not open OTG settings", e)
    }
}

@Composable
private fun PreferenceRow(icon: String, title: String, summary: String, onClick: (() -> Unit)? = null, trailing: (@Composable () -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable { onClick() } else Modifier).padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        androidx.compose.material3.Text(icon, color = C.blue, modifier = Modifier.width(38.dp))
        Column(Modifier.weight(1f)) {
            T(localized(title), C.text, 13, true)
            Spacer(Modifier.height(2.dp))
            T(localized(summary), C.dim, 10)
        }
        if (trailing != null) trailing() else if (onClick != null) T("›", C.dim, 22)
    }
}

@Composable
private fun SettingGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
        T(localized(title.uppercase()), C.blue, 10, true, Modifier.padding(start = 16.dp, top = 13.dp, bottom = 4.dp))
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(C.panel), content = content)
    }
}

@Composable
fun SettingsPage(vm: MainVM) {
    val ctx = LocalContext.current
    var showWallpapers by remember { mutableStateOf(false) }
    var showLanguage by remember { mutableStateOf(false) }
    var showAdvanced by remember { mutableStateOf(false) }
    var editPartition by remember { mutableStateOf("") }
    var partitionValue by remember { mutableStateOf("") }
    val custom by produceState<ImageBitmap?>(null, AppSettings.bgUri) {
        value = withContext(Dispatchers.IO) { loadBackgroundBitmap(ctx, AppSettings.bgUri, 180) }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? ->
        if (u != null) {
            try { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            catch (e: Exception) { android.util.Log.w("FlashForge", "Could not keep background image permission", e) }
            AppSettings.setCustomBg(u.toString())
        }
    }

    SettingGroup(if (AppSettings.language == "bn") "চেহারা ও ভাষা" else "Appearance & language") {
        PreferenceRow("文", if (AppSettings.language == "bn") "অ্যাপের ভাষা" else "App language", if (AppSettings.language == "bn") "বাংলা" else "English", { showLanguage = true })
        PreferenceRow("▧", "Background image", "${when (AppSettings.bgChoice) { 3 -> "Midnight Flow"; 4 -> "Soft Cyan Waves"; 5 -> "Electric Horizon"; 6 -> "Deep Navy Glow"; 7 -> "Violet Flow"; 8 -> "Neon Lines"; 9 -> "Glass Geometry"; else -> "Blue Particle Wave" }} selected", { showWallpapers = true })
        PreferenceRow("A", "Text size", "${(AppSettings.textScale * 100).toInt()}%") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                T("−", C.blue, 20, true, Modifier.clickable { AppSettings.stepTextScale(-0.05f) }.padding(horizontal = 8.dp))
                T("+", C.blue, 20, true, Modifier.clickable { AppSettings.stepTextScale(0.05f) }.padding(horizontal = 8.dp))
            }
        }
    }

    SettingGroup("Device and connection") {
        val host = ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_USB_HOST)
        PreferenceRow("⌁", "USB host support", if (host) "Available on this phone" else "Not reported by this phone")
        PreferenceRow("↗", "OTG and USB settings", "Open Android system connection settings", { openOtgSettings(ctx) })
        PreferenceRow("⇄", "Slow transfer warning", "Alert below ${"%.1f".format(AppSettings.slowMbs)} MiB/s") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                T("−", C.blue, 20, true, Modifier.clickable { AppSettings.stepSlowMbs(-0.5) }.padding(horizontal = 7.dp))
                T("+", C.blue, 20, true, Modifier.clickable { AppSettings.stepSlowMbs(0.5) }.padding(horizontal = 7.dp))
            }
        }
        PreferenceRow("!", "Disconnect warning limit", "${AppSettings.flapLimit} disconnects") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                T("−", C.blue, 20, true, Modifier.clickable { AppSettings.stepFlapLimit(-1) }.padding(horizontal = 7.dp))
                T("+", C.blue, 20, true, Modifier.clickable { AppSettings.stepFlapLimit(1) }.padding(horizontal = 7.dp))
            }
        }
    }

    SettingGroup("Flashing and safety") {
        PreferenceRow("▣", "Minimum controller battery", "Flash operations require at least ${AppSettings.minBattery}%") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                T("−", C.blue, 20, true, Modifier.clickable { AppSettings.stepMinBattery(-5) }.padding(horizontal = 7.dp))
                T("+", C.blue, 20, true, Modifier.clickable { AppSettings.stepMinBattery(5) }.padding(horizontal = 7.dp))
            }
        }
        PreferenceRow("⌑", "Default backup partition", AppSettings.defBackup, { editPartition = "backup"; partitionValue = AppSettings.defBackup })
        PreferenceRow("⌑", "Default recovery partition", AppSettings.defRecovery, { editPartition = "recovery"; partitionValue = AppSettings.defRecovery })
        PreferenceRow("⌑", "Default patched image partition", AppSettings.defPatched, { editPartition = "patched"; partitionValue = AppSettings.defPatched })
        PreferenceRow("ⓘ", "Advanced preferences", "Log history and connection sampling", { showAdvanced = !showAdvanced })
        if (showAdvanced) {
            PreferenceRow("≋", "Connection samples before warning", "${AppSettings.slowSamples} samples") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    T("−", C.blue, 20, true, Modifier.clickable { AppSettings.stepSlowSamples(-1) }.padding(horizontal = 7.dp))
                    T("+", C.blue, 20, true, Modifier.clickable { AppSettings.stepSlowSamples(1) }.padding(horizontal = 7.dp))
                }
            }
            PreferenceRow("≡", "Maximum log entries", "${AppSettings.logMax}") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    T("−", C.blue, 20, true, Modifier.clickable { AppSettings.stepLogMax(-100) }.padding(horizontal = 7.dp))
                    T("+", C.blue, 20, true, Modifier.clickable { AppSettings.stepLogMax(100) }.padding(horizontal = 7.dp))
                }
            }
        }
    }

    if (showLanguage) AlertDialog(
        onDismissRequest = { showLanguage = false },
        title = { T(if (AppSettings.language == "bn") "অ্যাপের ভাষা" else "App language", C.text, 17, true) },
        text = {
            Column {
                PreferenceRow(if (AppSettings.language == "bn") "●" else "○", "বাংলা", if (AppSettings.language == "bn") "নির্বাচিত" else "Select", {
                    AppSettings.setLanguage("bn"); showLanguage = false
                })
                PreferenceRow(if (AppSettings.language == "en") "●" else "○", "English", if (AppSettings.language == "en") "Selected" else "Select", {
                    AppSettings.setLanguage("en"); showLanguage = false
                })
            }
        },
        confirmButton = { TextButton(onClick = { showLanguage = false }) { androidx.compose.material3.Text(if (AppSettings.language == "bn") "বন্ধ" else "Close") } }
    )

    if (editPartition.isNotBlank()) AlertDialog(
        onDismissRequest = { editPartition = "" },
        title = { T(localized("Default partition"), C.text, 17, true) },
        text = { OutlinedTextField(value = partitionValue, onValueChange = { partitionValue = it }, singleLine = true, label = { androidx.compose.material3.Text(localized("Partition name")) }) },
        confirmButton = { TextButton(onClick = {
            when (editPartition) {
                "backup" -> AppSettings.updateDefBackup(partitionValue)
                "recovery" -> AppSettings.updateDefRecovery(partitionValue)
                "patched" -> AppSettings.updateDefPatched(partitionValue)
            }
            editPartition = ""
        }) { androidx.compose.material3.Text(localized("Save")) } },
        dismissButton = { TextButton(onClick = { editPartition = "" }) { androidx.compose.material3.Text(localized("Cancel")) } }
    )

    if (showWallpapers) AlertDialog(
        onDismissRequest = { showWallpapers = false },
        title = { T(localized("Background image"), C.text, 17, true) },
        text = {
            Column {
                listOf(3 to "Midnight Flow", 4 to "Soft Cyan Waves", 5 to "Electric Horizon", 6 to "Deep Navy Glow", 7 to "Violet Flow", 8 to "Neon Lines", 9 to "Glass Geometry", 10 to "Blue Particle Wave").forEach { (id, name) ->
                    PreferenceRow(if (AppSettings.bgChoice == id) "●" else "○", name, if (AppSettings.bgChoice == id) "Selected" else "Use this background", { AppSettings.chooseBg(id); showWallpapers = false })
                }
                if (custom != null) PreferenceRow("▧", "My image", "Use selected phone image", { AppSettings.chooseBg(2); showWallpapers = false })
            }
        },
        confirmButton = { TextButton(onClick = { picker.launch(arrayOf("image/*")) }) { androidx.compose.material3.Text(localized("Choose from phone")) } },
        dismissButton = { TextButton(onClick = { showWallpapers = false }) { androidx.compose.material3.Text(localized("Close")) } }
    )
}
