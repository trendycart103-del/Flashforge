package com.flashforge

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Opens the phone's own settings screen where OTG / USB options live. Falls back to the main Settings app. */
private fun openOtgSettings(ctx: Context) {
    val tries = listOf(
        Intent("android.settings.USB_SETTINGS"),
        Intent().setClassName("com.android.settings", "com.android.settings.Settings\$ConnectedDeviceDashboardActivity"),
        Intent(Settings.ACTION_SETTINGS)
    )
    for (i in tries) {
        try {
            ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        } catch (e: Exception) {
            android.util.Log.w("FlashForge", "Could not open OTG settings with ${i.action ?: i.component}", e)
        }
    }
}

@Composable
private fun BgTile(choice: Int, label: String, bitmap: ImageBitmap?, modifier: Modifier = Modifier) {
    val sel = AppSettings.bgChoice == choice
    val sh = FieldShape
    Column(modifier.clickable { AppSettings.chooseBg(choice) }, horizontalAlignment = Alignment.CenterHorizontally) {
        BgThumb(
            choice, bitmap,
            Modifier.fillMaxWidth().height(150.dp).clip(sh).border(if (sel) 3.dp else 1.dp, if (sel) C.blue else C.ink.copy(alpha = 0.2f), sh)
        )
        Spacer(Modifier.height(4.dp))
        T(label + if (sel) "  \u2713" else "", if (sel) C.blue else C.dim, 11, sel)
    }
}

@Composable
fun SettingsPage(vm: MainVM) {
    val ctx = LocalContext.current
    Panel("USB CABLE AND OTG") {
        KV("OTG / USB host support", if (ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_USB_HOST)) "yes" else "no")
        KV("Target phone", if (vm.mode == Mode.NONE) "Not detected" else vm.mode.label)
        T("Use a DATA cable, not a charge-only cable, and an OTG adapter on this phone. On many phones OTG is switched off until you turn it on in the phone's own settings. If the target phone is not detected, open the phone settings below and enable OTG (often under Connections or Connected devices).", C.dim, 11, mod = Modifier.padding(top = 4.dp))
        Spacer(Modifier.size(8.dp))
        Btn("OPEN OTG SETTINGS", mod = Modifier.fillMaxWidth(), icon = 0) { openOtgSettings(ctx) }
    }
    val custom by produceState<ImageBitmap?>(null, AppSettings.bgUri) {
        value = withContext(Dispatchers.IO) { loadBackgroundBitmap(ctx, AppSettings.bgUri, 480) }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? ->
        if (u != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                android.util.Log.w("FlashForge", "Could not keep access to the chosen background image", e)
            }
            AppSettings.setCustomBg(u.toString())
        }
    }
    Panel("BACKGROUND IMAGE STOCK") {
        T("Choose any saved FlashForge wallpaper. Your selection is remembered, and you can change it here any time.", C.dim, 11, mod = Modifier.padding(bottom = 8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BgTile(3, "Midnight Circuit", null, Modifier.weight(1f))
            BgTile(4, "Soft Cyan", null, Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BgTile(5, "Electric Grid", null, Modifier.weight(1f))
            BgTile(6, "Deep Navy", null, Modifier.weight(1f))
        }
        if (custom != null) {
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth()) { BgTile(2, "My image", custom, Modifier.weight(1f)); Spacer(Modifier.weight(2f)) }
        }
        Spacer(Modifier.height(8.dp))
        Btn("CHOOSE IMAGE FROM PHONE") { picker.launch(arrayOf("image/*")) }
    }
}
