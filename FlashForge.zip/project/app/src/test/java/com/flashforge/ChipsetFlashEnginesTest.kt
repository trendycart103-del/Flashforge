package com.flashforge

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Test

/** Safety regression tests: a detected transport must never silently enable a chipset write path. */
class ChipsetFlashEnginesTest {
    @Test
    fun allRegisteredChipsetEnginesRemainFailClosed() {
        assertEquals(4, ChipsetFlashEngines.engines.size)
        assertFalse(
            "Chipset write operations must remain disabled until a reviewed, tested protocol engine exists",
            ChipsetFlashEngines.engines.any { it.writeEnabled }
        )
    }

    @Test
    fun eachRegisteredEngineHasAUniqueModeAndExplicitRequirements() {
        val modes = ChipsetFlashEngines.engines.map { it.mode }
        assertEquals(modes.size, modes.toSet().size)
        ChipsetFlashEngines.engines.forEach { engine ->
            assertNotNull(engine.title)
            assertFalse(engine.requirements.isBlank())
            assertFalse(engine.transport.isBlank())
            assertNotNull(ChipsetFlashEngines.forMode(engine.mode))
        }
    }
}
