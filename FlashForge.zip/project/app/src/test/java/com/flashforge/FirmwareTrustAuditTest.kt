package com.flashforge

import org.junit.Assert.* 
import org.junit.Test

class FirmwareTrustAuditTest {
    private val validHash = "a".repeat(64)

    @Test fun rejectsNonHttpsSources() {
        assertEquals(FirmwareTrustAudit.Status.BLOCKED, FirmwareTrustAudit.validateSource("http://example.com/rom.zip").status)
        assertEquals(FirmwareTrustAudit.Status.WARNING, FirmwareTrustAudit.validateSource("https://example.com/rom.zip").status)
    }

    @Test fun checksumWithoutExpectedDigestIsOnlyWarning() {
        assertEquals(FirmwareTrustAudit.Status.WARNING, FirmwareTrustAudit.compareSha256(validHash, null).status)
    }

    @Test fun checksumMatchAndMismatchAreDistinguished() {
        assertEquals(FirmwareTrustAudit.Status.PASS, FirmwareTrustAudit.compareSha256(validHash, validHash).status)
        assertEquals(FirmwareTrustAudit.Status.BLOCKED, FirmwareTrustAudit.compareSha256(validHash, "b".repeat(64)).status)
    }

    @Test fun exactModelMismatchBlocksCompatibility() {
        assertEquals(FirmwareTrustAudit.Status.BLOCKED, FirmwareTrustAudit.assessCompatibility("Pixel 6", "Pixel 6 Pro").status)
    }

    @Test fun incompleteRegionOrChipsetEvidenceIsWarning() {
        assertEquals(FirmwareTrustAudit.Status.WARNING, FirmwareTrustAudit.assessCompatibility("Model X", "Model X").status)
    }

    @Test fun fullCompatibilityEvidencePasses() {
        assertEquals(FirmwareTrustAudit.Status.PASS, FirmwareTrustAudit.assessCompatibility("Model X", "Model X", "EU", "EU", "Chip A", "Chip A").status)
    }
}
