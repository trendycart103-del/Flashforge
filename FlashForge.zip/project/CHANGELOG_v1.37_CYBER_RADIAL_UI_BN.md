# FlashForge v1.37 — Cyber Gaming UI Update

- Bundled the selected dark cyber-gaming wallpaper with a deep-black overlay, animated cyan/purple light trails, subtle edge HUD traces and floating particles.
- Reworked shared expandable panels into dark metallic glass panels with cyan/magenta neon outlines while preserving their existing controls and callbacks.
- Updated the Device mode wheel, Flash action wheel and ROM & Root wheel with dark raised-looking segment fills, metallic bevel strokes and cyan/magenta neon edges.
- Preserved the horizontal top-level tab navigation and the existing action-selection logic.
- Updated Android app version metadata to 1.37 (versionCode 25).

## Validation
- ZIP integrity and resource presence are checked during packaging.
- Full Gradle/Android compile, lint, emulator and real-device validation were not run: this working environment does not contain a Gradle executable or Android SDK.
- The new UI styling does not authorize or change any firmware flashing safety gate or device command behavior.
