**ঐতিহাসিক রিপোর্ট:** এই রিপোর্টের বর্তমান-অবস্থা অংশগুলো v1.12 দ্বারা superseded। বর্তমান Logical Partition, Resume, Restore ও Database অবস্থা `UPDATE_REPORT_BN_v1.12.md` এবং README-তে দেখুন।

---

# FlashForge Android — Final Audit & Fix Report (v1.8)

## Summary
এই ZIP-এ আগের v1.6 audited project এবং v1.7 language-selector change-এর উপর incremental v1.8 fixes যোগ করা হয়েছে। Source review/static checks করা হয়েছে; Android build বা hardware tests চালানো হয়নি।

## v1.8 confirmed changes
- `versionCode` 8, `versionName` 1.8.
- Shared UI helper `T()` এবং bottom navigation-এ dictionary-backed Bangla labels.
- Settings `PreferenceRow`, `SettingGroup`, এবং কয়েকটি dialog action-এর labels localization helper ব্যবহার করে.
- Bangla dictionary-এর জন্য unit test source যোগ করা হয়েছে.
- Firmware Source Resolver brand aliases normalize করে (Google Pixel, Redmi/Poco, Moto, Nokia/HMD ইত্যাদি); official portal/domain-scoped search discovery উন্নত করা হয়েছে.
- আগের custom wallpaper URI persistence fix বজায় আছে.

## Feature status matrix

| Feature | Status | Reason / remaining work |
|---|---|---|
| Compose UI, navigation, Settings | Implemented in source | Build/device validation needed |
| Custom wallpaper persistence | Fixed in v1.6 | Android restart/storage permission test needed |
| Bangla/English selector persistence | Implemented | App-wide translation is partial, not complete |
| Shared static-label localization | Partial | Dictionary covers selected labels only; dynamic/raw Text/dialog/log/error strings remain untranslated |
| USB host detection/permission | Implemented in source | Hardware/OS test required |
| Vendor/Product ID reading | Implemented in source | Device matrix/accuracy tests required |
| Fastboot detection/connect | Implemented in source | USB test, malformed response and timeout tests required |
| Fastboot flash path | Present with safety checks | Not hardware validated; firmware/model compatibility cannot be guaranteed |
| ADB sideload | Present | Recovery protocol/device test required |
| Official firmware portals | Present | Portals are not exact direct ROM links |
| Firmware resolver | Partial | Alias normalization added; exact model/region/build and authenticity resolver still absent |
| HTTPS download | Present | Redirect, resume, server and interruption tests required |
| ZIP extraction/queue | Present | Malformed archive and storage/limit tests required |
| SHA-256 | Implemented | Trusted publisher checksum must be supplied; hash alone does not authenticate source |
| Compatibility/Safety Analyzer | Present | Safety PASS is not hardware guarantee; device matrix needed |
| Logical partition create/resize/delete | Disabled | Insufficient device-specific metadata/guard validation |
| Bootloader relock | Disabled | Modified image/boot state compatibility risk |
| Automatic vbmeta patching | Disabled | Verified Boot weakening path intentionally excluded |
| Qualcomm EDL | Detection/registry only | Write protocol not implemented; fail-closed |
| MediaTek BROM | Detection/registry only | DA/protocol engine not implemented; fail-closed |
| Samsung Download | Detection only | Native Samsung flashing protocol not implemented |
| Unisoc FDL | Detection only | FDL protocol engine not implemented |
| Optional loader/DA selection | UI/reference storage | Does not execute or authorize flashing |
| Backup | Limited | Fastboot fetch only on supported devices; partition support varies |
| Restore | Not implemented | No safe end-to-end restore workflow |
| Device database | Present | Local JSON/HTTPS update; signature/authenticity verification absent |
| Operation Journal | Present | Does not guarantee safe operation resume after interruption |
| Floating bubble | Present | Overlay/notification/foreground-service restrictions require OS tests |
| Logs/export | Present in source | Export and interruption behavior tests required |

## Why some features remain incomplete
- **Full Bangla/English:** The project uses many direct string literals and dynamic protocol/device messages. A small shared dictionary was added, but a complete localization pass requires replacing/auditing all user-visible strings and formatting templates. Claiming complete translation would be inaccurate.
- **EDL/BROM/Samsung/FDL flashing:** detection and metadata are not the same as a verified vendor protocol. Device-specific authorization, signed loaders, protocol implementations, and hardware validation are not present. Write paths remain disabled instead of presenting false success or unsafe generic flashing.
- **Backup/Restore:** Fastboot `fetch` is not universally supported and does not cover all partitions. Restore requires exact model/partition metadata and robust preflight/verification; the full workflow is not present.
- **Direct official firmware URLs:** manufacturer portals and official-domain search are discovery links. Many vendors require region, account, device serial, software version, or service tools; a universal exact direct-download resolver is not implemented.
- **Firmware trust:** SHA-256 confirms byte equality only against a trusted expected hash. Source authenticity/signature verification and signed database updates are not complete.
- **Build/hardware validation:** this runtime has no Gradle executable, Gradle wrapper, Android SDK or connected phone, so build, APK, emulator, and USB tests cannot be truthfully marked successful.

## Static checks performed in this update
- ZIP integrity: checked after packaging.
- XML parse: 52 files passed.
- JSON parse: 1 file passed.
- `AppStrings.kt` isolated Kotlin compile with a stub settings object: passed.
- Unit tests: source added/retained, not executed.
- Full Kotlin/Android build: not run.
- Emulator/physical device/USB tests: not run.

## Safe capability policy
Unsupported chipset write engines, bootloader relock, automatic vbmeta modification, and logical partition mutation remain disabled/fail-closed. Detection or optional file selection is never represented as an executed write. The app must not claim operation success unless the transport and device report a verifiable result.
