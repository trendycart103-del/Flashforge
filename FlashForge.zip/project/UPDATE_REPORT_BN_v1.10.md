**ঐতিহাসিক রিপোর্ট:** এই রিপোর্টের বর্তমান-অবস্থা অংশগুলো v1.12 দ্বারা superseded। বর্তমান Logical Partition, Resume, Restore ও Database অবস্থা `UPDATE_REPORT_BN_v1.12.md` এবং README-তে দেখুন।

---

# FlashForge v1.10 — Priority Weakness Update

এই আপডেটটি Android-only অ্যাপের তুলনায় পূর্বে চিহ্নিত দুর্বল ক্ষেত্রগুলোকে অগ্রাধিকার দিয়েছে:

1. Firmware Management (আগের মূল্যায়ন 4/10): `FirmwareTrustAudit` যোগ করা হয়েছে—HTTPS source URL validation, SHA-256 expected digest compare, এবং mismatch/missing digest-এর fail-closed/warning status.
2. Flashing Capability (আগের মূল্যায়ন 2/10): destructive chipset write engines যোগ করা হয়নি। Supported mode registry ও safety boundary বজায় রেখে diagnostics/compatibility রিপোর্ট উন্নত করা হয়েছে; detection-কে write authorization হিসেবে গণ্য করা হয় না.
3. Hardware Compatibility (আগের মূল্যায়ন 3/10): exact model, region ও chipset evidence তুলনার evaluator যোগ হয়েছে; missing evidence WARNING, mismatch BLOCKED.
4. Testing & Stability (আগের মূল্যায়ন 2/10): FirmwareTrustAudit-এর JUnit test cases যোগ হয়েছে—HTTPS validation, checksum missing/match/mismatch, model mismatch, incomplete evidence এবং complete match.

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- Publisher certificate/signature verification এখনো পূর্ণাঙ্গ নয়; trusted OEM certificate/manifest chain না থাকলে publisher authenticity VERIFIED বলা যাবে না.
- নতুন evaluator Safety UI-তে রিপোর্ট হিসেবে যুক্ত হয়েছে, কিন্তু এটি সব operation-এর authorization gate নয়.
- Android build, unit tests, emulator ও physical-device tests এই environment-এ চালানো হয়নি; Gradle/SDK availability না থাকায় সেগুলো যাচাই বাকি.
- Destructive partition write, bootloader relock বা Verified Boot weakening/automatic vbmeta patch execution যোগ করা হয়নি.
