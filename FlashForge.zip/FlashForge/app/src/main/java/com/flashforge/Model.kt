package com.flashforge

import android.net.Uri

enum class Mode(val label: String) {
    NONE("NO DEVICE"),
    FASTBOOT("FASTBOOT"),
    ADB("ADB / RECOVERY"),
    SAMSUNG_DOWNLOAD("SAMSUNG DOWNLOAD"),
    QUALCOMM_EDL("QUALCOMM EDL 9008"),
    MEDIATEK_BROM("MEDIATEK BROM / PRELOADER"),
    UNISOC("UNISOC FDL"),
    UNKNOWN("UNKNOWN")
}

enum class Screen(val title: String, val icon: Int) {
    DEVICE("DEVICE", R.drawable.ic_device),
    FLASH("FLASH", R.drawable.ic_flash),
    PART("PARTITION", R.drawable.ic_part),
    UNLOCK("UNLOCK", R.drawable.ic_lock),
    ROM("CUSTOM ROM", R.drawable.ic_rom),
    ROOT("ROOT", R.drawable.ic_root),
    MODES("MODES", R.drawable.ic_modes),
    LOG("LOG", R.drawable.ic_log)
}

data class QItem(val part: String, val uri: Uri, val name: String, val size: Long)
