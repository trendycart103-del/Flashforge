package com.flashforge

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class DeviceDb(private val ctx: Context) {
    private val file = File(ctx.filesDir, "devices.json")
    private var root: JSONObject = load()

    private fun load(): JSONObject = try {
        val txt = if (file.exists()) file.readText()
        else ctx.assets.open("devices.json").bufferedReader().use { it.readText() }
        JSONObject(txt)
    } catch (e: Exception) {
        JSONObject("{\"version\":0,\"vendors\":{},\"models\":[]}")
    }

    val version: Int get() = root.optInt("version")

    fun vendor(vid: Int): String =
        root.optJSONObject("vendors")?.optString("%04x".format(vid), "Unknown vendor") ?: "Unknown vendor"

    fun model(product: String): JSONObject? {
        val a = root.optJSONArray("models") ?: return null
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.optString("product").equals(product, true)) return o
        }
        return null
    }

    fun count(): Int = root.optJSONArray("models")?.length() ?: 0

    /** Blocking network call. Run on a background thread. */
    fun update(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        val txt = c.inputStream.bufferedReader().use { it.readText() }
        val n = JSONObject(txt)
        if (n.optInt("version") < version) return "Local database v$version is newer than remote v${n.optInt("version")}"
        file.writeText(txt)
        root = n
        return "Database updated to v${n.optInt("version")} (${count()} models)"
    }
}
