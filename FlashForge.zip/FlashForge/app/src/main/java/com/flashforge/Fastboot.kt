package com.flashforge

import android.content.ContentResolver
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.net.Uri
import java.io.OutputStream

/** Fastboot protocol over USB bulk endpoints (host side). */
class Fastboot(private val conn: UsbDeviceConnection, private val dev: UsbDevice) {
    private var inEp: UsbEndpoint? = null
    private var outEp: UsbEndpoint? = null
    private var iface: UsbInterface? = null

    class Res(val ok: Boolean, val text: String, val info: List<String>)

    fun open(): Boolean {
        for (i in 0 until dev.interfaceCount) {
            val f = dev.getInterface(i)
            if (f.interfaceClass == 0xFF && f.interfaceSubclass == 0x42 && f.interfaceProtocol == 0x03) {
                var a: UsbEndpoint? = null
                var b: UsbEndpoint? = null
                for (e in 0 until f.endpointCount) {
                    val ep = f.getEndpoint(e)
                    if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                        if (ep.direction == UsbConstants.USB_DIR_IN) a = ep else b = ep
                    }
                }
                if (a != null && b != null && conn.claimInterface(f, true)) {
                    inEp = a; outEp = b; iface = f
                    return true
                }
            }
        }
        return false
    }

    fun close() {
        try { iface?.let { conn.releaseInterface(it) } } catch (e: Exception) { }
        conn.close()
    }

    private fun send(b: ByteArray, len: Int = b.size): Boolean {
        var off = 0
        while (off < len) {
            val n = minOf(16384, len - off)
            val r = conn.bulkTransfer(outEp, b, off, n, 10000)
            if (r < 0) return false
            off += r
        }
        return true
    }

    private fun recv(timeout: Int): String? {
        val buf = ByteArray(512)
        val n = conn.bulkTransfer(inEp, buf, buf.size, timeout)
        return if (n < 0) null else String(buf, 0, n, Charsets.UTF_8)
    }

    fun cmd(c: String, timeout: Int = 60000): Res {
        if (!send(c.toByteArray(Charsets.UTF_8))) return Res(false, "USB write failed", emptyList())
        val info = ArrayList<String>()
        while (true) {
            val r = recv(timeout) ?: return Res(false, "timeout or USB read failed", info)
            when {
                r.startsWith("INFO") -> info.add(r.substring(4))
                r.startsWith("OKAY") -> return Res(true, r.substring(4), info)
                r.startsWith("DATA") -> return Res(true, r, info)
                r.startsWith("FAIL") -> return Res(false, r.substring(4), info)
                else -> return Res(false, "bad response: $r", info)
            }
        }
    }

    fun getvar(name: String): String? {
        val r = cmd("getvar:$name", 5000)
        if (!r.ok) return null
        return r.text.ifEmpty { r.info.firstOrNull() ?: "" }
    }

    fun flash(part: String, resolver: ContentResolver, uri: Uri, size: Long, progress: (Float) -> Unit): Res {
        if (size <= 0) return Res(false, "empty or unknown file size", emptyList())
        val max = getvar("max-download-size")?.trim()?.removePrefix("0x")?.toLongOrNull(16) ?: 0L
        if (max > 0 && size > max) {
            return Res(false, "Image is $size bytes but this bootloader accepts $max per download. Use a sparse image split for this device.", emptyList())
        }
        val d = cmd("download:%08x".format(size))
        if (!d.ok || !d.text.startsWith("DATA")) return Res(false, "download refused: ${d.text}", d.info)
        val ins = resolver.openInputStream(uri) ?: return Res(false, "cannot open file", emptyList())
        ins.use { s ->
            val buf = ByteArray(16384)
            var sent = 0L
            while (sent < size) {
                val want = minOf(buf.size.toLong(), size - sent).toInt()
                val n = s.read(buf, 0, want)
                if (n < 0) return Res(false, "file ended early at $sent", emptyList())
                if (!send(buf, n)) return Res(false, "USB write failed at $sent", emptyList())
                sent += n
                progress(sent.toFloat() / size)
            }
        }
        val ok = recv(60000) ?: return Res(false, "no response after data", emptyList())
        if (!ok.startsWith("OKAY")) return Res(false, ok, emptyList())
        return cmd("flash:$part", 180000)
    }

    /** Reads a partition with the fastboot "fetch" command (needs bootloader support). */
    fun fetch(part: String, out: OutputStream, progress: (Float) -> Unit): Res {
        val r = cmd("fetch:$part")
        if (!r.ok || !r.text.startsWith("DATA")) return Res(false, "fetch not supported or refused: ${r.text}", r.info)
        val total = r.text.substring(4).trim().toLongOrNull(16) ?: return Res(false, "bad size reply", emptyList())
        val buf = ByteArray(65536)
        var got = 0L
        while (got < total) {
            val remain = total - got
            val len = minOf(65536L, ((remain + 511) / 512) * 512).toInt()
            val n = conn.bulkTransfer(inEp, buf, len, 30000)
            if (n < 0) return Res(false, "USB read failed at $got", emptyList())
            val take = minOf(n.toLong(), remain).toInt()
            out.write(buf, 0, take)
            got += take
            progress(got.toFloat() / total)
        }
        val end = recv(30000) ?: return Res(false, "no final response", emptyList())
        return Res(end.startsWith("OKAY"), end.drop(4), emptyList())
    }
}
