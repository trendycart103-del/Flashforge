package com.flashforge

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColor
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.exp

/** Classic light palette: strong, saturated colours on a warm paper background. */
object C {
    val bg = Color(0xFFF4F8FF)
    val panel = Color(0xFFFFFFFF)
    val line = Color(0xFF0B1F4B)
    val ink = Color(0xFF0B1F4B)
    val blue = Color(0xFF0B5FFF)
    val amber = Color(0xFFE65100)
    val green = Color(0xFF007A3D)
    val red = Color(0xFFD50000)
    val yellow = Color(0xFFFFC400)
    val yellowDark = Color(0xFF8A5A00)
    val text = Color(0xFF0B1220)
    val dim = Color(0xFF44506A)
    val off = Color(0xFFD5DAE3)
}

val Mono = FontFamily.Monospace

/** Lamp colour and readable text colour for each connection state. */
val Link.tint: Color get() = when (this) {
    Link.RED -> C.red
    Link.YELLOW -> C.yellow
    Link.GREEN -> C.green
}
val Link.ink: Color get() = when (this) {
    Link.RED -> C.red
    Link.YELLOW -> C.yellowDark
    Link.GREEN -> C.green
}

// ---------------- unique shapes ----------------

fun chamfer(c: Float) = GenericShape { size, _ ->
    moveTo(c, 0f)
    lineTo(size.width, 0f)
    lineTo(size.width, size.height - c)
    lineTo(size.width - c, size.height)
    lineTo(0f, size.height)
    lineTo(0f, c)
    close()
}

val PanelShape = chamfer(34f)
val FieldShape = chamfer(14f)
val TabShape = chamfer(16f)

/** Slanted "tag" button: both ends cut at an angle. */
val BtnShape = GenericShape { size, _ ->
    val s = size.height * 0.3f
    moveTo(s, 0f)
    lineTo(size.width, 0f)
    lineTo(size.width - s, size.height)
    lineTo(0f, size.height)
    close()
}

// ---------------- background ----------------

fun Modifier.blueprint(): Modifier = this.background(C.bg).drawBehind {
    // Soft pastel blobs on a pale blue-white base (pink, mint, lavender, peach).
    val w = size.width
    val h = size.height
    drawCircle(Color(0xFFFFE3EC), radius = w * 0.27f, center = Offset(w * 0.88f, h * 0.06f))
    drawCircle(Color(0xFFD6F5E7), radius = w * 0.27f, center = Offset(w * 0.04f, h * 0.42f))
    drawCircle(Color(0xFFE6E0FB), radius = w * 0.31f, center = Offset(w * 0.00f, h * 0.86f))
    drawCircle(Color(0xFFFBEBCB), radius = w * 0.32f, center = Offset(w * 0.96f, h * 0.83f))
}

// ---------------- basic building blocks ----------------

@Composable
fun T(s: String, c: Color = C.text, sz: Int = 12, bold: Boolean = false, mod: Modifier = Modifier) {
    Text(
        s, color = c, fontFamily = Mono, fontSize = sz.sp,
        fontWeight = if (bold) FontWeight.ExtraBold else FontWeight.SemiBold, modifier = mod
    )
}

@Composable
fun KV(k: String, v: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(k, color = C.dim, fontFamily = Mono, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.45f))
        Text(v, color = C.text, fontFamily = Mono, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(0.55f))
    }
}

/** Transparent box with a chamfered outline. The outline thickens, changes colour and glows on touch or focus. */
@Composable
fun Panel(title: String, content: @Composable ColumnScope.() -> Unit) {
    var focused by remember { mutableStateOf(false) }
    var pressed by remember { mutableStateOf(false) }
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val active = focused || pressed
    val appear by animateFloatAsState(if (shown) 1f else 0f, tween(450), label = "appear")
    val bw by animateDpAsState(if (active) 3.dp else 1.5.dp, tween(200), label = "bw")
    val bc by animateColorAsState(if (active) C.blue else C.ink, tween(250), label = "bc")
    val glow by animateFloatAsState(if (active) 0.16f else 0f, tween(300), label = "glow")
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .graphicsLayer { alpha = appear; translationY = (1f - appear) * 48f }
            .background(Color.White.copy(alpha = 0.55f), PanelShape)
            .background(C.blue.copy(alpha = glow), PanelShape)
            .border(bw, bc, PanelShape)
            .onFocusChanged { focused = it.hasFocus }
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val e = awaitPointerEvent(PointerEventPass.Initial)
                        pressed = e.changes.any { it.pressed }
                    }
                }
            }
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(9.dp).background(C.amber))
            Spacer(Modifier.width(8.dp))
            T(title, C.amber, 12, true)
        }
        Spacer(Modifier.height(8.dp))
        content()
    }
}

@Composable
fun Rw(content: @Composable RowScope.() -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), content = content)
}

/** Picks the graphical icon that is drawn inside a button, from the button label. */
fun iconFor(t: String): Int {
    val u = t.uppercase()
    return when {
        u.startsWith("REFRESH") || u.startsWith("READ TABLE") -> R.drawable.b_refresh
        u.startsWith("SLOT") -> R.drawable.b_slot
        u.startsWith("REBOOT TO RECOVERY") || u == "RECOVERY" -> R.drawable.b_recovery
        u == "SYSTEM" || u.startsWith("REBOOT SYSTEM") -> R.drawable.b_power
        u == "BOOTLOADER" -> R.drawable.b_boot
        u == "FASTBOOTD" -> R.drawable.b_term
        u.startsWith("ADD IMAGE") -> R.drawable.b_image
        u.startsWith("UNPACK") -> R.drawable.b_zip
        u.startsWith("FLASH") -> R.drawable.b_bolt
        u.startsWith("SAVE") -> R.drawable.b_save
        u.startsWith("DOWNLOAD") || u.startsWith("UPDATE") -> R.drawable.b_download
        u.startsWith("ERASE") || u.startsWith("DELETE") || u.startsWith("WIPE") -> R.drawable.b_trash
        u.startsWith("BACKUP") -> R.drawable.b_backup
        u.startsWith("CREATE") -> R.drawable.b_plus
        u.startsWith("RESIZE") -> R.drawable.b_resize
        u.startsWith("UNLOCK") -> R.drawable.b_unlock
        u.startsWith("LOCK") -> R.drawable.b_lock
        u.startsWith("CHOOSE") -> R.drawable.b_folder
        u.startsWith("SIDELOAD") -> R.drawable.b_upload
        u.startsWith("EXPORT") -> R.drawable.b_export
        u.startsWith("CLEAR") -> R.drawable.b_clear
        u.startsWith("GRANT") || u.startsWith("BUBBLE") || u.startsWith("TEST") -> R.drawable.b_bubble
        u.startsWith("ALLOW") -> R.drawable.b_bell
        else -> 0
    }
}

/** Small round graphical icon button (used in the flash queue). */
@Composable
fun IconBtn(res: Int, on: () -> Unit) {
    Box(
        Modifier
            .padding(horizontal = 3.dp)
            .size(34.dp)
            .clip(CircleShape)
            .background(Color.White)
            .border(1.5.dp, C.ink, CircleShape)
            .clickable(onClick = on),
        contentAlignment = Alignment.Center
    ) { Image(painterResource(res), null, Modifier.size(20.dp)) }
}

/** Gradient pairs (start, end) in the style of the reference screenshot. */
private val BtnGradients = listOf(
    Color(0xFFFF5252) to Color(0xFFFFB300),  // coral to amber
    Color(0xFF00B0FF) to Color(0xFF5B5BFF),  // sky to indigo
    Color(0xFF00C98D) to Color(0xFF0E9AA7),  // green to teal
    Color(0xFF8E5BFF) to Color(0xFFE040C8),  // violet to magenta
    Color(0xFF1E88E5) to Color(0xFF26A69A),  // blue to teal
    Color(0xFFFF7043) to Color(0xFFEC407A)   // orange to pink
)
private val DangerGradient = Color(0xFFFF3D57) to Color(0xFFFF8A3D)

@Composable
fun Btn(t: String, enabled: Boolean = true, danger: Boolean = false, mod: Modifier = Modifier, icon: Int = iconFor(t), on: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pr by src.collectIsPressedAsState()
    val sc by animateFloatAsState(
        if (pr) 0.94f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "btnScale"
    )
    val (g1, g2) = if (danger) DangerGradient else BtnGradients[(t.hashCode() and 0x7fffffff) % BtnGradients.size]
    val brush = if (enabled) Brush.linearGradient(listOf(g1, g2)) else Brush.linearGradient(listOf(C.off, C.off))
    Button(
        onClick = on, enabled = enabled,
        modifier = mod
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .then(if (enabled) Modifier.shadow(10.dp, BtnShape, ambientColor = g2, spotColor = g1) else Modifier)
            .background(brush, BtnShape),
        shape = BtnShape,
        interactionSource = src,
        elevation = null,
        border = BorderStroke(1.dp, if (enabled) Color.White.copy(alpha = 0.45f) else C.off),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent, contentColor = Color.White,
            disabledContainerColor = Color.Transparent, disabledContentColor = C.dim
        )
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != 0) {
                Box(Modifier.size(24.dp).background(Color.White, CircleShape), contentAlignment = Alignment.Center) {
                    Image(painterResource(icon), null, Modifier.size(17.dp), alpha = if (enabled) 1f else 0.45f)
                }
                Spacer(Modifier.width(8.dp))
            }
            Text(t, fontFamily = Mono, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}

@Composable
fun ConfirmBtn(t: String, msg: String, enabled: Boolean = true, danger: Boolean = true, mod: Modifier = Modifier, go: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Btn(t, enabled, danger, mod) { open = true }
    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            confirmButton = { TextButton(onClick = { open = false; go() }) { Text("CONFIRM", color = C.red, fontFamily = Mono, fontWeight = FontWeight.ExtraBold) } },
            dismissButton = { TextButton(onClick = { open = false }) { Text("CANCEL", color = C.dim, fontFamily = Mono, fontWeight = FontWeight.Bold) } },
            title = { Text(t, fontFamily = Mono, fontWeight = FontWeight.ExtraBold) },
            text = { Text(msg, fontFamily = Mono, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) },
            shape = PanelShape,
            containerColor = Color.White, titleContentColor = C.amber, textContentColor = C.text
        )
    }
}

@Composable
fun Field(v: String, onv: (String) -> Unit, label: String) {
    OutlinedTextField(
        value = v, onValueChange = onv, singleLine = true, modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        shape = FieldShape,
        label = { Text(label, fontFamily = Mono, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
        textStyle = TextStyle(fontFamily = Mono, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = C.text),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = C.text, unfocusedTextColor = C.text,
            focusedContainerColor = Color.White.copy(alpha = 0.55f),
            unfocusedContainerColor = Color.White.copy(alpha = 0.30f),
            focusedBorderColor = C.blue, unfocusedBorderColor = C.ink.copy(alpha = 0.55f),
            focusedLabelColor = C.blue, unfocusedLabelColor = C.dim, cursorColor = C.blue
        )
    )
}

@Composable
fun PickBtn(label: String, mod: Modifier = Modifier, on: (Uri) -> Unit) {
    val l = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) on(u) }
    Btn(label, mod = mod) { l.launch(arrayOf("*/*")) }
}

// ---------------- heartbeat header ----------------

fun bump(x: Float, c: Float, w: Float): Float {
    val d = (x - c) / w
    return exp(-d * d)
}

/** One ECG beat, t in 0..1. */
fun ecg(t: Float): Float =
    0.14f * bump(t, 0.16f, 0.035f) -
        0.12f * bump(t, 0.36f, 0.010f) +
        1.00f * bump(t, 0.40f, 0.012f) -
        0.30f * bump(t, 0.44f, 0.012f) +
        0.28f * bump(t, 0.66f, 0.050f)

@Composable
fun Heartbeat(col: Color, active: Boolean, ph: Float) {
    Canvas(Modifier.fillMaxWidth().height(46.dp)) {
        val period = 160.dp.toPx()
        val amp = size.height * (if (active) 0.42f else 0.10f)
        val mid = size.height * 0.58f
        drawLine(col.copy(alpha = 0.25f), Offset(0f, mid), Offset(size.width, mid), strokeWidth = 1.5f)
        val path = Path()
        var x = 0f
        var first = true
        while (x <= size.width) {
            val t = ((x / period) + ph) % 1f
            val y = mid - amp * ecg(t)
            if (first) { path.moveTo(x, y); first = false } else path.lineTo(x, y)
            x += 3f
        }
        drawPath(path, col, style = Stroke(width = 3.5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        val hx = size.width * 0.88f
        val hy = mid - amp * ecg(((hx / period) + ph) % 1f)
        drawCircle(col.copy(alpha = 0.30f), 14f, Offset(hx, hy))
        drawCircle(col, 6f, Offset(hx, hy))
    }
}

@Composable
fun Header(vm: MainVM) {
    val active = vm.link != Link.RED
    val inf = rememberInfiniteTransition(label = "hb")
    val ph by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1500, easing = LinearEasing), RepeatMode.Restart), label = "phase")
    val ring by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart), label = "ring")
    val titleColor by inf.animateColor(
        C.blue, C.amber, infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "title"
    )
    val beat = 1f + 0.16f * bump(ph, 0.40f, 0.025f) + 0.08f * bump(ph, 0.62f, 0.05f)
    val ringColor = vm.link.tint
    Column(
        Modifier.fillMaxWidth()
            .background(Color.White.copy(alpha = 0.75f))
            .drawBehind { drawLine(C.blue, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = 5f) }
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(60.dp).drawBehind {
                    drawCircle(
                        color = ringColor.copy(alpha = (1f - ring) * 0.6f),
                        radius = size.minDimension / 2f * (0.55f + 0.45f * ring),
                        style = Stroke(3f)
                    )
                },
                contentAlignment = Alignment.Center
            ) {
                Image(painterResource(R.drawable.ic_logo), null, Modifier.size(46.dp).graphicsLayer { scaleX = beat; scaleY = beat })
            }
            Spacer(Modifier.width(10.dp))
            Column {
                T("FLASHFORGE", titleColor, 18, true)
                if (vm.mode == Mode.NONE) T("no device - connect the phone with an OTG cable", C.red, 11, true)
                else T(vm.vendor + "  |  " + vm.usbId + "  |  " + vm.mode.label, vm.link.ink, 11, true)
            }
        }
        Heartbeat(vm.link.tint, active, ph)
    }
}

// ---------------- connection light box ----------------

@Composable
fun Lamp(c: Color, lit: Boolean) {
    val a by animateFloatAsState(if (lit) 1f else 0.14f, tween(150), label = "lamp")
    Box(
        Modifier
            .size(28.dp)
            .drawBehind {
                if (a > 0.5f) drawCircle(c.copy(alpha = 0.30f * a), radius = size.minDimension * 0.85f)
            }
            .background(c.copy(alpha = a), CircleShape)
            .border(2.dp, C.ink, CircleShape)
    )
}

/** Three lamps: red = no connection, yellow (blinking) = connecting or unstable, green = stable. */
@Composable
fun LinkBox(vm: MainVM) {
    val l = vm.link
    val inf = rememberInfiniteTransition(label = "link")
    val blink by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(450, easing = LinearEasing), RepeatMode.Reverse), label = "blink")
    val main by animateColorAsState(l.tint, tween(300), label = "linkColor")
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .background(Color.White.copy(alpha = 0.55f), PanelShape)
            .background(main.copy(alpha = 0.12f), PanelShape)
            .border(2.dp, main, PanelShape)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Lamp(C.red, l == Link.RED)
        Spacer(Modifier.width(12.dp))
        Lamp(C.yellow, l == Link.YELLOW && blink > 0.5f)
        Spacer(Modifier.width(12.dp))
        Lamp(C.green, l == Link.GREEN)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            T(l.label, l.ink, 13, true)
            T(vm.linkNote, C.dim, 10, true)
        }
        T(vm.linkPct.toString() + "%", l.ink, 16, true)
    }
}

// ---------------- animated tabs ----------------

@Composable
fun TabItem(s: Screen, sel: Boolean, onClick: () -> Unit) {
    val sc by animateFloatAsState(
        if (sel) 1.2f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "tabScale"
    )
    val col by animateColorAsState(if (sel) C.blue else C.dim, tween(250), label = "tabColor")
    val bar by animateDpAsState(if (sel) 30.dp else 0.dp, tween(300), label = "tabBar")
    val bgA by animateFloatAsState(if (sel) 0.14f else 0f, tween(300), label = "tabBg")
    Column(
        Modifier
            .padding(horizontal = 3.dp, vertical = 6.dp)
            .clip(TabShape)
            .background(C.blue.copy(alpha = bgA))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painterResource(s.icon), null,
            Modifier.size(30.dp).graphicsLayer { scaleX = sc; scaleY = sc; alpha = if (sel) 1f else 0.8f }
        )
        T(s.title, col, 10, true)
        Spacer(Modifier.height(2.dp))
        Box(Modifier.height(3.dp).width(bar).background(col))
    }
}

@Composable
fun TabBar(vm: MainVM) {
    Row(
        Modifier.fillMaxWidth()
            .background(Color.White.copy(alpha = 0.70f))
            .drawBehind { drawLine(C.ink.copy(alpha = 0.25f), Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = 2f) }
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 4.dp)
    ) {
        Screen.values().forEach { s -> TabItem(s, vm.screen == s) { vm.screen = s } }
    }
}

@Composable
fun Footer(vm: MainVM) {
    val p by animateFloatAsState(if (vm.busy) vm.progress else 0f, tween(200), label = "progress")
    Column(
        Modifier.fillMaxWidth()
            .background(Color.White.copy(alpha = 0.80f))
            .drawBehind { drawLine(C.ink.copy(alpha = 0.25f), Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = 2f) }
            .padding(8.dp)
    ) {
        if (vm.busy && vm.progress <= 0f) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(4.dp), color = C.blue, trackColor = C.off)
        } else {
            LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth().height(4.dp), color = C.blue, trackColor = C.off)
        }
        Spacer(Modifier.height(4.dp))
        T(vm.logs.lastOrNull() ?: "Ready", C.dim, 11, true)
    }
}

@Composable
fun AppUi(vm: MainVM) {
    MaterialTheme(
        colorScheme = lightColorScheme(primary = C.blue, background = C.bg, surface = Color.White, onSurface = C.text, onBackground = C.text)
    ) {
        Column(Modifier.fillMaxSize().blueprint()) {
            Header(vm)
            LinkBox(vm)
            TabBar(vm)
            Box(Modifier.weight(1f).fillMaxWidth()) {
                AnimatedContent(
                    targetState = vm.screen,
                    transitionSpec = {
                        (fadeIn(tween(280)) + slideInHorizontally(tween(280)) { it / 8 }) togetherWith fadeOut(tween(120))
                    },
                    label = "screen"
                ) { s ->
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(10.dp)) {
                        when (s) {
                            Screen.DEVICE -> DevicePage(vm)
                            Screen.FLASH -> FlashPage(vm)
                            Screen.PART -> PartPage(vm)
                            Screen.UNLOCK -> UnlockPage(vm)
                            Screen.ROM -> RomPage(vm)
                            Screen.ROOT -> RootPage(vm)
                            Screen.MODES -> ModesPage(vm)
                            Screen.LOG -> LogPage(vm)
                        }
                    }
                }
            }
            Footer(vm)
        }
        vm.cableWarn?.let { why ->
            AlertDialog(
                onDismissRequest = { },
                icon = { Image(painterResource(R.drawable.ic_cable), null, Modifier.size(52.dp)) },
                title = { Text("CHANGE THE DATA CABLE", fontFamily = Mono, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp) },
                text = {
                    Column {
                        Text(why, fontFamily = Mono, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Use a short, good quality DATA cable (not a charge-only cable) and plug it straight into the phone or a good OTG adapter, without a hub. The task keeps running; if it fails, swap the cable and run it again.",
                            fontFamily = Mono, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                        )
                    }
                },
                confirmButton = { TextButton(onClick = { vm.cableChange() }) { Text("I WILL CHANGE IT", color = C.blue, fontFamily = Mono, fontWeight = FontWeight.ExtraBold) } },
                dismissButton = { TextButton(onClick = { vm.cableContinue() }) { Text("CONTINUE ANYWAY", color = C.dim, fontFamily = Mono, fontWeight = FontWeight.Bold) } },
                shape = PanelShape,
                containerColor = Color.White, titleContentColor = C.red, textContentColor = C.text
            )
        }
    }
}
