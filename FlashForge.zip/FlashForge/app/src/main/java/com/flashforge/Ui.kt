package com.flashforge

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.sin

object C {
    val bg = Color(0xFF14171A)
    val panel = Color(0xFF1C2024)
    val line = Color(0xFF2E343A)
    val amber = Color(0xFFFFB000)
    val green = Color(0xFF3DDC84)
    val red = Color(0xFFFF4D4D)
    val text = Color(0xFFE6E6E6)
    val dim = Color(0xFF8A939B)
}

val Mono = FontFamily.Monospace

fun Modifier.blueprint(): Modifier = this.background(C.bg).drawBehind {
    val s = 32.dp.toPx()
    val col = C.line.copy(alpha = 0.35f)
    var x = 0f
    while (x < size.width) { drawLine(col, Offset(x, 0f), Offset(x, size.height)); x += s }
    var y = 0f
    while (y < size.height) { drawLine(col, Offset(0f, y), Offset(size.width, y)); y += s }
}

@Composable
fun T(s: String, c: Color = C.text, sz: Int = 12, bold: Boolean = false, mod: Modifier = Modifier) {
    Text(s, color = c, fontFamily = Mono, fontSize = sz.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal, modifier = mod)
}

@Composable
fun KV(k: String, v: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(k, color = C.dim, fontFamily = Mono, fontSize = 12.sp, modifier = Modifier.weight(0.45f))
        Text(v, color = C.text, fontFamily = Mono, fontSize = 12.sp, modifier = Modifier.weight(0.55f))
    }
}

@Composable
fun Panel(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 6.dp)
            .border(1.dp, C.line).background(C.panel).padding(10.dp)
    ) {
        T(title, C.amber, 11, true)
        Spacer(Modifier.height(8.dp))
        content()
    }
}

@Composable
fun Rw(content: @Composable RowScope.() -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), content = content)
}

@Composable
fun Btn(t: String, enabled: Boolean = true, danger: Boolean = false, mod: Modifier = Modifier, on: () -> Unit) {
    Button(
        onClick = on, enabled = enabled, modifier = mod, shape = RoundedCornerShape(2.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (danger) C.red else C.amber, contentColor = Color.Black,
            disabledContainerColor = C.line, disabledContentColor = C.dim
        )
    ) { Text(t, fontFamily = Mono, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun ConfirmBtn(t: String, msg: String, enabled: Boolean = true, danger: Boolean = true, mod: Modifier = Modifier, go: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Btn(t, enabled, danger, mod) { open = true }
    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            confirmButton = { TextButton(onClick = { open = false; go() }) { Text("CONFIRM", color = C.red, fontFamily = Mono) } },
            dismissButton = { TextButton(onClick = { open = false }) { Text("CANCEL", color = C.dim, fontFamily = Mono) } },
            title = { Text(t, fontFamily = Mono) },
            text = { Text(msg, fontFamily = Mono, fontSize = 13.sp) },
            containerColor = C.panel, titleContentColor = C.amber, textContentColor = C.text
        )
    }
}

@Composable
fun Field(v: String, onv: (String) -> Unit, label: String) {
    OutlinedTextField(
        value = v, onValueChange = onv, singleLine = true, modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        label = { Text(label, fontFamily = Mono, fontSize = 11.sp) },
        textStyle = TextStyle(fontFamily = Mono, fontSize = 13.sp, color = C.text),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = C.amber, unfocusedBorderColor = C.line,
            focusedLabelColor = C.amber, unfocusedLabelColor = C.dim, cursorColor = C.amber
        )
    )
}

@Composable
fun PickBtn(label: String, mod: Modifier = Modifier, on: (Uri) -> Unit) {
    val l = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) on(u) }
    Btn(label, mod = mod) { l.launch(arrayOf("*/*")) }
}

@Composable
fun Wave(active: Boolean) {
    val t = rememberInfiniteTransition(label = "wave")
    val ph by t.animateFloat(0f, 6.2832f, infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Restart), label = "phase")
    Canvas(Modifier.fillMaxWidth().height(26.dp)) {
        val p = Path()
        val amp = if (active) size.height * 0.38f else size.height * 0.04f
        var x = 0f
        while (x <= size.width) {
            val y = size.height / 2 + amp * sin(x / 16f + ph) * sin(x / 90f + 1f)
            if (x == 0f) p.moveTo(x, y) else p.lineTo(x, y)
            x += 4f
        }
        drawPath(p, if (active) C.green else C.dim, style = Stroke(2f))
    }
}

@Composable
fun Header(vm: MainVM) {
    Column(Modifier.fillMaxWidth().background(C.panel).padding(horizontal = 12.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.ic_logo), null, Modifier.size(34.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                T("FLASHFORGE", C.amber, 16, true)
                if (vm.mode == Mode.NONE) T("no device - connect the phone with an OTG cable", C.red, 11)
                else T(vm.vendor + "  |  " + vm.usbId + "  |  " + vm.mode.label, C.green, 11)
            }
        }
        Wave(vm.mode != Mode.NONE)
    }
}

@Composable
fun TabBar(vm: MainVM) {
    Row(Modifier.fillMaxWidth().background(C.panel).horizontalScroll(rememberScrollState())) {
        Screen.values().forEach { s ->
            val sel = vm.screen == s
            Column(
                Modifier.clickable { vm.screen = s }.padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(painterResource(s.icon), null, tint = if (sel) C.amber else C.dim, modifier = Modifier.size(22.dp))
                T(s.title, if (sel) C.amber else C.dim, 9)
                Box(Modifier.height(2.dp).width(24.dp).background(if (sel) C.amber else Color.Transparent))
            }
        }
    }
}

@Composable
fun Footer(vm: MainVM) {
    Column(Modifier.fillMaxWidth().background(C.panel).padding(8.dp)) {
        LinearProgressIndicator(
            progress = { if (vm.busy) vm.progress else 0f },
            modifier = Modifier.fillMaxWidth().height(3.dp), color = C.amber, trackColor = C.line
        )
        Spacer(Modifier.height(4.dp))
        T(vm.logs.lastOrNull() ?: "Ready", C.dim, 11)
    }
}

@Composable
fun AppUi(vm: MainVM) {
    MaterialTheme(
        colorScheme = darkColorScheme(primary = C.amber, background = C.bg, surface = C.panel, onSurface = C.text, onBackground = C.text)
    ) {
        Column(Modifier.fillMaxSize().blueprint()) {
            Header(vm)
            TabBar(vm)
            Box(Modifier.weight(1f).fillMaxWidth()) {
                Column(Modifier.verticalScroll(rememberScrollState()).padding(10.dp)) {
                    when (vm.screen) {
                        Screen.DEVICE -> DevicePage(vm)
                        Screen.FLASH -> FlashPage(vm)
                        Screen.PART -> PartPage(vm)
                        Screen.UNLOCK -> UnlockPage(vm)
                        Screen.ROM -> RomPage(vm)
                        Screen.ROOT -> RootPage(vm)
                        Screen.MODES -> ModesPage(vm)
                        Screen.LOG -> LogPage(vm)
                    }
                }
            }
            Footer(vm)
        }
    }
}
