package com.flashforge

import android.app.Application
import android.app.PendingIntent
import android.content.Context
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.zip.ZipInputStream

class MainVM(app: Application) : AndroidViewModel(app) {
    companion object { const val ACTION = "com.flashforge.USB_PERMISSION" }

    private val ctx = app
    private val usb = app.getSystemService(Context.USB_SERVICE) as UsbManager
    private val prefs = app.getSharedPreferences("flashforge", Context.MODE_PRIVATE)
    private val db = DeviceDb(app)
    private var fb: Fastboot? = null

    var screen by mutableStateOf(Screen.DEVICE)
    var device by mutableStateOf<UsbDevice?>(null)
    var mode by mutableStateOf(Mode.NONE)
    var vendor by mutableStateOf("")
    var usbId by mutableStateOf("")
    var product by mutableStateOf("")
    var modelName by mutableStateOf("")
    var modelNote by mutableStateOf("")
    var chip by mutableStateOf("")
    var isAB by mutableStateOf(false)
    var unlocked by mutableStateOf("?")
    var slot by mutableStateOf("?")
    var userspace by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var progress by mutableFloatStateOf(0f)
    var expected by mutableStateOf(prefs.getString("expected", "") ?: "")
    var dbUrl by mutableStateOf(prefs.getString("dburl", "") ?: "")
    var dbInfo by mutableStateOf("v${db.version}, ${db.count()} models")

    // ---- cable alert and floating bubble ----
    var cableWarn by mutableStateOf<String?>(null)
    var bubbleOn by mutableStateOf(prefs.getBoolean("bubble", true))
    var overlayOk by mutableStateOf(false)
    var notifOk by mutableStateOf(true)
    private var slowCount = 0
    private var cableIgnored = false
    @Volatile private var failed = false
    private val slowMbs = 2.0

    val vars = mutableStateMapOf<String, String>()
    val parts = mutableStateListOf<String>()
    val queue = mutableStateListOf<QItem>()
    val logs = mutableStateListOf<String>()

    // ---- connection light (red / yellow / green) ----
    var link by mutableStateOf(Link.RED)
    var linkNote by mutableStateOf("No device. Connect the phone with an OTG cable.")
    var linkPct by mutableStateOf(0)
    private var pending = false
    private var connecting = false
    private var ready = false
    private var connectedAt = 0L
    private val detachTimes = ArrayList<Long>()

    init {
        FlashStatus.bubbleOn = bubbleOn
        refreshPerms()
        viewModelScope.launch {
            while (true) {
                delay(500)
                updateLink()
            }
        }
    }

    /** Main thread only. Red = no link, yellow = connecting or dropping, green = stable and ready. */
    private fun updateLink() {
        val now = System.currentTimeMillis()
        detachTimes.removeAll { now - it > 20000 }
        val flapping = detachTimes.size >= 2
        val r = when {
            flapping -> {
                raiseCable("The USB connection dropped ${detachTimes.size} times in 20 seconds.")
                Triple(Link.YELLOW, "Connection keeps dropping. Check the cable and OTG adapter.", 35)
            }
            pending -> Triple(Link.YELLOW, "Waiting for USB permission. Tap Allow.", 20)
            device == null -> Triple(Link.RED, "No device. Connect the phone with an OTG cable.", 0)
            connecting -> Triple(Link.YELLOW, "Connecting and reading the device...", 60)
            ready && now - connectedAt >= 2000 -> Triple(Link.GREEN, "Stable connection. Ready.", 100)
            ready -> Triple(Link.YELLOW, "Verifying the link...", 90)
            else -> Triple(Link.YELLOW, "Device found but not ready. Put it in a known mode.", 50)
        }
        link = r.first
        linkNote = r.second
        linkPct = r.third
    }

    private fun markReady() {
        connectedAt = System.currentTimeMillis()
        ready = true
    }

    fun log(s: String) {
        logs.add(s)
        if (logs.size > 400) logs.removeAt(0)
    }

    private fun hex(i: Int) = "%04X".format(i)

    private fun io(label: String, bubble: Boolean = false, block: () -> Unit) {
        if (busy) { log("Busy. Wait for the current task to finish."); return }
        busy = true
        progress = 0f
        cableIgnored = false
        slowCount = 0
        failed = false
        if (bubble) {
            FlashStatus.label = label
            FlashStatus.progress = 0f
            FlashStatus.speed = 0.0
            FlashStatus.warn = false
            FlashStatus.warnText = ""
            FlashStatus.result = 0
            FlashStatus.running = true
            startBubble()
        }
        viewModelScope.launch(Dispatchers.IO) {
            try { block() } catch (e: Exception) { failed = true; log("ERROR [$label]: ${e.message}") } finally {
                busy = false
                if (bubble) {
                    if (!failed) FlashStatus.progress = 1f
                    FlashStatus.result = if (failed) 2 else 1
                    FlashStatus.running = false
                }
            }
        }
    }

    // ---------------- cable alert ----------------

    private fun prog(f: Float) {
        progress = f
        FlashStatus.progress = f
    }

    /** Progress callback that also measures the real USB speed once per second. */
    private fun speedProbe(total: () -> Long): (Float) -> Unit {
        var t0 = System.nanoTime()
        var b0 = 0L
        return { f ->
            prog(f)
            val now = System.nanoTime()
            if (now - t0 >= 1_000_000_000L) {
                val b = (f * total()).toLong()
                val mbs = (b - b0) / 1048576.0 / ((now - t0) / 1e9)
                t0 = now
                b0 = b
                onSpeed(mbs)
            }
        }
    }

    private fun onSpeed(mbs: Double) {
        FlashStatus.speed = mbs
        if (mbs < slowMbs) {
            slowCount++
            if (slowCount >= 3) raiseCable("The transfer speed is only " + String.format("%.1f", mbs) + " MB/s. A good data cable should be much faster.")
        } else slowCount = 0
    }

    private fun usbCheck(r: Fastboot.Res) {
        if (r.ok) return
        failed = true
        val t = r.text
        if (t.contains("USB", true) || t.contains("timeout", true) || t.contains("no response", true)) {
            raiseCable("A USB transfer error happened: $t")
        }
    }

    private fun raiseCable(why: String) {
        if (cableIgnored || cableWarn != null) return
        cableWarn = why
        FlashStatus.warnText = why
        FlashStatus.warn = true
        FlashStatus.warnSeq = FlashStatus.warnSeq + 1
        log("CABLE WARNING: $why")
    }

    fun cableContinue() {
        cableIgnored = true
        cableWarn = null
        FlashStatus.warn = false
        log("Cable warning ignored for this task")
    }

    fun cableChange() {
        slowCount = 0
        detachTimes.clear()
        cableWarn = null
        FlashStatus.warn = false
        log("Change the data cable, then run the task again if it failed")
    }

    // ---------------- floating bubble ----------------

    private fun startBubble() {
        if (!Settings.canDrawOverlays(ctx)) log("Floating bubble is off: grant the overlay permission in the Device tab.")
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, BubbleService::class.java))
        } catch (e: Exception) {
            log("Bubble service not started: ${e.message}")
        }
    }

    fun refreshPerms() {
        overlayOk = Settings.canDrawOverlays(ctx)
        notifOk = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }

    fun toggleBubble() {
        bubbleOn = !bubbleOn
        FlashStatus.bubbleOn = bubbleOn
        prefs.edit().putBoolean("bubble", bubbleOn).apply()
    }

    /** 20 second demo: press Home while it runs to see the bubble over the launcher. */
    fun testBubble() {
        if (busy) return
        busy = true
        failed = false
        FlashStatus.label = "Bubble test"
        FlashStatus.progress = 0f
        FlashStatus.speed = 0.0
        FlashStatus.warn = false
        FlashStatus.warnText = ""
        FlashStatus.result = 0
        FlashStatus.running = true
        startBubble()
        log("Bubble test for 20 seconds. Press Home to see the bubble.")
        viewModelScope.launch {
            for (i in 1..80) {
                delay(250)
                prog(i / 80f)
                FlashStatus.speed = 18.0 + (i % 5)
            }
            FlashStatus.result = 1
            FlashStatus.running = false
            busy = false
            progress = 0f
        }
    }

    private fun need(): Fastboot = fb ?: throw IOException("No fastboot device connected")

    // ---------------- USB connection ----------------

    fun scan() {
        val d = usb.deviceList.values.firstOrNull()
        if (d == null) { if (device != null) onDetached(); return }
        if (device?.deviceId == d.deviceId && mode != Mode.NONE) return
        if (usb.hasPermission(d)) connect(d) else {
            val pi = PendingIntent.getBroadcast(
                ctx, 0, Intent(ACTION).setPackage(ctx.packageName),
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            pending = true
            usb.requestPermission(d, pi)
        }
        updateLink()
    }

    private fun connect(d: UsbDevice) {
        device = d
        mode = ModeDetector.detect(d)
        vendor = db.vendor(d.vendorId)
        usbId = hex(d.vendorId) + ":" + hex(d.productId)
        chip = ModeDetector.chipHint(mode)
        log("Detected $vendor  USB $usbId  mode ${mode.label}")
        screen = when (mode) {
            Mode.FASTBOOT -> Screen.DEVICE
            Mode.ADB -> Screen.ROM
            else -> Screen.MODES
        }
        pending = false
        ready = false
        connecting = mode == Mode.FASTBOOT
        if (mode == Mode.FASTBOOT) io("Connect") {
            try {
                val c = usb.openDevice(d) ?: throw IOException("openDevice failed")
                val f = Fastboot(c, d)
                if (!f.open()) { c.close(); throw IOException("Cannot claim the fastboot interface") }
                fb = f
                refreshInternal(f)
                markReady()
            } finally {
                connecting = false
            }
        } else {
            if (mode != Mode.UNKNOWN) markReady()
        }
        updateLink()
    }

    fun onDetached() {
        if (device != null) detachTimes.add(System.currentTimeMillis())
        pending = false; connecting = false; ready = false
        try { fb?.close() } catch (e: Exception) { }
        fb = null
        device = null; mode = Mode.NONE; vendor = ""; usbId = ""; product = ""
        modelName = ""; modelNote = ""; chip = ""; slot = "?"; unlocked = "?"
        isAB = false; userspace = false; busy = false
        log("Device disconnected")
        updateLink()
    }

    // ---------------- device info ----------------

    private fun refreshInternal(f: Fastboot) {
        vars.clear(); parts.clear()
        val all = f.cmd("getvar:all", 20000)
        all.info.forEach { l ->
            if (l.startsWith("partition-size:")) parts.add(l.removePrefix("partition-size:").trim())
            else {
                val i = l.indexOf(": ")
                if (i > 0) vars[l.substring(0, i).trim()] = l.substring(i + 2).trim()
            }
        }
        product = f.getvar("product") ?: ""
        slot = f.getvar("current-slot")?.trim()?.removePrefix("_") ?: "?"
        isAB = (f.getvar("slot-count")?.trim()?.toIntOrNull() ?: 0) > 1
        unlocked = f.getvar("unlocked") ?: "?"
        userspace = f.getvar("is-userspace")?.trim() == "yes"
        val m = db.model(product)
        if (m != null) {
            modelName = m.optString("brand") + " " + m.optString("name")
            modelNote = m.optString("note")
            chip = m.optString("chip")
        } else {
            modelName = "Not in database"
            modelNote = "Add this product ID to devices.json or update the database in the Log tab."
        }
        log("Product '$product'  slot $slot  unlocked $unlocked  A/B $isAB  fastbootd $userspace")
    }

    fun refresh() = io("Refresh") { refreshInternal(need()) }

    fun changeExpected(s: String) {
        expected = s
        prefs.edit().putString("expected", s).apply()
    }

    private fun guardOk(): Boolean {
        if (expected.isNotBlank() && !expected.equals(product, true)) {
            log("BLOCKED: expected product '$expected' but connected device reports '$product'")
            return false
        }
        return true
    }

    // ---------------- fastboot commands ----------------

    fun fbCmd(c: String) = io(c) {
        if (c.startsWith("erase") && !guardOk()) return@io
        val r = need().cmd(c, 120000)
        log("> $c => ${if (r.ok) "OKAY" else "FAIL"} ${r.text}")
        r.info.forEach { log("  $it") }
    }

    fun changeSlot(s: String) = io("Slot") {
        val f = need()
        val r = f.cmd("set_active:$s")
        log("set_active:$s => ${if (r.ok) "OKAY" else "FAIL " + r.text}")
        slot = f.getvar("current-slot")?.trim()?.removePrefix("_") ?: "?"
        log("Active slot is now $slot")
    }

    fun wipe() = io("Wipe", true) {
        if (!guardOk()) return@io
        val f = need()
        val a = f.cmd("erase:userdata", 120000)
        log("erase:userdata => ${if (a.ok) "OKAY" else "FAIL " + a.text}")
        val b = f.cmd("erase:metadata", 60000)
        log("erase:metadata => ${if (b.ok) "OKAY" else "skipped (" + b.text + ")"}")
    }

    private fun meta(uri: Uri): Pair<String, Long> {
        var name = "file"
        var size = 0L
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = c.getString(ni) ?: "file"
                if (si >= 0) size = c.getLong(si)
            }
        }
        if (size == 0L && uri.scheme == "file") {
            val f = File(uri.path ?: "")
            name = f.name; size = f.length()
        }
        return Pair(name, size)
    }

    fun flashOne(part: String, uri: Uri) = io("Flash", true) {
        if (!guardOk()) return@io
        val (n, s) = meta(uri)
        val p = part.ifBlank { n.substringBeforeLast('.') }
        val r = need().flash(p, ctx.contentResolver, uri, s, speedProbe { s })
        usbCheck(r)
        log("flash $n -> $p => ${if (r.ok) "OKAY" else "FAIL " + r.text}")
    }

    /** Flashes vbmeta with verity and verification disabled (flags field patched to 3). */
    fun flashVbmeta(uri: Uri) = io("Flash vbmeta", true) {
        if (!guardOk()) return@io
        val b = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IOException("cannot open file")
        if (b.size < 256 || String(b, 0, 4) != "AVB0") throw IOException("Not a vbmeta image")
        b[120] = 0; b[121] = 0; b[122] = 0; b[123] = 3
        val f = File(ctx.cacheDir, "vbmeta_patched.img")
        f.writeBytes(b)
        val r = need().flash("vbmeta", ctx.contentResolver, Uri.fromFile(f), f.length(), speedProbe { f.length() })
        usbCheck(r)
        log("flash vbmeta (verity and verification disabled) => ${if (r.ok) "OKAY" else "FAIL " + r.text}")
    }

    fun backup(p: String) = io("Backup", true) {
        val dir = File(ctx.getExternalFilesDir(null), "backups")
        dir.mkdirs()
        val out = File(dir, "$p.img")
        var tot = 1L
        val r = out.outputStream().use { need().fetch(p, it, { n -> tot = n }, speedProbe { tot }) }
        usbCheck(r)
        log("backup $p => ${if (r.ok) "OKAY " + out.absolutePath else "FAIL " + r.text}")
        if (!r.ok) out.delete()
    }

    // ---------------- queue, hash, profiles ----------------

    fun addFile(uri: Uri, part: String) {
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) { }
        val (n, s) = meta(uri)
        queue.add(QItem(part.ifBlank { n.substringBeforeLast('.').lowercase() }, uri, n, s))
    }

    fun move(i: Int) {
        if (i > 0 && i < queue.size) {
            val x = queue.removeAt(i)
            queue.add(i - 1, x)
        }
    }

    fun flashQueue() = io("Flash queue", true) {
        if (!guardOk()) return@io
        val f = need()
        queue.toList().forEachIndexed { i, q ->
            log("[${i + 1}/${queue.size}] ${q.name} -> ${q.part}")
            val r = f.flash(q.part, ctx.contentResolver, q.uri, q.size, speedProbe { q.size })
            r.info.forEach { log("  $it") }
            usbCheck(r)
            if (!r.ok) { log("FAIL: ${r.text}  (queue stopped)"); return@io }
            log("OKAY")
        }
        log("Queue finished")
    }

    fun hash(q: QItem, expect: String) = io("SHA-256") {
        val md = MessageDigest.getInstance("SHA-256")
        val ins = ctx.contentResolver.openInputStream(q.uri) ?: throw IOException("cannot open file")
        ins.use { s ->
            val b = ByteArray(65536)
            var t = 0L
            while (true) {
                val n = s.read(b)
                if (n < 0) break
                md.update(b, 0, n)
                t += n
                prog(t.toFloat() / maxOf(q.size, 1L))
            }
        }
        val h = md.digest().joinToString("") { "%02x".format(it) }
        log("SHA-256 ${q.name}: $h")
        if (expect.isNotBlank()) log(if (h.equals(expect.trim(), true)) "CHECKSUM MATCH" else "CHECKSUM MISMATCH - do not flash this file")
    }

    fun saveQueue(name: String) {
        if (name.isBlank()) { log("Enter a profile name"); return }
        val a = JSONArray()
        queue.forEach { a.put(JSONObject().put("p", it.part).put("u", it.uri.toString()).put("n", it.name).put("s", it.size)) }
        prefs.edit().putString("q:$name", a.toString()).apply()
        log("Saved profile '$name' with ${queue.size} item(s)")
    }

    fun loadQueue(name: String) {
        val s = prefs.getString("q:$name", null)
        if (s == null) { log("No profile '$name'"); return }
        queue.clear()
        val a = JSONArray(s)
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            queue.add(QItem(o.getString("p"), Uri.parse(o.getString("u")), o.getString("n"), o.getLong("s")))
        }
        log("Loaded profile '$name'")
    }

    fun profileNames(): List<String> = prefs.all.keys.filter { it.startsWith("q:") }.map { it.removePrefix("q:") }

    // ---------------- firmware files ----------------

    private fun unzipInternal(uri: Uri) {
        val dir = File(ctx.getExternalFilesDir(null), "fw")
        dir.mkdirs()
        val raw = ctx.contentResolver.openInputStream(uri) ?: throw IOException("cannot open zip")
        ZipInputStream(raw.buffered()).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (!e.isDirectory && e.name.endsWith(".img")) {
                    val n = e.name.substringAfterLast('/')
                    val f = File(dir, n)
                    f.outputStream().use { o -> z.copyTo(o) }
                    queue.add(QItem(n.removeSuffix(".img").lowercase(), Uri.fromFile(f), n, f.length()))
                    log("Unpacked $n (${f.length() / 1024} KB)")
                }
                e = z.nextEntry
            }
        }
    }

    fun unzipToQueue(uri: Uri) = io("Unpack") { unzipInternal(uri) }

    fun download(url: String) = io("Download", true) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        val total = c.contentLengthLong
        val name = url.substringAfterLast('/').substringBefore('?').ifBlank { "download.bin" }
        val dir = File(ctx.getExternalFilesDir(null), "fw")
        dir.mkdirs()
        val f = File(dir, name)
        c.inputStream.use { i ->
            f.outputStream().use { o ->
                val b = ByteArray(65536)
                var t = 0L
                while (true) {
                    val n = i.read(b)
                    if (n < 0) break
                    o.write(b, 0, n)
                    t += n
                    if (total > 0) prog(t.toFloat() / total)
                }
            }
        }
        log("Downloaded ${f.absolutePath}")
        if (name.endsWith(".zip")) unzipInternal(Uri.fromFile(f))
        else queue.add(QItem(name.substringBeforeLast('.').lowercase(), Uri.fromFile(f), name, f.length()))
    }

    // ---------------- ADB sideload ----------------

    fun sideload(uri: Uri) = io("Sideload", true) {
        val d = device ?: throw IOException("No device")
        val (n, s) = meta(uri)
        val c = usb.openDevice(d) ?: throw IOException("openDevice failed")
        try {
            val a = AdbSideload(c, d)
            if (!a.open()) throw IOException("No ADB interface. On the phone choose Recovery > Apply update from ADB.")
            log("Sideloading $n ...")
            val res = a.sideload(ctx.contentResolver, uri, s, speedProbe { s }, { log(it) })
            log("Result: $res")
            if (!res.startsWith("OK")) {
                failed = true
                if (res.contains("USB", true) || res.contains("timeout", true)) raiseCable("A USB transfer error happened: $res")
            }
        } finally { c.close() }
    }

    // ---------------- log and database ----------------

    fun exportLog() {
        val f = File(ctx.getExternalFilesDir(null), "flashforge-log.txt")
        f.writeText(logs.joinToString("\n"))
        log("Log saved to ${f.absolutePath}")
    }

    fun updateDb(url: String) {
        dbUrl = url
        prefs.edit().putString("dburl", url).apply()
        if (url.isBlank()) { log("Enter the raw GitHub URL of devices.json"); return }
        io("Database") {
            log(db.update(url))
            dbInfo = "v${db.version}, ${db.count()} models"
        }
    }
}
