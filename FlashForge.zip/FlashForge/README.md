# FlashForge
USB-OTG phone-to-phone flash workbench (Kotlin, Jetpack Compose).

GitHub build: keep `.github/workflows/build.yml` at the repository root and push either this
project's files or this zip file. The workflow extracts the zip if needed and builds the APK
(Actions > latest run > Artifacts > FlashForge-debug-apk).

Device list: edit `app/src/main/assets/devices.json`, host a copy on GitHub (raw URL) and paste
the URL in the app: Log tab > Device database > Update.

## Version 1.1
- Data cable alert: if the USB speed stays under 2 MB/s for 3 seconds, a USB transfer fails or the
  connection keeps dropping, a "Change the data cable" dialog appears. Choose "I will change it" or
  "Continue anyway".
- Floating bubble: while a flash, backup, sideload or download runs, a draggable bubble with progress,
  speed and cable warnings floats over every app (tap it to return). Grant the overlay permission
  in the Device tab > FLOATING BUBBLE (also allow notifications). "Test bubble" shows a 20 s demo.
- New unique launcher icon (phone + lightning bolt + USB plug on a blueprint grid, with themed icon layer).
- All tab icons and button icons are now coloured graphical icons.

## Version 1.2 (UI restyle only)
- New look: rounded cards, soft pastel background, slanted gradient buttons with white icon tiles,
  header card with a link-state pill, bottom navigation bar. No logic, feature or tab was changed.
