# FlashForge
USB-OTG phone-to-phone flash workbench (Kotlin, Jetpack Compose).

GitHub build: keep `.github/workflows/build.yml` at the repository root and push either this
project's files or this zip file. The workflow extracts the zip if needed and builds the APK
(Actions > latest run > Artifacts > FlashForge-debug-apk).

Device list: edit `app/src/main/assets/devices.json`, host a copy on GitHub (raw URL) and paste
the URL in the app: Log tab > Device database > Update.
