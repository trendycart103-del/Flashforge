# FlashForge — বাংলা টেকনিক্যাল অডিট ও পরিবর্তন বিবরণ

## ১. এই সংস্করণে কী করা হয়েছে

এই আপডেটটি সরবরাহ করা `FlashForge_Safety_Gate_Enforced.zip`-এর ওপর করা হয়েছে। নতুন অ্যাপ বানানো হয়নি। মূল `com.flashforge` namespace/application ID, Kotlin ও Jetpack Compose architecture, মূল navigation, theme/resources, device database এবং বিদ্যমান পেজগুলো রেখে সংশোধন করা হয়েছে।

সবচেয়ে গুরুত্বপূর্ণ পরিবর্তন হলো: **কোনো Image Flash path-এ আলাদা করে Safety Analyzer এড়িয়ে USB-তে `flash:` command পাঠানো যাবে না।**

## ২. আগের অডিটে পাওয়া সমস্যাগুলোর সমাধান

| আগের অডিটে পাওয়া সমস্যা | এই সংস্করণে করা সমাধান | অবস্থা |
|---|---|---|
| Logical partition CREATE/RESIZE/DELETE command destructive guard এড়িয়ে যেতে পারত | UI control রাখা হয়েছে কিন্তু disable করা হয়েছে; `Fastboot.cmd()` transport layer-এও command authorization callback ছাড়া destructive command গ্রহণ করে না | সংশোধিত / ফিচার নিরাপদে বন্ধ |
| Wipe-এ `erase:userdata` ব্যর্থ হলেও `erase:metadata` চলত | প্রথম erase ব্যর্থ হলে exception দিয়ে থামে; metadata erase আর পাঠানো হয় না | সংশোধিত |
| USB transfer মাঝপথে থামলে Fastboot protocol DATA state-এ থেকে যেতে পারত | transfer/read/write/hash/response failure-এ protocol state uncertain করা হয়; Fastboot session invalid করে `RECONNECT USB` প্রয়োজন হয় | সংশোধিত |
| Fastboot `FAIL` response-এর পর UI ভুলভাবে Success দেখাতে পারত | command-এর `r.ok` বাধ্যতামূলক; FAIL হলে operation failed হিসেবে journal/log হয় | সংশোধিত |
| Stream `read()` শূন্য ফেরালে hash/transfer loop আটকে যাওয়ার ঝুঁকি | SHA-256, Fastboot transfer, ZIP extraction, download এবং ADB block read-এ zero-byte read আলাদা error | সংশোধিত |
| USB disconnect বা process death-এর পর শেষ ধাপ জানা যেত না | persistent operation journal ও সর্বশেষ ১০০টি operation history যোগ; app restart-এ RUNNING operation-কে INTERRUPTED হিসেবে রেকর্ড করে | উন্নত; পূর্ণ resume নয় |
| ZIP-এর কিছু Image extract হওয়ার পর archive corruption হলে partial file queue-তে থাকতে পারত | staging directory-তে পুরো ZIP extract/CRC read শেষ না হওয়া পর্যন্ত queue-তে কিছু যোগ হয় না; failure-এ staged/committed file cleanup | সংশোধিত |
| Backup আংশিক ফাইল রেখে যেতে পারত বা metadata ছাড়া ফাইল থাকতে পারত | `.partial` ফাইল, partition size ও storage check, SHA-256, metadata temp file; ব্যর্থ হলে অসম্পূর্ণ backup cleanup | সংশোধিত |
| Backup আগের ফাইল overwrite করতে পারত | timestamped filename এবং existing-file collision হলে overwrite না করে fail | সংশোধিত |
| Persistent operation history ছিল না | operation type, product ID, filename, partition, SHA-256, result, error ও last confirmed step সংরক্ষণ; log export-এ যুক্ত | উন্নত |
| Slow USB speed threshold গণনা হলেও warning দেখাত না | 2 MiB/s-এর নিচে টানা ৩টি sample হলে cable warning | সংশোধিত |
| Fastboot session invalid হলে একই USB device-এ সহজে reconnect করা যেত না | একই device ID থাকলেও `fb == null` হলে scan পুনরায় connect চেষ্টা করে; Device page-এ `RECONNECT USB` button | সংশোধিত |
| Slot change response যাচাই করা হতো না | command FAIL হলে থামে; OKAY-এর পর `current-slot` আবার পড়ে target slot-এর সঙ্গে মিলিয়ে দেখে | সংশোধিত |
| file metadata/URI সমস্যা picker callback-এ crash ঘটাতে পারত | URI metadata, permission, descriptor size এবং file readability error catch করে log; invalid file queue-তে যোগ হয় না | সংশোধিত |
| Firmware filename থেকে partition অনুমান করা হতো | filename থেকে partition আর অনুমান করা হয় না; প্রতিটি queue item-এ explicit target partition field | সংশোধিত |
| Recovery/Boot standalone path-এ publisher checksum দেওয়ার UI ছিল না | standalone Recovery এবং patched Boot image-এর জন্য আলাদা checksum input ও Verify action | সংশোধিত |
| non-critical warning নীরবে pass হতে পারত | Safety Analyzer-এ warning acknowledgement বাধ্যতামূলক; ফলাফল WARNING-ই থাকে, critical failure acknowledge করে bypass করা যায় না | সংশোধিত |
| Bootloader lock ও vbmeta UI স্বাভাবিক flash হিসেবে দেখাত | দুই অপশনই UI-তে disabled এবং limitation ব্যাখ্যা; automatic vbmeta patch বন্ধ | সংশোধিত / ফিচার নিরাপদে বন্ধ |
| ADB sideload normal Android ADB ও Recovery Sideload আলাদা করত না; package integrity দুর্বল ছিল | ADB recovery/sideload banner বাধ্যতামূলক; normal `device` state BLOCKED; trusted publisher SHA-256; private cache staging; transfer digest check; interface/connection cleanup | উন্নত; hardware validation বাকি |

## ৩. Image Flash Safety Gate-এর বর্তমান প্রবাহ

বর্তমান কোডে সব Image Flash path একটিমাত্র application-level function-এ যায়:

`MainVM.executeVerifiedFlash()` → `Fastboot.flash()` → mandatory authorization callback → `verifyFlashGate()`

এই path ব্যবহার করে:

- Flash Queue
- Recovery Image Flash
- Patched Boot Image Flash

`Fastboot.cmd()`-এ raw `flash:` command সরাসরি BLOCKED। Raw `download:` এবং unreviewed Fastboot command-ও command whitelist/authorization ছাড়া গ্রহণ করা হয় না। `Fastboot.command()` private; transport layer-এ আলাদা public raw flash path নেই।

### প্রতিটি Flash-এর আগে যা যাচাই হয়

1. Fastboot mode এবং ready USB connection
2. live `getvar:product` পুনরায় পড়ে expected product ID-এর সঙ্গে মিল
3. user-নিশ্চিত expected product ID ফাঁকা নয়
4. file URI/readability/size
5. আগে দেওয়া publisher SHA-256
6. একই ফাইলের SHA-256 Flash-এর ঠিক আগে পুনরায় গণনা
7. USB transfer চলাকালীন SHA-256 পুনরায় গণনা ও digest comparison
8. Controller phone battery অন্তত ৪০%; target phone battery বলে কোনো অজানা মান দেখানো হয় না
9. slot-count/current-slot পুনরায় যাচাই
10. A/B partition হলে `has-slot` যাচাই এবং `_a`/`_b` suffix স্পষ্ট থাকা
11. `is-logical` যাচাই; logical partition হলে Fastbootd mode বাধ্যতামূলক
12. bootloader-এর `partition-size` query
13. Android sparse image হলে expanded footprint হিসাব করে partition capacity-র সঙ্গে তুলনা
14. bootloader `download` ও `flash` response প্রকৃতপক্ষে সফল কি না

কোনো critical তথ্য পাওয়া না গেলে Flash BLOCKED। Publisher checksum-এর উৎস অ্যাপ নিজে authenticate করতে পারে না এবং সব ডিভাইসের hardware variant/build metadata Fastboot থেকে পাওয়া যায় না—এগুলো স্পষ্ট WARNING হিসেবে দেখানো হয়। প্রথম Image write-এর আগে Safety Analyzer পেজে ব্যবহারকারীকে এই warning-গুলো আলাদাভাবে acknowledge করতে হয়। Acknowledgement-এর পরও ফলাফল `WARNING`-ই থাকে; এটি `PASS` হয়ে যায় না। Critical failure acknowledgement দিয়ে এড়ানো যায় না। `PASS` হলেও অজানা vendor/hardware risk-এর বিরুদ্ধে শতভাগ নিশ্চয়তা নয়।

## ৪. Destructive Fastboot Command সুরক্ষা

- `erase:`-এর জন্য explicit in-app confirmation, live product check, controller battery check এবং bootloader partition-size query প্রয়োজন।
- `flashing unlock` ও legacy `oem unlock`-এর জন্য explicit confirmation, live product check এবং battery check প্রয়োজন।
- `set_active:`-এর জন্য confirmation, A/B slot-count, valid target slot এবং command-এর পর `current-slot` re-check হয়।
- Wipe-এ userdata erase ব্যর্থ হলে metadata erase পাঠানো হয় না।
- Logical partition create/resize/delete এবং super partition modification এই build-এ disabled; কারণ group geometry/metadata constraints পুরোপুরি যাচাই করা হয় না।
- Bootloader lock disabled; modified বা incompatible image থাকলে relock boot failure ঘটাতে পারে এবং এই app stock compatibility প্রমাণ করতে পারে না।
- Automatic vbmeta patch/flash disabled; Android Verified Boot দুর্বল করা হয় না।
- raw/unknown Fastboot command default deny।

## ৫. USB failure, interruption ও app restart

- Fastboot USB bulk transfer exception, timeout, malformed response, partial transfer, file read failure, hash mismatch এবং backup output failure protocol state uncertain করে।
- uncertain session-এ পরবর্তী command প্রত্যাখ্যান হয়; session বন্ধ করে UI-তে `RECONNECT USB` প্রয়োজন হয়।
- USB detach হলে active Fastboot connection বন্ধ হয়; unrelated USB device detach event হলে current device অকারণে disconnect করা হয় না।
- Flash transfer ব্যর্থ হলে পরের queue image চালানো হয় না এবং destructive operation auto-retry হয় না।
- journal-এ DOWNLOAD accepted, data transfer in progress, checksum matched/FLASH command about to be issued এবং bootloader OKAY-এর মতো শেষ নিশ্চিত ধাপ রাখা হয়।
- app process restart-এ RUNNING operation INTERRUPTED হয়; app আগের Flash স্বয়ংক্রিয়ভাবে আবার চালায় না।
- partition write-এর safe resume এই app দাবি করে না।
- Flash সফল হওয়ার পর কোনো automatic reboot, `finish()` বা `System.exit()` যোগ করা হয়নি। reboot কেবল ব্যবহারকারীর আলাদা button action।

## ৬. Firmware ও Backup

### Firmware/ZIP/Download

- ZIP extraction staging folder-এ হয়; সর্বোচ্চ ৫১২ entry, এক entry ১ GiB এবং মোট ৪ GiB সীমা; path ব্যবহার না করে নিরাপদ basename; duplicate image filename reject; zero-byte read reject; archive সম্পূর্ণ পড়া না হলে queue update নয়।
- HTTPS download-এ redirect HTTPS-ই থাকতে হয়; redirect limit ৫; server-কে positive Content-Length দিতে হয় এবং exact size match বাধ্যতামূলক; অস্থায়ী `.download` ফাইল; existing firmware file overwrite নয়; ৪ GiB stream limit। Content-Length না থাকলে download BLOCKED।
- filename থেকে partition আর অনুমান হয় না। user-কে queue item-এ partition লিখতে হয়।

### Backup

- Bootloader `fetch` support না করলে backup blocked/failed।
- `partition-size` ও `fetch`-এর size মিলতে হবে; storage free space check হয়।
- temporary file থেকে finalize, SHA-256 ও JSON metadata; existing backup overwrite নয়।
- Backup Restore এখনো implement করা হয়নি।

## ৭. ADB Sideload

- normal Fastboot বা normal Android ADB `device` state-এ sideload নয়; ADB USB interface-এর পাশাপাশি recovery/sideload banner state বাধ্যতামূলক।
- package আগে private app cache-এ stream করে copy করা হয়; size ও publisher SHA-256 মিললে তবেই protocol শুরু হয়।
- ADB transport-এ local SHA-256 pre-read এবং transfer-এর requested blocks-এর SHA-256 তুলনা হয়; block order/duplicate request অস্বাভাবিক হলে transfer stop।
- Publisher SHA-256 user-কে trusted source থেকে দিতে হয়; app source authenticity নিজে প্রমাণ করে না। Recovery-এর transport completion-ও installation success-এর নিশ্চয়তা নয়।
- ADB AUTH/key authorization এখনো implemented নয় এবং physical recovery test হয়নি। Recovery banner যাচাই হয়, কিন্তু Recovery ADB transport থেকে target product ID/hardware variant নির্ভরযোগ্যভাবে query করা এখনো implemented নয়; তাই sideload package compatibility আলাদাভাবে OEM নির্দেশনা দিয়ে নিশ্চিত করতে হবে।

## ৮. Crash/Resource review

- Large file processing streaming buffer-এ; পুরো firmware memory-তে load করা হয় না।
- Content URI metadata/permission/open errors catch করা হয়।
- `InputStream` zero-byte read infinite loop এড়ানো হয়েছে।
- ZIP extraction path traversal/duplicate basename/oversize/partial commit guard করা হয়েছে।
- Fastboot/ADB USB interface release ও connection close cleanup যোগ হয়েছে।
- Fastboot command failure-এর পর operation Success হিসেবে চিহ্নিত হয় না।
- operation coroutine `viewModelScope` ও `withContext(Dispatchers.IO)` ব্যবহার করে; cancellation journal-এ INTERRUPTED হয়।
- Floating Bubble/Intent/notification এবং USB cleanup-এর পূর্বের silent catch-গুলোতে diagnostic log যোগ হয়েছে।
- ViewModel cleanup-এ Fastboot connection close হয়।

## ৯. আগের অডিটের সব সমস্যা সমাধানের অবস্থা

**আগের অডিটে সরাসরি পাওয়া এবং কোডে সংশোধন করা সমস্যাগুলো:** logical partition command bypass, wipe second erase after failure, transfer protocol state uncertainty, Fastboot FAIL handling, zero-byte read, partial ZIP queue, backup partial file/overwrite, operation history, slow speed warning, reconnect path, slot change verification, file/URI error handling, filename-based partition inference, standalone image checksum UI, vbmeta/lock misleading UI।

**সীমাবদ্ধতা/অসম্পূর্ণ:**

- এই পরিবেশে Android SDK/Gradle নেই; প্রকৃত Android Gradle compilation বা APK তৈরি করা হয়নি।
- ZIP-এ Gradle Wrapper নেই।
- কোনো physical USB/Fastboot device-এ destructive বা non-destructive hardware test চালানো হয়নি।
- ADB sideload actual recovery compatibility test হয়নি; AUTH/key support নেই।
- Backup Restore নেই।
- Firmware download resume নেই।
- Firmware package build/region/CSC metadata parser পূর্ণ নয়।
- Qualcomm EDL Sahara/Firehose, MediaTek BROM/DA, Samsung Download Mode flashing এবং Unisoc FDL flashing বাস্তবায়িত নয়; detection মানেই support নয়।
- Logical partition modification, bootloader locking ও vbmeta automatic patch/flash disabled।
- Operation history সর্বশেষ ১০০টি operation রাখে।
- sparse image parser standard Android sparse header/chunk structure ও expanded size যাচাই করে; publisher SHA-256-ই content authenticity-এর ভিত্তি নয়। publisher checksum trusted source থেকে ব্যবহারকারীকে আনতে হবে।

## ১০. Validation report

| পরীক্ষা | ফলাফল |
|---|---|
| Original project file inventory/diff | সম্পন্ন |
| Original Kotlin/resource/database files preserved | archive comparison দিয়ে যাচাই |
| `unzip -t` ZIP integrity | PASS |
| Image Flash call-site search | একটিমাত্র USB `Fastboot.flash()` transport path পাওয়া গেছে |
| Raw `flash:` command block | source-level check PASS |
| Raw `download:` / unknown Fastboot command block | source-level check PASS |
| Wipe stop-on-first-failure | source-level check PASS |
| Queue blank partition / missing SHA gate | source-level check PASS |
| ZIP transactional extraction | source-level check PASS |
| Parser/syntax scan with standalone kotlinc | syntax/expecting/redeclaration diagnostics পাওয়া যায়নি; Android/AndroidX classpath অনুপস্থিত থাকায় এটি Android compile নয় |
| `./gradlew clean` | NOT RUN — মূল ZIP-এ Gradle Wrapper নেই |
| `./gradlew assembleDebug` | NOT RUN — wrapper/Gradle/Android SDK নেই |
| `./gradlew test` | NOT RUN — wrapper/Gradle/Android SDK নেই |
| `./gradlew lint` | NOT RUN — wrapper/Gradle/Android SDK নেই |
| Physical USB/Fastboot/Recovery tests | NOT RUN |
| Debug APK | তৈরি হয়নি |

**চূড়ান্ত সতর্কতা:** এই সংস্করণে source-level safety hardening ও crash-path handling করা হয়েছে। Android Studio build এবং authorized test device-এ hardware validation না হওয়া পর্যন্ত এটিকে production-tested বা crash-free বলা যাবে না।
