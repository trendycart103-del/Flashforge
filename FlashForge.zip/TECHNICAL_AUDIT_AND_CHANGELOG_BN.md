# FlashForge — Technical Audit & Change Log

## এই আপডেটে করা পরিবর্তন

### হোম স্ক্রিন / UI
- অ্যাপ লোগোর দৃশ্যমান মাপ 76dp থেকে 56dp করা হয়েছে, যাতে শিরোনামের জন্য বেশি জায়গা থাকে।
- `FlashForge` শিরোনাম 22sp bold করা হয়েছে এবং এক লাইনে সম্পূর্ণ দেখানোর জন্য soft-wrap বন্ধ করা হয়েছে।
- Connected status pill-এর padding ও font ছোট করা হয়েছে, যাতে ছোট স্ক্রিনেও শিরোনাম ও status পাশাপাশি জায়গা পায়।
- হোম স্ক্রিনের লাল `no device - connect the phone with an OTG cable` বার্তাটি সরানো হয়েছে।
- ডিভাইস সংযুক্ত না থাকলে নিচের ধূসর connection sentence-টিও আর দেখানো হয় না; `Not Connected` status pill-ই অবস্থা জানায়।
- সংযুক্ত থাকলে device information ও connection progress আগের মতো দেখায়।

### ADB Sideload
- ADB packet header ঠিক 24 byte করে পড়া হয়; header ও payload একই USB read-এ এলে payload হারিয়ে যাওয়ার ঝুঁকি এড়ানো হয়েছে।
- Packet length 0–64 KiB সীমার মধ্যে যাচাই করা হয়।
- ADB magic ও payload checksum যাচাই যোগ করা হয়েছে।
- USB transfer-এ negative বা zero byte return হলে infinite loop না করে ব্যর্থতা জানায়।
- ZIP block পড়ার সময় অসম্পূর্ণ/শূন্য read হলে স্পষ্ট error দেয়।

### Fastboot
- USB write/read-এ zero-byte transfer হলে loop আটকে না থেকে ব্যর্থ হয়।
- Fetch transfer-এ buffer-এর চেয়ে বড় alignment length পাঠানোর ঝুঁকি সরানো হয়েছে।
- Empty partition fetch-এর ক্ষেত্রে divide-by-zero progress এড়ানো হয়েছে।

### USB Detection ও Operation lifecycle
- Composite USB device-এ প্রথম vendor interface অচেনা হলে অন্য interface-ও পরীক্ষা করা হয়; পরের ADB/Fastboot interface পাওয়া যেতে পারে।
- USB বিচ্ছিন্ন হলেই `busy=false` করে দেওয়া বন্ধ করা হয়েছে। চলমান background operation নিজস্ব `finally` থেকে শেষ হলে busy state clear করবে; এতে একই সময়ে দ্বিতীয় operation চালু হওয়ার ঝুঁকি কমে।

### Firmware database update
- Database update URL-এ HTTPS বাধ্যতামূলক করা হয়েছে।
- HTTP status, 2 MB download limit এবং JSON structure/version যাচাই যোগ করা হয়েছে।
- Redirect স্বয়ংক্রিয়ভাবে অনুসরণ করা হয় না।
- নতুন database temporary file-এ লিখে atomic replace করা হয়।

### ZIP image extraction
- Archive path ব্যবহার না করে শুধু filename নেওয়া হয়; path traversal প্রতিরোধ করা হয়েছে।
- সর্বোচ্চ 512টি entry, প্রতিটি image 1 GiB এবং মোট extracted image 4 GiB সীমা যোগ করা হয়েছে।
- Empty image reject করা হয়।

### Firmware source label
- SamMobile, SamFw, XiaomiFirmware, XiaomiROM, Lolinet ও Oxygen Updater-এর মতো তৃতীয়-পক্ষের উৎসগুলোকে UI-তে তৃতীয়-পক্ষ হিসেবে স্পষ্টভাবে চিহ্নিত করা হয়েছে।
- Google Factory Images/OTA এবং নির্মাতার support/download page-কে তৃতীয়-পক্ষের mirror-এর সঙ্গে গুলিয়ে ফেলা যাবে না।

## এখনো অসম্পূর্ণ / সতর্কতা

- Qualcomm EDL, MediaTek BROM, Samsung Download ও Unisoc-এর জন্য এই build-এ পূর্ণ flashing protocol/engine যোগ করা হয়নি; এগুলো detection/status স্তরে আছে।
- Samsung/Motorola/Xiaomi-সহ সব brand-এর জন্য model+region+build অনুযায়ী সরাসরি official firmware URL resolver তৈরি হয়নি। কিছু brand page বা third-party index link আছে; এগুলোকে official direct firmware file হিসেবে ধরা যাবে না।
- Firmware image download শেষে SHA-256 verification workflow এখনো সম্পূর্ণ নয়।
- Fastboot flashing বাস্তব ফোনে/প্রতিটি partition layout-এ পরীক্ষা করা হয়নি। ভুল image বা partition নির্বাচন করলে ফোন boot না-ও করতে পারে।
- ADB sideload-এর end-to-end test recovery device-এ করা হয়নি। ADB authorization/recovery mode এবং sideload service negotiation-এর device-specific আচরণ থাকতে পারে।
- USB attach/detach, permission এবং multiple-device selection-এর পূর্ণ hardware matrix test করা হয়নি।
- Android APK build এই পরিবেশে চালানো যায়নি: Gradle executable/Android SDK অনুপস্থিত। GitHub Actions workflow-তে Gradle 8.7 দিয়ে `assembleDebug` চালানোর ব্যবস্থা আছে।

## Build করার উপায়

GitHub-এ project root push করে Actions workflow চালান, অথবা Android Studio-তে `FlashForge/` folder খুলে Gradle sync করে `app:assembleDebug` চালান। Build output হবে:

`app/build/outputs/apk/debug/app-debug.apk`

## নিরাপদ ব্যবহারের নোট

- Flash করার আগে সঠিক device product/codename, region, build number ও partition layout মিলিয়ে নিন।
- Bootloader unlock/wipe/flash ডেটা মুছে দিতে পারে; আগে backup নিন।
- অজানা বা তৃতীয়-পক্ষের firmware mirror থেকে পাওয়া ফাইল যাচাই ছাড়া flash করবেন না।
- এই ZIP-এ source-level fixes করা হয়েছে; বাস্তব ফোনে hardware validation বা successful APK build দাবি করা হচ্ছে না।


## দ্বিতীয় আপডেট — নির্বাচিত ১, ২ ও ৩ নম্বর ফিচার

### ১. Chipset engine architecture
- Qualcomm EDL, MediaTek BROM, Samsung Download এবং Unisoc FDL-এর জন্য পৃথক capability registry যোগ হয়েছে।
- প্রতিটি মোডের transport ও model-specific signed loader/authentication requirement UI-তে দেখানো হয়।
- নিরাপত্তার কারণে generic বা cross-model programmer দিয়ে write operation চালু করা হয়নি। এই প্রজেক্টে এখনো vendor protocol implementation, signed loader validation এবং বাস্তব hardware qualification অনুপস্থিত; তাই এগুলোকে পূর্ণ Flash Engine বলা যাবে না।

### ২. Official Firmware Resolver
- Samsung, Xiaomi, Google, Motorola, OnePlus, Sony, Huawei, OPPO, vivo, ASUS, LG, HTC, ZTE ও HMD-এর manufacturer-owned support/download portals যোগ হয়েছে।
- Model/codename এবং optional model number/region দিয়ে manufacturer-domain scoped search তৈরি হয়।
- Portal link-কে direct firmware URL হিসেবে দাবি করা হয় না। Independent mirror-কে official হিসেবে লেবেল করা হয় না।

### ৩. SHA-256 verification gate
- Flash queue-র প্রতিটি ফাইলের জন্য আলাদা trusted 64-character SHA-256 checksum দিতে হয়।
- VERIFY SHA-256 checksum মিললে তবেই ফাইলটি verified হয়; mismatch হলে verification বাতিল হয়।
- FLASH ALL-এর আগে সব queued file verified থাকা বাধ্যতামূলক। Flash শুরুর ঠিক আগে প্রতিটি ফাইলের hash আবার গণনা করা হয়, যাতে verify করার পর ফাইল বদলে গেলে flash আটকে যায়।
- Trusted checksum অবশ্যই নির্মাতা/বিশ্বস্ত firmware publisher-এর প্রকাশিত মান থেকে নিতে হবে। শুধু নিজে গণনা করা hash authenticity প্রমাণ করে না।

### সংরক্ষণ ও সীমাবদ্ধতা
- বিদ্যমান প্রজেক্ট ফাইল ও assets মুছে ফেলা হয়নি; পরিবর্তনগুলো মূল project tree-তেই করা হয়েছে।
- পূর্ণ EDL/BROM/Download/FDL writing implementation, vendor authorization এবং real-device validation এই আপডেটে সম্পন্ন নয়।
- APK build/runtime test চালানো হয়নি; Android SDK/Gradle environment না থাকায় compile success দাবি করা হচ্ছে না।


## তৃতীয় আপডেট — EDL ও MediaTek Loader ঐচ্ছিক নির্বাচন

- Qualcomm EDL-এর জন্য `SELECT OPTIONAL EDL PROGRAMMER` অপশন যোগ হয়েছে।
- MediaTek BROM-এর জন্য `SELECT OPTIONAL MTK DA` অপশন যোগ হয়েছে।
- নির্বাচিত ফাইলের URI অ্যাপের private preferences-এ রাখা হয়; অ্যাপ বন্ধ/খোলার পরও নির্বাচনের তথ্য দেখা যাবে।
- CLEAR দিয়ে নির্বাচনের reference মুছে ফেলা যায়।
- এগুলো সম্পূর্ণ ঐচ্ছিক; কোনো ফাইল নিজে থেকে ডাউনলোড, execute, authenticate বা flash করা হয় না।
- শুধু exact model-এর জন্য OEM/authorized source থেকে পাওয়া signed programmer/DA ব্যবহারযোগ্য বলে UI-তে সতর্ক করা হয়। Secure Boot, SLA, DAA বা অন্য vendor authorization এড়িয়ে যাওয়ার কোনো ব্যবস্থা যোগ করা হয়নি।
- এই build-এ Qualcomm/MediaTek write protocol এখনো সক্রিয় নয়; loader নির্বাচন ভবিষ্যৎ অনুমোদিত protocol integration-এর জন্য সংরক্ষিত reference মাত্র।
- আগের firmware resolver, SHA-256 gate, existing app assets, profile/database ও UI ফাইল অক্ষত রাখা হয়েছে; শুধু engine registry, Flash page ও MainVM-এ ঐচ্ছিক loader reference যোগ হয়েছে।

## চতুর্থ আপডেট — Flash Safety Hardening (2026-11-17)

### ZIP inventory ও সংরক্ষণ
- মূল ZIP-এ মোট ৮০টি archive entry ছিল; এর মধ্যে Kotlin source, Compose UI, Android manifest, resources/drawables, `devices.json`, Gradle configuration, GitHub Actions workflow, README এবং আগের audit নথি রয়েছে।
- `com.flashforge` namespace/applicationId, FlashForge নাম, বিদ্যমান source/assets, device database, বিদ্যমান navigation pages এবং Floating Bubble মুছে ফেলা হয়নি।
- বিদ্যমান `Fastboot.kt`, `AdbSideload.kt`, `MainVM.kt`, `Pages.kt`, `Ui.kt`, `DeviceDb.kt`, `ChipsetFlashEngines.kt`-এর ওপরই পরিবর্তন করা হয়েছে।

### নতুন Safety Analyzer
- বিদ্যমান নেভিগেশনে `SAFETY` পেজ যোগ হয়েছে; একই Compose panel/card design language ব্যবহার করা হয়েছে।
- সংযুক্ত Fastboot device, detected product ID, expected product ID, model lookup, active slot, A/B status, Fastbootd status, USB state, controller phone battery এবং queued image checksum status দেখায়।
- detected product ID expected field-এ বসানোর জন্য আলাদা confirmation action যোগ হয়েছে।
- expected product ID ফাঁকা, unknown, mismatch, Fastboot connection অনুপস্থিত/unstable হলে destructive operation fail-closed হয়।
- controller phone battery ৪০%-এর নিচে বা battery level unavailable হলে image flash gate BLOCKED করে। target device-এর battery level বানিয়ে দেখানো হয় না।

### Flash engine safety gate
- Single Image Flash ও Flash Queue—দুই write path-ই একই `verifyFlashGate` ব্যবহার করে।
- প্রতিটি image-এর trusted publisher SHA-256 আগে VERIFY-তে মেলাতে হয়; transfer-এর ঠিক আগে hash আবার গণনা করা হয় এবং URI metadata size বনাম বাস্তবে পড়া byte count মেলানো হয়।
- Fastboot bootloader থেকে `partition-size:<partition>` না পাওয়া গেলে বা image partition capacity ছাড়ালে flash আটকে যায়।
- partition name-এর জন্য conservative character/length validation যোগ হয়েছে; filename থেকে partition নাম অনুমান করে single flash চালানো হয় না।
- transfer fail হলে queue exception দিয়ে থামে; পরবর্তী flash command বা automatic retry হয় না।
- erase, unlock, slot change ইত্যাদি destructive Fastboot command-এর আগে exact expected product ID এবং ready Fastboot connection বাধ্যতামূলক।
- Bootloader lock operation আপাতত block করা হয়েছে, কারণ stock-compatible firmware ও device-specific preconditions অ্যাপ নির্ভরযোগ্যভাবে প্রমাণ করতে পারে না।
- automatic vbmeta patching/verity-disable path বন্ধ করা হয়েছে; Android Verified Boot দুর্বল করতে পারে এমন automatic পরিবর্তন আর করা হয় না।

### Backup ও download
- Fastboot `fetch`-সমর্থিত partition-এর backup-এ unique timestamp filename, returned-size validation এবং SHA-256 metadata sidecar যোগ হয়েছে; আগের backup overwrite হয় না।
- Firmware download-এর জন্য HTTPS বাধ্যতামূলক, HTTP status যাচাই, safe filename, available-space check, temporary `.download` file এবং known Content-Length mismatch/empty-file rejection যোগ হয়েছে।
- Download resume এখনো implement করা হয়নি।

### যাচাইয়ের ফল
- ZIP extraction integrity এবং source inventory যাচাই করা হয়েছে।
- Static source review-এ সব direct `Fastboot.flash` call `MainVM`-এর দুই guarded path-এ সীমাবদ্ধ পাওয়া গেছে।
- Android build চালানো যায়নি: project ZIP-এ Gradle wrapper নেই এবং execution environment-এ Gradle executable/Android SDK পাওয়া যায়নি। তাই `clean`, `assembleDebug`, `test`, `lint` সফল হয়েছে—এমন দাবি করা হচ্ছে না।
- Physical USB/Fastboot, USB disconnect, low battery, wrong device, partition mismatch, bootloader response এবং recovery device tests চালানো হয়নি।

### এখনও অসম্পূর্ণ / গুরুত্বপূর্ণ সীমাবদ্ধতা
- Safety Analyzer-এ PASS state দেখানো হয় না; এটি বর্তমানে fail-closed BLOCKED অথবা WARNING review state দেখায়। Partition capacity-এর চূড়ান্ত যাচাই operation শুরুর ঠিক আগে bootloader থেকে করা হয়, Analyzer page-এ আলাদা live partition probe নেই।
- Product ID-ই সব hardware variant, codename, region/CSC বা partition layout নিশ্চিত করে না; firmware package parser/variant validation সম্পূর্ণ নয়।
- SHA-256 কেবল trusted publisher checksum-এর সঙ্গে মেলানো হলে gate-এ গ্রহণ করা হয়; checksum source-এর authenticity অ্যাপ নিজে যাচাই করে না।
- Partition logical/physical classification এবং slot-specific partition semantics সম্পূর্ণ implement করা হয়নি; unsupported/unknown capacity fail-closed হয়, কিন্তু সব vendor-specific layout বোঝে না।
- USB transfer speed threshold warning, transfer error telemetry, persisted operation journal/process-restart recovery, resume, cancellation protocol এবং structured history database এখনো সম্পূর্ণ নয়। বর্তমান log মূলত in-memory; exportable text log বিদ্যমান।
- Backup কেবল bootloader `fetch` support করলে কাজ করবে; restore workflow, restore compatibility validation এবং full metadata restore এখনো নেই।
- ADB Sideload end-to-end recovery validation হয়নি।
- Qualcomm EDL, MediaTek BROM, Samsung Download ও Unisoc FDL পূর্ণ flashing engine নয়; detection/capability description মাত্র।
- APK build, automated unit tests, lint এবং physical device validation অনুপস্থিত। কোনো APK-কে tested build বলা হচ্ছে না।

### নিরাপত্তা ঘোষণা
এই পরিবর্তনগুলো ঝুঁকি কমানোর fail-closed ব্যবস্থা; ১০০% নিরাপত্তার নিশ্চয়তা নয়। অজানা bootloader আচরণ, vendor-specific partition layout, ভুল/ক্ষতিকর firmware, USB hardware fault বা recovery limitation-এর ঝুঁকি থেকে যায়। বাস্তব ডিভাইসে destructive flash চালানোর আগে OEM procedure, verified firmware এবং recovery plan নিশ্চিত করতে হবে।

## 2026-11-17 — বাধ্যতামূলক কেন্দ্রীয় Flash Safety Gate (গুরুত্বপূর্ণ সংশোধন)

ব্যবহারকারীর সর্বোচ্চ অগ্রাধিকার অনুযায়ী Safety Analyzer-কে শুধু আলাদা UI পেজে সীমাবদ্ধ না রেখে Fastboot transport স্তরেও বাধ্যতামূলক করা হয়েছে।

### কী পরিবর্তন হয়েছে
- `Fastboot` constructor-এ বাধ্যতামূলক `authorizeFlash` callback যোগ হয়েছে; কোনো unguarded constructor/API রাখা হয়নি।
- `Fastboot.flash()` প্রতিবার USB `download:` কমান্ড পাঠানোর আগেই callback চালায়। callback ব্যর্থ/exception হলে `download:` বা `flash:`—কোনোটিই পাঠানো হয় না।
- callback বর্তমান URI metadata পুনরায় পড়ে, queued size-এর সঙ্গে মেলায় এবং MainVM-এর `verifyFlashGate()` চালায়; এতে exact product ID, Fastboot readiness, publisher SHA-256, controller battery threshold, partition name এবং bootloader-reported partition capacity পুনরায় যাচাই হয়।
- `MainVM.executeVerifiedFlash()` একক application-level flash route হয়েছে; Single Image, Recovery/Boot (যেগুলো `flashOne` ব্যবহার করে) এবং Flash Queue একই route ব্যবহার করে।
- Generic `Fastboot.cmd("flash:...")` সরাসরি flash command পাঠাতে পারে না; এটি স্পষ্ট BLOCKED result দেয়। প্রকৃত `flash:` command শুধু authorization-পাস করা `Fastboot.flash()`-এর private command path দিয়ে পাঠানো হয়।
- USB-তে image stream করার সময় একই সঙ্গে SHA-256 পুনরায় গণনা হয়। যাচাইকৃত digest-এর সঙ্গে না মিললে, ফাইল transfer-এর সময় বড় হয়ে গেলে, বা stream অসম্পূর্ণ হলে `flash:` command পাঠানো হয় না।
- Transfer ব্যর্থ হলে queue থামে; স্বয়ংক্রিয় retry বা পরবর্তী destructive command পাঠানো হয় না।

### গুরুত্বপূর্ণ সীমা
এই gate বর্তমান Fastboot image-write পথগুলিকে রক্ষা করে। Erase/partition-layout/slot/unlock-এর মতো অন্য destructive Fastboot command-গুলির জন্য পৃথক confirmation ও command-specific policy এখনও প্রয়োজন; এই পরিবর্তনকে সেগুলির পূর্ণ safety certification হিসেবে গণ্য করা যাবে না। Hardware test বা Gradle build এই পরিবেশে চালানো হয়নি।
