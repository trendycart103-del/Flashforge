# FlashForge — Technical Audit & Change Log

## এই আপডেটে করা পরিবর্তন

### হোম স্ক্রিন / UI
- অ্যাপ লোগোর দৃশ্যমান মাপ 76dp থেকে 56dp করা হয়েছে, যাতে শিরোনামের জন্য বেশি জায়গা থাকে।
- `FlashForge` শিরোনাম 22sp bold করা হয়েছে এবং এক লাইনে সম্পূর্ণ দেখানোর জন্য soft-wrap বন্ধ করা হয়েছে।
- Connected status pill-এর padding ও font ছোট করা হয়েছে, যাতে ছোট স্ক্রিনেও শিরোনাম ও status পাশাপাশি জায়গা পায়।
- হোম স্ক্রিনের লাল `no device - connect the phone with an OTG cable` বার্তাটি সরানো হয়েছে।
- ডিভাইস সংযুক্ত না থাকলে নিচের ধূসর connection sentence-টিও আর দেখানো হয় না; `Not Connected` status pill-ই অবস্থা জানায়।
- সংযুক্ত থাকলে device information ও connection progress আগের মতো দেখায়।

### ADB Sideload
- ADB packet header ঠিক 24 byte করে পড়া হয়; header ও payload একই USB read-এ এলে payload হারিয়ে যাওয়ার ঝুঁকি এড়ানো হয়েছে।
- Packet length 0–64 KiB সীমার মধ্যে যাচাই করা হয়।
- ADB magic ও payload checksum যাচাই যোগ করা হয়েছে।
- USB transfer-এ negative বা zero byte return হলে infinite loop না করে ব্যর্থতা জানায়।
- ZIP block পড়ার সময় অসম্পূর্ণ/শূন্য read হলে স্পষ্ট error দেয়।

### Fastboot
- USB write/read-এ zero-byte transfer হলে loop আটকে না থেকে ব্যর্থ হয়।
- Fetch transfer-এ buffer-এর চেয়ে বড় alignment length পাঠানোর ঝুঁকি সরানো হয়েছে।
- Empty partition fetch-এর ক্ষেত্রে divide-by-zero progress এড়ানো হয়েছে।

### USB Detection ও Operation lifecycle
- Composite USB device-এ প্রথম vendor interface অচেনা হলে অন্য interface-ও পরীক্ষা করা হয়; পরের ADB/Fastboot interface পাওয়া যেতে পারে।
- USB বিচ্ছিন্ন হলেই `busy=false` করে দেওয়া বন্ধ করা হয়েছে। চলমান background operation নিজস্ব `finally` থেকে শেষ হলে busy state clear করবে; এতে একই সময়ে দ্বিতীয় operation চালু হওয়ার ঝুঁকি কমে।

### Firmware database update
- Database update URL-এ HTTPS বাধ্যতামূলক করা হয়েছে।
- HTTP status, 2 MB download limit এবং JSON structure/version যাচাই যোগ করা হয়েছে।
- Redirect স্বয়ংক্রিয়ভাবে অনুসরণ করা হয় না।
- নতুন database temporary file-এ লিখে atomic replace করা হয়।

### ZIP image extraction
- Archive path ব্যবহার না করে শুধু filename নেওয়া হয়; path traversal প্রতিরোধ করা হয়েছে।
- সর্বোচ্চ 512টি entry, প্রতিটি image 1 GiB এবং মোট extracted image 4 GiB সীমা যোগ করা হয়েছে।
- Empty image reject করা হয়।

### Firmware source label
- SamMobile, SamFw, XiaomiFirmware, XiaomiROM, Lolinet ও Oxygen Updater-এর মতো তৃতীয়-পক্ষের উৎসগুলোকে UI-তে তৃতীয়-পক্ষ হিসেবে স্পষ্টভাবে চিহ্নিত করা হয়েছে।
- Google Factory Images/OTA এবং নির্মাতার support/download page-কে তৃতীয়-পক্ষের mirror-এর সঙ্গে গুলিয়ে ফেলা যাবে না।

## এখনো অসম্পূর্ণ / সতর্কতা

- Qualcomm EDL, MediaTek BROM, Samsung Download ও Unisoc-এর জন্য এই build-এ পূর্ণ flashing protocol/engine যোগ করা হয়নি; এগুলো detection/status স্তরে আছে।
- Samsung/Motorola/Xiaomi-সহ সব brand-এর জন্য model+region+build অনুযায়ী সরাসরি official firmware URL resolver তৈরি হয়নি। কিছু brand page বা third-party index link আছে; এগুলোকে official direct firmware file হিসেবে ধরা যাবে না।
- Firmware image download শেষে SHA-256 verification workflow এখনো সম্পূর্ণ নয়।
- Fastboot flashing বাস্তব ফোনে/প্রতিটি partition layout-এ পরীক্ষা করা হয়নি। ভুল image বা partition নির্বাচন করলে ফোন boot না-ও করতে পারে।
- ADB sideload-এর end-to-end test recovery device-এ করা হয়নি। ADB authorization/recovery mode এবং sideload service negotiation-এর device-specific আচরণ থাকতে পারে।
- USB attach/detach, permission এবং multiple-device selection-এর পূর্ণ hardware matrix test করা হয়নি।
- Android APK build এই পরিবেশে চালানো যায়নি: Gradle executable/Android SDK অনুপস্থিত। GitHub Actions workflow-তে Gradle 8.7 দিয়ে `assembleDebug` চালানোর ব্যবস্থা আছে।

## Build করার উপায়

GitHub-এ project root push করে Actions workflow চালান, অথবা Android Studio-তে `FlashForge/` folder খুলে Gradle sync করে `app:assembleDebug` চালান। Build output হবে:

`app/build/outputs/apk/debug/app-debug.apk`

## নিরাপদ ব্যবহারের নোট

- Flash করার আগে সঠিক device product/codename, region, build number ও partition layout মিলিয়ে নিন।
- Bootloader unlock/wipe/flash ডেটা মুছে দিতে পারে; আগে backup নিন।
- অজানা বা তৃতীয়-পক্ষের firmware mirror থেকে পাওয়া ফাইল যাচাই ছাড়া flash করবেন না।
- এই ZIP-এ source-level fixes করা হয়েছে; বাস্তব ফোনে hardware validation বা successful APK build দাবি করা হচ্ছে না।


## দ্বিতীয় আপডেট — নির্বাচিত ১, ২ ও ৩ নম্বর ফিচার

### ১. Chipset engine architecture
- Qualcomm EDL, MediaTek BROM, Samsung Download এবং Unisoc FDL-এর জন্য পৃথক capability registry যোগ হয়েছে।
- প্রতিটি মোডের transport ও model-specific signed loader/authentication requirement UI-তে দেখানো হয়।
- নিরাপত্তার কারণে generic বা cross-model programmer দিয়ে write operation চালু করা হয়নি। এই প্রজেক্টে এখনো vendor protocol implementation, signed loader validation এবং বাস্তব hardware qualification অনুপস্থিত; তাই এগুলোকে পূর্ণ Flash Engine বলা যাবে না।

### ২. Official Firmware Resolver
- Samsung, Xiaomi, Google, Motorola, OnePlus, Sony, Huawei, OPPO, vivo, ASUS, LG, HTC, ZTE ও HMD-এর manufacturer-owned support/download portals যোগ হয়েছে।
- Model/codename এবং optional model number/region দিয়ে manufacturer-domain scoped search তৈরি হয়।
- Portal link-কে direct firmware URL হিসেবে দাবি করা হয় না। Independent mirror-কে official হিসেবে লেবেল করা হয় না।

### ৩. SHA-256 verification gate
- Flash queue-র প্রতিটি ফাইলের জন্য আলাদা trusted 64-character SHA-256 checksum দিতে হয়।
- VERIFY SHA-256 checksum মিললে তবেই ফাইলটি verified হয়; mismatch হলে verification বাতিল হয়।
- FLASH ALL-এর আগে সব queued file verified থাকা বাধ্যতামূলক। Flash শুরুর ঠিক আগে প্রতিটি ফাইলের hash আবার গণনা করা হয়, যাতে verify করার পর ফাইল বদলে গেলে flash আটকে যায়।
- Trusted checksum অবশ্যই নির্মাতা/বিশ্বস্ত firmware publisher-এর প্রকাশিত মান থেকে নিতে হবে। শুধু নিজে গণনা করা hash authenticity প্রমাণ করে না।

### সংরক্ষণ ও সীমাবদ্ধতা
- বিদ্যমান প্রজেক্ট ফাইল ও assets মুছে ফেলা হয়নি; পরিবর্তনগুলো মূল project tree-তেই করা হয়েছে।
- পূর্ণ EDL/BROM/Download/FDL writing implementation, vendor authorization এবং real-device validation এই আপডেটে সম্পন্ন নয়।
- APK build/runtime test চালানো হয়নি; Android SDK/Gradle environment না থাকায় compile success দাবি করা হচ্ছে না।


## তৃতীয় আপডেট — EDL ও MediaTek Loader ঐচ্ছিক নির্বাচন

- Qualcomm EDL-এর জন্য `SELECT OPTIONAL EDL PROGRAMMER` অপশন যোগ হয়েছে।
- MediaTek BROM-এর জন্য `SELECT OPTIONAL MTK DA` অপশন যোগ হয়েছে।
- নির্বাচিত ফাইলের URI অ্যাপের private preferences-এ রাখা হয়; অ্যাপ বন্ধ/খোলার পরও নির্বাচনের তথ্য দেখা যাবে।
- CLEAR দিয়ে নির্বাচনের reference মুছে ফেলা যায়।
- এগুলো সম্পূর্ণ ঐচ্ছিক; কোনো ফাইল নিজে থেকে ডাউনলোড, execute, authenticate বা flash করা হয় না।
- শুধু exact model-এর জন্য OEM/authorized source থেকে পাওয়া signed programmer/DA ব্যবহারযোগ্য বলে UI-তে সতর্ক করা হয়। Secure Boot, SLA, DAA বা অন্য vendor authorization এড়িয়ে যাওয়ার কোনো ব্যবস্থা যোগ করা হয়নি।
- এই build-এ Qualcomm/MediaTek write protocol এখনো সক্রিয় নয়; loader নির্বাচন ভবিষ্যৎ অনুমোদিত protocol integration-এর জন্য সংরক্ষিত reference মাত্র।
- আগের firmware resolver, SHA-256 gate, existing app assets, profile/database ও UI ফাইল অক্ষত রাখা হয়েছে; শুধু engine registry, Flash page ও MainVM-এ ঐচ্ছিক loader reference যোগ হয়েছে।
