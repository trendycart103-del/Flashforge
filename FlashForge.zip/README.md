# FlashForge — Safety Remediation Build

This is an update of the supplied FlashForge Android Studio project, not a replacement application. The original package/application ID (`com.flashforge`), Kotlin/Compose architecture, device database, navigation, theme, and existing pages are retained.

## Main safety changes

- Every image write path (`Flash Queue`, Recovery Image, and patched Boot Image) reaches `MainVM.executeVerifiedFlash()` and then the only USB write entry point, `Fastboot.flash()`.
- `Fastboot.flash()` invokes the mandatory authorization callback before `download:` and verifies the bytes again while streaming. A raw `flash:` command is rejected by `Fastboot.cmd()`; raw `download:` and unreviewed Fastboot commands are rejected as well.
- The pre-flash gate re-reads the live product ID, requires the user-confirmed expected product ID, publisher-provided SHA-256, controller-phone battery >= 40%, current slot layout, `has-slot`, logical/physical partition status, and the bootloader-reported partition size. The Safety Analyzer page shows the actual latest check results and warning details.
- Non-critical unresolved warnings (publisher checksum source authenticity and unavailable universal hardware-variant/build proof) remain visibly `WARNING`; the user must explicitly acknowledge them for the current device session before the first image write. Acknowledgement never changes the result to PASS, and critical failures remain BLOCKED.
- Android sparse images are parsed for their expanded footprint before partition-capacity comparison. Malformed or unsupported sparse structures are blocked.
- A queue item must have an explicit partition. Partition names are never inferred from filenames. The UI exposes a partition field for each queue item and for standalone recovery/boot images. The Fastboot image path accepts `.img` only; ZIPs must be unpacked first and other formats require a reviewed parser.
- Standalone Recovery and patched Boot image paths now have their own publisher-checksum verification control. Missing or mismatched checksums block the write.
- Logical partition CREATE/RESIZE/DELETE, bootloader locking, and automatic vbmeta modification remain disabled because the application cannot currently prove all device-specific safety conditions.
- Erase, wipe, unlock, and slot modification are protected by a command-level authorization callback. The generic Fastboot command interface allows only reviewed read-only/reboot commands or specifically authorized destructive commands.
- Wipe stops immediately if userdata erase fails; metadata erase is not attempted after a failure.
- USB transfer errors, zero-byte reads, malformed responses, and timeouts mark the Fastboot protocol state uncertain. The connection is invalidated and must be re-detected; destructive operations are never automatically retried.
- Operation state is journaled in app preferences. If the app restarts with an operation still marked RUNNING, it is recorded as INTERRUPTED and the app instructs the operator not to retry automatically.
- Firmware ZIP extraction is staged and committed only after the entire archive has been read successfully. Failed extraction does not add partial images to the queue.
- HTTPS downloads reject redirects to non-HTTPS URLs, require a positive Content-Length and validate the exact received size, use temporary files, and do not silently overwrite an existing firmware file.
- Backup uses a temporary file, checks the bootloader-reported partition size and available storage, computes SHA-256, writes metadata, and refuses overwrite.
- ADB sideload requires the ADB USB interface and a Recovery/Sideload banner (normal Android ADB `device` state is blocked), requires a publisher SHA-256, stages the package in private app cache before protocol negotiation, checks package size, and compares a locally computed SHA-256 with the streamed transfer. Recovery ADB product/hardware identity is not yet queried by this transport; package/device compatibility must be checked against OEM instructions.

## Important operator workflow

1. Connect the target phone in Fastboot mode and select **RECONNECT USB** if the link has been invalidated.
2. Confirm the detected product ID using the Model Guard. Do not copy a product ID from a similar model.
3. Add the image or select a Recovery/Boot image.
4. Enter the exact target partition manually.
5. Obtain the expected SHA-256 from a trusted OEM or independently verified source and run **VERIFY SHA-256**.
6. Open the Safety Analyzer page, read the unresolved warnings, and explicitly acknowledge them for this device session. Critical failures cannot be acknowledged away.
7. Run the flash action. The checks are repeated at the USB transport boundary immediately before download and the transfer is hashed again.
7. If USB fails, the operation is stopped. Reconnect and inspect the phone's current mode/partition state before deciding what to do. Flash resume is not claimed or attempted.

A PASS means the checks implemented by this build passed. It is not a guarantee against unknown hardware, firmware, bootloader, or vendor-specific behavior.

## Build environment and validation

- Android namespace/application ID: `com.flashforge`
- `compileSdk`: 34
- Android Gradle Plugin: 8.5.2 (Gradle 8.7 is the matching distribution)
- Kotlin Gradle plugin: 1.9.24
- Java target: 17

The supplied project does not include `gradlew`, `gradle/wrapper/gradle-wrapper.jar`, or a Gradle wrapper distribution. The current editing environment also has no installed Gradle executable or Android SDK. Therefore `clean`, `assembleDebug`, `test`, and `lint` were **not run successfully** and no APK is included. Open the project in Android Studio with the matching Android SDK and Gradle installation, sync, then run:

```bash
gradle clean assembleDebug test lint
```

Do not perform destructive tests on a personal phone. Start with mock tests and non-destructive device identification on an explicitly authorized test device.

## Known incomplete features

- No physical USB/Fastboot device testing has been performed in this environment.
- ADB Recovery Sideload needs validation against actual supported recoveries; ADB AUTH/key authorization is not implemented, and transport completion is not the same as confirmed installation success.
- Backup Restore is not implemented. Backup creation is available only when the bootloader supports `fetch`.
- Firmware download resume is not implemented.
- Full firmware package metadata parsing (build/region/CSC/device compatibility) is incomplete; product ID, checksum, slot, partition type, and size gates are implemented.
- Qualcomm EDL/Sahara/Firehose, MediaTek BROM/DA, Samsung Download Mode flashing, and Unisoc FDL write protocols are not implemented. Detection must not be treated as flash support.
- Bootloader relocking, logical partition modification, and automatic vbmeta patching are intentionally blocked.
- No interrupted partition-write resume is supported. No automatic retry or automatic reboot is performed.

See `TECHNICAL_AUDIT_AND_CHANGELOG_BN.md` for the Bengali audit, changed files, validation details, and remaining risks.

## Latest UI update
- Home header logo: slowly auto-rotating gear inside a rounded-square tile.
- Bottom tab labels centered under their icons (tabs spread evenly when they fit the screen).
- Top-right link pill reads "NOT CONNECTED" when no device is linked.
- Button audit: downloaded-files list now refreshes after delete; EXPORT in Log now also opens the share sheet.
