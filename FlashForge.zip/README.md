# FlashForge
USB-OTG phone-to-phone flash workbench (Kotlin, Jetpack Compose).

GitHub build: keep `.github/workflows/build.yml` at the repository root and push either this
project's files or this zip file. The workflow extracts the zip if needed and builds the APK
(Actions > latest run > Artifacts > FlashForge-debug-apk).

Device list: edit `app/src/main/assets/devices.json`, host a copy on GitHub (raw URL) and paste
the URL in the app: Log tab > Device database > Update.

## Version 1.1
- Data cable alert: if the USB speed stays under 2 MB/s for 3 seconds, a USB transfer fails or the
  connection keeps dropping, a "Change the data cable" dialog appears. Choose "I will change it" or
  "Continue anyway".
- Floating bubble: while a flash, backup, sideload or download runs, a draggable bubble with progress,
  speed and cable warnings floats over every app (tap it to return). Grant the overlay permission
  in the Device tab > FLOATING BUBBLE (also allow notifications). "Test bubble" shows a 20 s demo.
- New unique launcher icon (phone + lightning bolt + USB plug on a blueprint grid, with themed icon layer).
- All tab icons and button icons are now coloured graphical icons.

## Version 1.2 (UI restyle only)
- New look: rounded cards, soft pastel background, slanted gradient buttons with white icon tiles,
  header card with a link-state pill, bottom navigation bar. No logic, feature or tab was changed.


## Safety upgrade notes
- Added a dedicated Pre-Flash Safety Analyzer page in the existing navigation.
- Destructive Fastboot operations now require an explicitly confirmed expected product ID and a ready Fastboot connection.
- Every image write path requires a publisher-provided SHA-256 match and re-hashes the file immediately before transfer.
- Image writes require the bootloader to report the target partition size; unknown capacity and oversized images are blocked.
- Automatic vbmeta patching is disabled because it weakens Android Verified Boot. Bootloader locking is blocked until device-specific stock compatibility can be established.
- Firmware downloads require HTTPS, validate known content length, use a temporary file, and reject empty/incomplete downloads.
- The Analyzer distinguishes the controller phone battery from the target phone battery. A target battery value is not fabricated.

Safety checks are fail-closed but are not a guarantee against unknown hardware, bootloader, firmware, or vendor-specific risks. The project has not been physically tested against a device in this environment.

## Validation status
The source ZIP was inspected and updated, but this environment did not contain a Gradle executable, Gradle wrapper, or Android SDK. Therefore no successful `clean`, `assembleDebug`, `test`, or `lint` result is claimed. See `TECHNICAL_AUDIT_AND_CHANGELOG_BN.md` for the Bengali audit, implemented safeguards, and remaining limitations.

## Mandatory pre-flash enforcement

The Safety Analyzer is not only a standalone screen. Every image write goes through the same application-level `executeVerifiedFlash()` route, and the Fastboot transport requires a mandatory authorization callback before sending `download:`. The callback rechecks device identity/readiness, publisher SHA-256, controller battery threshold, partition name/capacity, and the current URI size. The image stream is hashed again while it is transferred; if the bytes differ from the authorized digest, the app does not issue `flash:<partition>`. Raw `cmd("flash:...")` calls are explicitly rejected.

This is fail-closed defense in depth, not a guarantee against unknown device/firmware risks. Destructive commands other than image writes still require their own command-specific safety review. Build and hardware validation status is documented in `TECHNICAL_AUDIT_AND_CHANGELOG_BN.md`.
